# WebSocket in Pulse — explained simply

A complete, plain-English guide to the real-time layer of this app: what WebSocket is,
why we need it, how we wired it, and how STOMP, the broker, and the messaging template
fit together. Read it top to bottom once and you'll be able to defend every line.

---

## 1. The problem: why plain HTTP isn't enough

Everything you learned in Block and Contact uses **HTTP**, which works like mailing letters:

1. The **browser asks** ("give me my contacts").
2. The **server answers**.
3. The connection **closes**.

The browser *always speaks first*. The server can never start a conversation — it can only
reply to a question it was asked.

That's fine for "load my contacts." It's useless for chat, because chat needs the **opposite**:

> When Bob sends *you* a message, the **server** must reach **your** browser — but you never
> asked for anything.

With only HTTP, your one option is **polling**: the browser asks "any new messages?" every
second, forever.

```
Browser: any new messages?   Server: no.
Browser: any new messages?   Server: no.
Browser: any new messages?   Server: no.   ← 99% wasted, and still up to 1s late
```

Polling is wasteful (thousands of pointless requests) and laggy (you only find out on the
next poll). We need a way for the **server to push** to the browser the instant something
happens.

---

## 2. What a WebSocket is

A **WebSocket** is a single connection the browser opens **once** and keeps **open**. After
that, **either side can send a message at any time**, with no new request needed.

The analogy:

| HTTP | WebSocket |
|---|---|
| Mailing letters | An open phone call |
| One question → one answer → hang up | Stay connected; either person talks whenever |
| Client must start every exchange | Either side can speak first |
| Stateless (each call is a stranger) | Stateful (the line stays up) |

So with a WebSocket open, the server can say "Bob sent you 'hi'" the moment it happens —
**a push, not a reply.** That is the entire reason WebSocket exists in this app.

### How the connection starts (the handshake)

A WebSocket actually *begins* as a normal HTTP request that asks to be "upgraded":

```
Browser → GET /ws   "Upgrade: websocket"   (a normal HTTP request…)
Server  → 101 Switching Protocols           (…that becomes a permanent 2-way pipe)
```

After that `101`, the same TCP connection stays open as a WebSocket. In our app the browser
connects to the **`/ws`** endpoint (defined in `WebSocketConfig`).

---

## 3. STOMP: giving the pipe an address system

A raw WebSocket is just a **dumb pipe of bytes**. If two messages come down it, how do you
know one is a chat message and the other is a "typing…" signal? Who is each one for? The raw
socket has no idea — it only moves bytes.

**STOMP** (Simple Text Oriented Messaging Protocol) is a thin set of rules layered on top of
the WebSocket that adds **named destinations** — like adding a postal address system to the
phone line. With STOMP you can:

- **SEND** a message *to a destination* — e.g. "send this to `/app/chat.send`".
- **SUBSCRIBE** to a destination — e.g. "tell me whenever anything arrives at
  `/user/queue/messages`".

So the whole real-time feature becomes simple to reason about: **which destinations exist,
who sends to them, and who is subscribed.** Spring has built-in STOMP support, which is why
our code is small.

> **One-line answer for "what does STOMP have to do with WebSocket?"**
> WebSocket is the open pipe; STOMP is the addressing/messaging language we speak over that
> pipe so messages can be routed to the right place and the right person.

---

## 4. Our configuration, line by line (`WebSocketConfig.java`)

This one class sets up the entire "post office." Four rules:

```java
@Configuration
@EnableWebSocketMessageBroker                              // turn on STOMP-over-WebSocket
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws")                        // 1. where browsers connect
                .addInterceptors(authInterceptor)          //    (attaches the logged-in user)
                .setHandshakeHandler(new WebSocketHandshakeHandler())
                .setAllowedOrigins(allowedOriginsArray)    //    CORS for the socket
                .withSockJS();                             //    fallback for old browsers
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.enableSimpleBroker("/topic", "/queue");   // 2. server → clients (outbound)
        registry.setApplicationDestinationPrefixes("/app"); // 3. client → server (inbound)
        registry.setUserDestinationPrefix("/user");        // 4. server → ONE specific user
    }
}
```

Read it as four rules:

1. **`/ws` — the door.** The browser opens its one WebSocket here. `withSockJS()` is a safety
   net: if a network/proxy blocks raw WebSockets, SockJS falls back to other techniques so the
   connection still works. The interceptor + handshake handler are what attach *who you are*
   to the connection (the auth piece — see §8).

2. **`/app` — inbound (client → server).** Anything the **client sends** must go to an address
   starting with `/app`, and Spring routes it to a matching handler method in our code. Think:
   *"`/app` = things my server code will handle."*

3. **`/topic` + `/queue` — outbound (server → clients).** The **broker** delivers messages the
   *server* publishes to whoever subscribed. Convention:
   - `/topic` = broadcast to **many** subscribers (e.g. a group),
   - `/queue` = a **one-to-one** private delivery.

4. **`/user` — outbound to exactly one person.** This is the magic prefix. The server can send
   to `/user/{someUserId}/queue/messages`, and Spring delivers it **only** to that user's
   connection. The recipient's browser just subscribes to `/user/queue/messages` and Spring
   automatically fills in *their own* id. This is how a chat message reaches exactly one person.

> The heartbeat (`setHeartbeatValue(10000, 10000)`) is just a keep-alive ping every 10s so a
> dead connection is detected and cleaned up. It isn't part of the logic.

### The mental model in one sentence

> **Client SENDs to `/app/...`; server PUSHes back to `/user/.../queue/...`.**

Hold that — it is the whole round trip.

---

## 5. What is "the broker"?

The **message broker** is the post office's sorting room: the component that takes a message
the server publishes and **delivers it to everyone subscribed** to that destination.

We use Spring's built-in **"simple broker"** (`enableSimpleBroker`). It runs *inside* our Java
app and keeps an in-memory list of "who is subscribed to what," then routes messages
accordingly. It's perfect for a single-server app like ours.

- **Simple broker (what we use):** in-memory, zero extra infrastructure, simple. Limitation:
  it lives in one app instance, so it doesn't share subscriptions across multiple servers.
- **External broker (RabbitMQ / ActiveMQ):** a separate program you'd plug in if you scaled to
  many server instances that must share real-time state. We don't need it.

So when you say "the broker," you mean: *the in-process component that fans a published message
out to its subscribers.*

---

## 6. The `SimpMessagingTemplate` (how the server actually pushes)

If the broker is the sorting room, **`SimpMessagingTemplate` is the stamp-and-drop tool** the
server code uses to hand a message *to* the broker. Whenever a service wants to push something,
it calls this template. In our code the pattern is always the same:

```java
// every service has this helper:
private void sendTo(Long userId, ChatMessageResponse response) {
    messagingTemplate.convertAndSendToUser(
            userId.toString(),       // WHO  → resolves to /user/{userId}/...
            "/queue/messages",       // WHICH destination on their side
            response);               // WHAT → auto-converted to JSON
}
```

`convertAndSendToUser(...)` does three things in one call:

1. **convert** — turns our `response` object into JSON (Jackson),
2. **toUser** — targets the `/user/{id}/...` prefix so it reaches **one** specific person,
3. **send** — hands it to the broker, which delivers it to that user's subscription.

There's also a plain `convertAndSend("/topic/...", payload)` for true broadcasts, but Pulse
almost always targets specific users, so you'll mostly see **`convertAndSendToUser`**.

---

## 7. Putting it together: a message's full round trip

Here is every moving part, end to end, using our real class and method names.

```
Sender's browser
   │  STOMP SEND to  /app/chat.send   {receiverId: 7, "hi"}
   ▼
@MessageMapping("/chat.send")  in ChatController          ← the "/app" rule routes here
   │  principal = sender's id  (auth attached at handshake)
   ▼
ChatService.sendDirectMessage(...)
   │  validate → load users → conversationId → save Message row → (status row)
   │  build ChatMessageResponse
   ├─ messagingTemplate.convertAndSendToUser("7", "/queue/messages", resp)  ─┐
   └─ messagingTemplate.convertAndSendToUser(senderId, "/queue/messages", resp)
                                                                              │ broker delivers
   ┌──────────────────────────────────────────────────────────────────────────┘
   ▼                                          ▼
Receiver's browser                        Sender's browser
(subscribed to /user/queue/messages)      (also subscribed → sees its own message
 shows the new message live                with the real id/time = "echo")
```

Two things worth saying out loud because interviewers love them:

- **Why echo to the sender too?** Because the client's SEND was *fire-and-forget* (a STOMP SEND
  gets no HTTP-style response body). The server pushes the saved message back so the sender's
  UI learns the real database id, timestamp, and status — and so the sender's other devices
  stay in sync.
- **`@MessageMapping` is the WebSocket twin of `@PostMapping`,** and the `Principal` parameter
  is the WebSocket twin of `SecurityUtil.currentUserId()`. Same ideas, different door.

---

## 8. Where "who am I?" comes from (the auth seam)

A REST controller gets the user from `SecurityUtil.currentUserId()`. A WebSocket controller
gets it from the **`Principal`** parameter:

```java
@MessageMapping("/chat.send")
public void sendMessage(SendMessageRequest request, Principal principal) {
    Long senderId = Long.valueOf(principal.getName());   // the logged-in user's id
    chatService.sendDirectMessage(senderId, request);
}
```

That `Principal` is attached **once, at the handshake**, by the `authInterceptor` +
`WebSocketHandshakeHandler` you saw registered on the `/ws` endpoint. They read the user's
token as the socket connects and bind their identity to the whole connection. After that,
every message on that socket already "knows" who sent it.

> You don't need the internals to defend the design: *"identity is verified once when the
> socket connects, then every message on that connection carries it automatically."*

---

## 9. The five outbound queues in Pulse

The server pushes five distinct kinds of event, each on its own `/queue/...` destination. The
browser subscribes to all five and updates a different part of the UI for each.

| Queue (`/user/{id}/...`) | Carries | Sent by |
|---|---|---|
| `/queue/messages` | a new chat message | `ChatService` |
| `/queue/status` | tick update (delivered/read) | `MessageStatusService` |
| `/queue/message-edited` | a message's text changed | `MessageActionService` |
| `/queue/message-deleted` | a message was deleted-for-everyone | `MessageActionService` |
| `/queue/typing` | someone started/stopped typing | `TypingService` |

And the inbound side — what the **client sends** to `/app/...`:

| Client SENDs to | Handler | Purpose |
|---|---|---|
| `/app/chat.send` | `ChatController.sendMessage` | send a direct message |
| `/app/group.send` | `sendGroupMessage` | send a group message |
| `/app/chat.delivered` | `markDelivered` | acknowledge delivery (✓✓) |
| `/app/chat.read` | `markRead` | acknowledge read (blue ✓✓) |
| `/app/chat.typing` | `typing` | broadcast typing on/off |

---

## 10. Glossary (say these in one breath)

- **WebSocket** — a single, long-lived, two-way connection between browser and server; either
  side can send any time. Solves "the server needs to push."
- **Handshake** — the initial HTTP request to `/ws` that "upgrades" into the WebSocket.
- **STOMP** — a simple messaging protocol over the WebSocket that adds **named destinations**
  so messages can be routed; supports SEND and SUBSCRIBE.
- **Destination** — an address like `/app/chat.send` or `/user/queue/messages`.
- **Broker** — the component that delivers a published message to all its subscribers; we use
  Spring's in-memory **simple broker** on `/topic` and `/queue`.
- **`/app` prefix** — inbound; client → server; routed to `@MessageMapping` methods.
- **`/topic`** — outbound broadcast (many subscribers). **`/queue`** — outbound one-to-one.
- **`/user` prefix** — outbound to one specific user; Spring maps `/user/queue/x` to that
  person's connection.
- **`SimpMessagingTemplate`** — the server-side tool to publish a message to the broker;
  `convertAndSendToUser(id, dest, payload)` = JSON-ify + target one user + send.
- **`@MessageMapping`** — WebSocket equivalent of `@PostMapping`.
- **`Principal`** — WebSocket equivalent of `currentUserId()`; identity bound at handshake.
- **SockJS** — a fallback that emulates WebSocket when the real thing is blocked.

---

## 11. Defend it out loud (interview-style Q&A)

**Q: Why did you use WebSocket instead of HTTP?**
A: Chat needs the *server* to push to the *client* the moment a message arrives. HTTP is
request/response — the client must ask first — so the only HTTP option is constant polling,
which is wasteful and laggy. A WebSocket is one persistent two-way connection, so the server
can push instantly. That's exactly what live messaging, ticks, and typing need.

**Q: What is STOMP and why not raw WebSocket?**
A: A raw WebSocket is just a byte pipe with no notion of "who is this for" or "what kind of
message is this." STOMP layers named **destinations** and SEND/SUBSCRIBE semantics on top, so
we can route a chat message vs a typing event vs a tick update, and address a specific user.
Spring's STOMP support is why the code stays small.

**Q: What does the broker do?**
A: It's the delivery component: it takes a message the server publishes to a destination and
delivers it to everyone subscribed. We use Spring's built-in in-memory simple broker on
`/topic` and `/queue` — no extra infrastructure, ideal for a single-server app.

**Q: How does a message reach exactly one person and not everyone?**
A: The `/user` destination prefix. The server calls
`convertAndSendToUser(userId, "/queue/messages", payload)`; Spring maps that to
`/user/{userId}/queue/messages`, and only that user's subscription receives it.

**Q: When you send a message, how does your *own* screen show it correctly?**
A: The client's STOMP SEND is fire-and-forget — no response body. So the server pushes the
saved message back to the sender too (the "echo"), which carries the real database id,
timestamp, and status, and keeps the sender's other devices in sync.

**Q: How does the server know which user a WebSocket message came from?**
A: At the handshake (connection to `/ws`), an interceptor verifies the user's token and binds
their identity to the connection. After that, every message exposes it via the `Principal`
parameter — the WebSocket equivalent of `currentUserId()`.

**Q: What are `/app`, `/topic`, `/queue`, `/user`?**
A: `/app` = inbound, client→server, handled by `@MessageMapping`. `/topic` = outbound
broadcast to many. `/queue` = outbound one-to-one. `/user` = outbound to a single specific
user. Inbound at `/app`, outbound at `/user/.../queue/...` is the whole round trip.

**Q: Could this scale to multiple servers?**
A: The in-memory simple broker is per-instance, so subscriptions aren't shared across servers.
To scale horizontally you'd swap in an external broker (RabbitMQ/ActiveMQ) via
`enableStompBrokerRelay`, so all instances share real-time state. For our single-server scope,
the simple broker is the right, simplest choice.

---

### The whole thing in five sentences

WebSocket gives us one always-open, two-way connection so the **server can push** to the
browser — which HTTP can't do without wasteful polling. **STOMP** rides on top of that pipe to
add **addresses** (destinations) and SEND/SUBSCRIBE, so messages can be routed and targeted.
Clients **send** to `/app/...` (handled by `@MessageMapping`), and the server **pushes back**
through the **broker** to `/user/.../queue/...` so it reaches exactly one person. The server
publishes with **`SimpMessagingTemplate.convertAndSendToUser(...)`**, which JSON-ifies the
payload and targets that user. Identity is bound once at the **handshake** and read later from
the **`Principal`** — the WebSocket twin of `currentUserId()`.
```
