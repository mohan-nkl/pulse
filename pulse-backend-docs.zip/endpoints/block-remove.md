# `DELETE /api/v1/blocks/{userId}`
> Unblock a user (idempotent — no-op if not blocked).

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (throws `ApiException(401)` if no/invalid auth principal).
**Request:** path var `userId: Long` (the user to unblock). No request body.
**Success:** `200 OK` — `ApiResponse.ok(null)` → `{ "success": true, "data": null, "timestamp": <Instant> }`.
**Errors:**
- not authenticated → `ApiException(UNAUTHORIZED, ...)` → `401`
- No "not found" error: if the block does not exist, it silently does nothing (idempotent).
- `ApiException`s rendered by `GlobalExceptionHandler.handleApiException` → `ApiResponse.error(message)` + status.

## Flow
```
Client ──► DELETE /api/v1/blocks/{userId} (no body)
  ▼
BlockController.unblock(userId)
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(UNAUTHORIZED) → 401
  ▼
BlockService.unblock(blockerId, blockedId)          [@Transactional]
  ▼
blockRepository.findByBlocker_IdAndBlocked_Id(blockerId, blockedId) — Optional<Block>
  ├─ empty ──► do nothing (idempotent)
  ▼ present
blockRepository.delete(existingBlock.get()) — remove row from blocks
  ▼
return void ──► BlockController returns ApiResponse.ok(null) ──► 200 JSON
```

## Touched files
- `block/BlockController.java` — `unblock(@PathVariable Long userId)`
- `block/BlockService.java` — `unblock`
- `block/BlockRepository.java` — `findByBlocker_IdAndBlocked_Id`, `delete`
- `block/Block.java` — entity
- `common/SecurityUtil.java` — `currentUserId`
- `common/ApiResponse.java` — `ok`
- `common/GlobalExceptionHandler.java` — error rendering