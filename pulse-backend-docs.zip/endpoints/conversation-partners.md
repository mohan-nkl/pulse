# `GET /api/conversations/partners`
> List the other users the current user has direct (1:1) conversations with, excluding anyone blocked in either direction.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`; throws `ApiException(401)` if missing.
**Request:** no path vars, no query params.
**Success:** `200` — `ApiResponse<List<ConversationPartner>>`, each `{ userId, name, phone, avatarUrl (presigned), lastSeen }`. Only direct partners (no groups). Order is unspecified (built from a Set).
**Errors:**
- No / invalid JWT → `401`.
- Unexpected → `500`.

## Flow
```
Client ──► GET /api/conversations/partners
  ▼
ConversationController.getPartners()
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(401) → 401
  ▼
ConversationService.getPartners(currentUserId)
  ▼
conversationIds = Set<String>:
   ├─ messageRepository.findDirectConversationIdsBySender(currentUserId)
   │     (DISTINCT m.conversationId WHERE m.sender.id = me AND conversationType = DIRECT)
   └─ recipientStatusRepository.findDirectConversationIdsForRecipient(currentUserId)
         (DISTINCT mrs.message.conversationId WHERE mrs.recipient.id = me AND conversationType = DIRECT)
  ▼
for each conversationId:
   ├─ ConversationUtil.dmParticipants(id) → long[]{a,b}
   └─ otherUserId = (a == me) ? b : a   →  partnerIds.add(otherUserId)
  ▼
partnerIds.removeIf( partnerId -> blockService.isBlockedBetween(currentUserId, partnerId) )
   └─ blockRepository.existsBlockBetween(...)   (block in EITHER direction removes partner)
  ▼
userRepository.findAllById(partnerIds)
  ▼
for each User:
   ├─ storageService.presignedUrl(user.avatarUrl)
   └─ new ConversationPartner(id, name, phone, avatarUrl, lastSeen)
  ▼
return List<ConversationPartner>
  ▼
ApiResponse.ok(list) ──► 200 JSON
```

## Touched files
- message/ConversationController.java
- message/ConversationService.java
- message/MessageRepository.java
- message/MessageRecipientStatusRepository.java
- block/BlockService.java
- storage/StorageService.java
- common/ConversationUtil.java
- common/SecurityUtil.java
- common/GlobalExceptionHandler.java
- user/UserRepository.java
- message/dtos/ConversationPartner.java