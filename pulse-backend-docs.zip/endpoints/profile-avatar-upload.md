# `POST /api/v1/profile/avatar`
> Validate, store an avatar image in MinIO, and return its presigned URL.

**Auth:** requires JWT — caller id via `SecurityUtil.currentUserId()` (set by JwtAuthFilter).
**Request:** `multipart/form-data` with part `file` (`@RequestParam("file") MultipartFile`).
Service-level validation (`UserProfileService.uploadAvatar`):
- not null and not empty
- `file.getSize()` ≤ `MAX_SIZE` = `5 * 1024 * 1024` (5 MB)
- `file.getContentType()` ∈ `ALLOWED_TYPES` = `["image/jpeg", "image/png", "image/webp"]`
**Success:** `200 OK` — `ApiResponse.ok("Avatar updated.", String)` where `data` is the presigned MinIO URL string → `{ success: true, message: "Avatar updated.", data: "<presigned-url>", timestamp }`.
**Errors:**
- No / invalid auth → `ApiException(401)` → `401`.
- Missing `file` part → `MissingServletRequestParameterException` → `GlobalExceptionHandler.handleMissingParam` → `400` `"Required parameter 'file' is missing."`.
- Null/empty file → `ApiException(BAD_REQUEST, "File must not be empty.")` → `400`.
- Over 5 MB → `ApiException(BAD_REQUEST, "Avatar must not exceed 5 MB.")` → `400`.
- Disallowed content type → `ApiException(BAD_REQUEST, "Avatar must be JPEG, PNG, or WebP.")` → `400`.
- User row missing → `ApiException(NOT_FOUND, "User not found.")` → `404`.
- MinIO put failure → `StorageService.saveToMinio` → `ApiException(INTERNAL_SERVER_ERROR, "Failed to upload file.")` → `500`.
- Presign failure → `ApiException(INTERNAL_SERVER_ERROR, "Failed to generate file URL.")` → `500`.

## Flow
```
Client ──► POST /api/v1/profile/avatar (multipart: file=<image>)
  │
  ▼
DispatcherServlet binds @RequestParam("file")
  ├─ part absent ──► MissingServletRequestParameterException → handleMissingParam → 400
  ▼
UserProfileController.uploadAvatar(file)
  ├─ SecurityUtil.currentUserId() ──(unauthenticated)──► throw ApiException(401) → 401
  ▼
UserProfileService.uploadAvatar(userId, file)
  ├─ file null || isEmpty() ──► throw ApiException(400, "File must not be empty.") → 400
  ├─ size > 5 MB ──────────────► throw ApiException(400, "Avatar must not exceed 5 MB.") → 400
  ├─ contentType not in {jpeg,png,webp} ──► throw ApiException(400, "Avatar must be JPEG, PNG, or WebP.") → 400
  ▼
findById(userId) → userRepository.findById(userId)
  ├─ empty ──► throw ApiException(NOT_FOUND, "User not found.") → 404
  ▼
storageService.upload("avatars", file)
  ├─ buildObjectKey: "avatars/" + UUID + extension(originalFilename)
  ├─ saveToMinio: MinioClient.putObject(stream, size, contentType)
  │     └─(error)──► throw ApiException(500, "Failed to upload file.") → 500
  └─ returns objectKey (avatarKey)
  ▼
user.setAvatarUrl(avatarKey) → userRepository.save(user)  — persist key
  ▼
storageService.presignedUrl(avatarKey) → generatePresignedUrl (MinIO GET, expiryMinutes)
  └─(error)──► throw ApiException(500, "Failed to generate file URL.") → 500
  ▼
ApiResponse.ok("Avatar updated.", presignedUrl) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `user/UserProfileController.java` — `uploadAvatar(MultipartFile)`
- `user/UserProfileService.java` — `uploadAvatar(Long, MultipartFile)`, constants `ALLOWED_TYPES`, `MAX_SIZE`, helper `findById`
- `user/User.java` — `setAvatarUrl`
- `user/UserRepository.java` — `findById`, `save`
- `storage/StorageService.java` — `upload(String, MultipartFile)` → `buildObjectKey`, `saveToMinio`, `extension`; `presignedUrl` → `generatePresignedUrl` (MinIO client)
- `common/ApiResponse.java` — `ok(message, data)`
- `common/SecurityUtil.java` — `currentUserId()`
- `common/GlobalExceptionHandler.java` — `handleMissingParam`, `handleApiException`
