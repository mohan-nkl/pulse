# `DELETE /api/messages/{messageId}/for-everyone`
> Sender-only retraction within a 1-hour window: soft-delete the message for everyone (clears content + media) and broadcast a `MessageDeletedEvent` to all conversation participants.

**Auth:** REST → `SecurityUtil.currentUserId()` from the `SecurityContext` (401 if missing).
**Request:**
- Path var: `messageId` (Long).
- No body.
**Result:** `200` with `ApiResponse.ok(null)`. Side effect: a WS push of `MessageDeletedEvent{ messageId, conversationId }` to `/user/{recipientId}/queue/message-deleted` for every participant (DM: both users; group: all current members — sender included).
**Errors:**
- Message not found → `ApiException(404)` "Message not found."
- Caller is not the sender → `ApiException(403)` "You can only delete your own messages for everyone."
- Already deleted → no error, early return (idempotent; no re-broadcast).
- Older than `DELETE_FOR_EVERYONE_WINDOW` (1 hour, measured `createdAt` → `Instant.now()`) → `ApiException(400)` "This message is too old to delete for everyone."

## Flow
```
Client ──► DELETE /api/messages/{messageId}/for-everyone
  ▼
MessageActionController.deleteForEveryone(messageId)
  ├─ currentUserId = SecurityUtil.currentUserId()
  ▼
MessageActionService.deleteForEveryone(userId, messageId)   @Transactional
  ▼
findMessageOrThrow(messageId)  (empty → 404)
  ▼
message.getSender().getId().equals(userId) ?
  └─ no  ──► throw 403 "You can only delete your own messages for everyone."
  ▼ yes
message.isDeleted() ?  ──yes──► return (idempotent)
  ▼ no
isOlderThan(message, 1h)  [Duration.between(createdAt, now) > 1h]
  └─ true ──► throw 400 "This message is too old to delete for everyone."
  ▼ false
message.setDeleted(true); setContent(null); setMediaUrl(null)
  ▼
messageRepository.save(message)
  ▼
broadcastDeleted(message)
  ├─ event = new MessageDeletedEvent(message.getId(), message.getConversationId())
  ├─ recipientsOf(conversationId):
  │     ├─ isDirect → ConversationUtil.dmParticipants() → [user0, user1]
  │     └─ isGroup  → groupMemberRepository.findByGroupId(groupId) → each member.getUser().getId()
  └─ for each recipientId:
        messagingTemplate.convertAndSendToUser(recipientId, "/queue/message-deleted", event)
  ▼
Controller returns ApiResponse.ok(null)  → 200
```

## Touched files
- `message/MessageActionController.java`
- `message/MessageActionService.java`
- `message/Message.java` / `message/MessageRepository.java`
- `message/dtos/MessageDeletedEvent.java`
- `group/GroupMemberRepository.java` / `group/GroupMember.java`
- `common/SecurityUtil.java` / `common/ConversationUtil.java`
- `common/ApiException.java` / `common/ApiResponse.java` / `common/GlobalExceptionHandler.java`
- `config/WebSocketConfig.java` (broker `/queue`, user prefix `/user`)
