# `POST /api/v1/contacts/sync`
> Match a list of phone numbers against Pulse users, flagging which are already contacts.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`.
**Request:** JSON body `SyncRequest` `{ phones: List<String> (required, @NotEmpty) }`. `@Valid` enforced.
**Success:** `200 OK` — `ApiResponse.ok(List<SyncedUserResponse>)`. Each `SyncedUserResponse` = `{ userId, name, avatarUrl, alreadyContact, contactRecordId }`. The owner's own user is excluded; `contactRecordId` is null when not already a contact. Note: this is NOT block-aware (no block filtering) and does NOT create contacts.
**Errors:**
- Empty `phones` list → `MethodArgumentNotValidException` → `400` ("phones: Phone list must not be empty.").
- Not logged in → `401`. Unexpected → `500`.

## Flow
```
Client ──► POST /api/v1/contacts/sync  (SyncRequest {phones: [...]})
  │
  ▼
ContactController.syncPhones(@Valid SyncRequest)
  │  @Valid empty phones ──invalid──► MethodArgumentNotValidException → 400
  │  SecurityUtil.currentUserId() ──no auth──► 401
  ▼
ContactService.syncPhones(ownerId, request)
  ▼
userRepository.findByPhoneIn(request.getPhones()) — all Pulse users matching the phones
  ▼
buildExistingContactMap(ownerId)
  └─ contactRepository.findByOwner_Id(ownerId) → Map<contactUserId, contactRecordId>
  ▼
for each matched User:
  ├─ user.id == ownerId ──► skip (continue) [self EXCLUDED]
  ├─ alreadyContact = map.containsKey(user.id)
  ├─ contactRecordId = map.get(user.id)   (null if not a contact)
  └─ avatarUrl = storageService.presignedUrl(user.getAvatarUrl())
  ▼
SyncedUserResponse.builder(userId, name, avatarUrl, alreadyContact, contactRecordId)
  ▼
return List<SyncedUserResponse>
  ▼
ApiResponse.ok(list) ──► 200 JSON
```

## Touched files
- `contact/ContactController.java` — `syncPhones()`
- `contact/ContactService.java` — `syncPhones`, `buildExistingContactMap`
- `contact/ContactRepository.java` — `findByOwner_Id`
- `contact/Contact.java`
- `contact/dtos/SyncRequest.java`, `contact/dtos/SyncedUserResponse.java`
- `user/UserRepository.java` — `findByPhoneIn`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/GlobalExceptionHandler.java`