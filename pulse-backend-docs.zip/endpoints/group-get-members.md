# `GET /api/groups/{groupId}/members`
> List all members of a group (caller must be a member); each entry includes role and presigned avatar URL.

**Auth:** requires JWT — actorId via `SecurityUtil.currentUserId()` (else 401).
**Request:** path var `groupId` (`Long`). No body.
**Success:** `200 OK`, `ApiResponse.ok(List<GroupMemberResponse>)` → `{ success:true, message:null, data:[ { userId, name, avatarUrl, role }, ... ], timestamp }`.
**Errors:**
- Caller not a member → `requireMembership` → `ApiException(FORBIDDEN)` → 403 "You are not a member of this group.".
- No JWT/principal → 401.
- Note: `requireMembership` returns 403 (not 404) even if the group does not exist, since lookup is by `(groupId, userId)`.

## Flow
```
Client ──► GET /api/groups/{groupId}/members
  ▼
GroupController.getMembers(groupId)  ── SecurityUtil.currentUserId() ──no auth──► 401
  ▼
GroupService.getMembers(actorId, groupId)   [@Transactional(readOnly=true)]
  ▼
requireMembership(groupId, actorId)
  └─ groupMemberRepository.findByGroupIdAndUserId(groupId, actorId)
       └─ empty ──► throw ApiException(403 "You are not a member of this group.") → 403
  ▼
groupMemberRepository.findByGroupId(groupId) — all members
  ▼
for each member: toMemberResponse(member)
  ├─ user = member.getUser()
  └─ storageService.presignedUrl(user.avatarUrl)
  ▼
return List<GroupMemberResponse> ──► ApiResponse.ok(list) ──► 200 JSON
```

## Touched files
- `group/GroupController.java` — `getMembers`
- `group/GroupService.java` — `getMembers`, `requireMembership`, `toMemberResponse`
- `group/dtos/GroupMemberResponse.java` — response DTO
- `group/GroupMember.java`, `group/GroupRole.java` — entity/enum
- `group/GroupMemberRepository.java` — `findByGroupIdAndUserId`, `findByGroupId`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/ApiException.java`