# `POST /api/messages/{messageId}/reactions`
> Add or change the caller's emoji reaction on a message (one reaction per user per message), broadcast it, and notify the author.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (throws `ApiException(401)` if no/invalid auth principal).
**Request:**
- path var `messageId: Long`
- body `ReactionRequest { emoji: String }` — read via `request.getEmoji()`. No bean-validation annotations; emptiness is checked manually in the service.
**Success:** `200 OK` — `ApiResponse.ok(null)` → `{ "success": true, "data": null, "timestamp": Instant }`. The actual reaction state is delivered over WebSocket (see realtime), not in the HTTP body.
**Errors:**
- emoji null/blank → `ApiException(BAD_REQUEST, "Emoji is required.")` → `400`
- message not found → `ApiException(NOT_FOUND, "Message not found.")` → `404`
- DM: caller not one of the two participants → `ApiException(FORBIDDEN, "You are not part of this conversation.")` → `403`
- group: caller not a member → `ApiException(FORBIDDEN, "You are not a member of this group.")` → `403`
- not authenticated → `ApiException(UNAUTHORIZED, ...)` → `401`
- `ApiException`s rendered by `GlobalExceptionHandler.handleApiException`.

## Flow
```
Client ──► POST /api/messages/{messageId}/reactions  body:{emoji}
  ▼
ReactionController.react(messageId, request)
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(UNAUTHORIZED) → 401
  ▼
ReactionService.react(userId, messageId, emoji)       [@Transactional]
  ├─ emoji == null || isBlank() ──true──► throw ApiException(BAD_REQUEST,"Emoji is required.") → 400
  ▼
findMessageOrThrow(messageId)
  └─ messageRepository.findById(messageId) ──empty──► throw ApiException(NOT_FOUND,"Message not found.") → 404
  ▼
ensureMember(userId, message.getConversationId())     ◄── membership gate
  ├─ ConversationUtil.isDirect(convId)?  dmParticipants(convId) → not p0/p1 ──► ApiException(FORBIDDEN,"...not part of this conversation.") → 403
  └─ ConversationUtil.isGroup(convId)?   groupIdFrom(convId) →
        groupMemberRepository.existsByGroupIdAndUserId(groupId,userId)==false ──► ApiException(FORBIDDEN,"...not a member of this group.") → 403
  ▼
findOrCreateReaction(message, userId)                 ◄── upsert
  ├─ reactionRepository.findByMessage_IdAndUser_Id(messageId,userId) present ──► reuse existing
  └─ else new Reaction(); setMessage(message); setUser(userRepository.getReferenceById(userId))
  ▼
reaction.setEmoji(emoji); reactionRepository.save(reaction) — insert/update (unique message_id+user_id)
  ▼
broadcast(message)                                    ◄── realtime ReactionUpdate
  ├─ update = new ReactionUpdate(messageId, convId, currentReactions(messageId))
  │      └─ currentReactions = reactionRepository.findByMessage_Id(messageId) → [ReactionEntry{userId,userName,emoji}]
  ├─ isDirect(convId): dmParticipants → send(p0,update); send(p1,update)
  └─ isGroup(convId): groupMemberRepository.findByGroupId(groupId) → send(each member.user.id, update)
        └─ send: messagingTemplate.convertAndSendToUser(recipientId, "/queue/reactions", update)
  ▼
notifyAuthorIfNeeded(message, reactorId=userId, emoji)
  ├─ authorId = message.getSender().getId()
  ├─ authorId.equals(reactorId) ──true──► return (skip self-notify)
  ▼ false
  ├─ reactorName = reactorNameOf(reactorId)  [userRepository.findById → name, else "Someone"]
  └─ notificationService.sendReactionNotification(authorId, convId, reactorName, emoji)
        └─ messagingTemplate.convertAndSendToUser(authorId, "/queue/notifications", NotificationDto{type:"REACTION",...})
  ▼
return void ──► ReactionController returns ApiResponse.ok(null) ──► 200 JSON
```

## Touched files
- `reaction/ReactionController.java` — `react`
- `reaction/ReactionService.java` — `react`, `findMessageOrThrow`, `ensureMember`, `findOrCreateReaction`, `broadcast`, `currentReactions`, `toEntry`, `send`, `notifyAuthorIfNeeded`, `reactorNameOf`
- `reaction/ReactionRepository.java` — `findByMessage_IdAndUser_Id`, `findByMessage_Id`, `save`
- `reaction/Reaction.java` — entity (unique message_id+user_id)
- `reaction/dtos/ReactionRequest.java` — request body (`emoji`)
- `reaction/dtos/ReactionUpdate.java` — broadcast payload (`messageId,conversationId,reactions`)
- `reaction/dtos/ReactionEntry.java` — `userId,userName,emoji`
- `message/MessageRepository.java` — `findById`
- `group/GroupMemberRepository.java` — `existsByGroupIdAndUserId`, `findByGroupId`
- `common/ConversationUtil.java` — `isDirect`, `isGroup`, `dmParticipants`, `groupIdFrom`
- `notification/NotificationService.java` — `sendReactionNotification`
- `user/UserRepository.java` — `getReferenceById`, `findById`
- `common/SecurityUtil.java` — `currentUserId`
- `common/ApiResponse.java` — `ok`
- `common/GlobalExceptionHandler.java` — error rendering
