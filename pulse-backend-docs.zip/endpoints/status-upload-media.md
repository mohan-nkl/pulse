# `POST /api/v1/statuses/upload`
> Upload a status image/video to object storage and return its MinIO object key.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (throws 401 if no authenticated principal).
**Request:** multipart form field `file` (`@RequestParam("file") MultipartFile`). No body DTO.
**Success:** `200 OK` — `ApiResponse.ok("Image uploaded.", mediaUrl)` where `mediaUrl` is the generated MinIO object key (e.g. `status/<uuid>.jpg`), returned as a plain `String` in `data`.
**Errors:**
- Missing/empty file → `ApiException(BAD_REQUEST, "File must not be empty.")` → **400**
- Size > 20 MB (`MAX_MEDIA_SIZE = 20L * 1024 * 1024`) → `ApiException(BAD_REQUEST, "Status media must not exceed 20 MB.")` → **400**
- Content type not in `ALLOWED_MEDIA_TYPES` (image/jpeg, image/png, image/webp, image/gif, video/mp4, video/webm, video/quicktime, video/ogg) → `ApiException(BAD_REQUEST, "Status media must be an image or a video.")` → **400**
- MinIO put failure → `ApiException(INTERNAL_SERVER_ERROR, "Failed to upload file.")` → **500**
- No JWT → `ApiException(UNAUTHORIZED, ...)` → **401**

## Flow
```
Client ──► POST /api/v1/statuses/upload (multipart file)
  ▼
StatusController.uploadMedia(file)
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(UNAUTHORIZED) → 401
  ▼
StatusService.uploadStatusMedia(userId, file)
  ├─ file == null || file.isEmpty() ──true──► throw ApiException(BAD_REQUEST,"File must not be empty.") → 400
  ├─ file.getSize() > MAX_MEDIA_SIZE (20MB) ──true──► throw ApiException(BAD_REQUEST,"...not exceed 20 MB.") → 400
  ├─ !ALLOWED_MEDIA_TYPES.contains(contentType) ──true──► throw ApiException(BAD_REQUEST,"...image or a video.") → 400
  ▼
StorageService.upload("status", file)
  ├─ buildObjectKey("status", originalFilename) — "status/" + UUID + extension
  ├─ saveToMinio(objectKey, file) — minioClient.putObject(bucket, key, stream, contentType)
  │     └─ Exception ──► throw ApiException(INTERNAL_SERVER_ERROR,"Failed to upload file.") → 500
  ▼
return objectKey (String)
  ▼
ApiResponse.ok("Image uploaded.", mediaUrl) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `status/StatusController.java` — `uploadMedia`
- `status/StatusService.java` — `uploadStatusMedia`, `ALLOWED_MEDIA_TYPES`, `MAX_MEDIA_SIZE`
- `storage/StorageService.java` — `upload`, `buildObjectKey`, `saveToMinio`
- `common/SecurityUtil.java` — `currentUserId`
- `common/GlobalExceptionHandler.java` — maps `ApiException` to status/JSON
- `common/ApiResponse.java` — response envelope
