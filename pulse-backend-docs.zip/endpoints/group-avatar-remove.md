# `DELETE /api/groups/{groupId}/avatar`
> Admin removes the group photo by clearing the stored avatar key (no MinIO object deletion).

**Auth:** requires JWT — actorId via `SecurityUtil.currentUserId()` (else 401). Admin-only.
**Request:** path var `groupId` (`Long`). No body.
**Success:** `200 OK`, `ApiResponse.ok("Group photo removed", GroupResponse)` → `data.avatarUrl` is `null` (presignedUrl(null) → null).
**Errors:**
- Caller not a member → `requireAdmin`→`requireMembership` → 403.
- Caller not ADMIN → `requireAdmin` → 403 "Only an admin can do that.".
- Group not found → `findGroupOrThrow` → 404 "Group not found".
- No JWT → 401.

## Flow
```
Client ──► DELETE /api/groups/{groupId}/avatar
  ▼
GroupController.removeGroupAvatar(groupId)  ── currentUserId() ──no auth──► 401
  ▼
GroupService.removeGroupAvatar(actorId, groupId)   [@Transactional]
  ▼
requireAdmin(actorId, groupId)
  ├─ requireMembership(groupId, actorId) ──not member──► ApiException(403) → 403
  └─ role != ADMIN ──► ApiException(403 "Only an admin can do that.") → 403
  ▼
findGroupOrThrow(groupId) → groupRepository.findById ──empty──► ApiException(404 "Group not found") → 404
  ▼
group.setAvatarUrl(null)  (only clears the key; MinIO object is not deleted)
  ▼
groupRepository.save(group)
  ▼
countMembers(groupId) → findByGroupId(...).size()
  ▼
toGroupResponse(savedGroup, ADMIN, memberCount)
  └─ storageService.presignedUrl(null) → returns null
  ▼
return GroupResponse ──► ApiResponse.ok("Group photo removed", group) ──► 200 JSON
```

## Touched files
- `group/GroupController.java` — `removeGroupAvatar`
- `group/GroupService.java` — `removeGroupAvatar`, `requireAdmin`, `requireMembership`, `findGroupOrThrow`, `countMembers`, `toGroupResponse`
- `group/dtos/GroupResponse.java` — response DTO
- `group/Group.java` (`avatarUrl`), `group/GroupRole.java`
- `group/GroupRepository.java`, `group/GroupMemberRepository.java`
- `storage/StorageService.java` — `presignedUrl` (null-safe)
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/ApiException.java`