# `POST /api/groups/{groupId}/admins/{userId}`
> Admin promotes an existing member to ADMIN.

**Auth:** requires JWT — actorId via `SecurityUtil.currentUserId()` (else 401). Admin-only.
**Request:** path vars `groupId` (`Long`), `userId` (`Long`, target to promote). No body.
**Success:** `200 OK`, `ApiResponse.ok("Member promoted to admin", List<GroupMemberResponse>)` — refreshed member list.
**Errors:**
- Caller not a member → `requireAdmin`→`requireMembership` → 403.
- Caller not ADMIN → `requireAdmin` → 403 "Only an admin can do that.".
- Target not a member → `requireMembership` → 403 "You are not a member of this group.".
- No JWT → 401.
- Note: no self-check — promoting yourself just re-saves your existing ADMIN role (idempotent).

## Flow
```
Client ──► POST /api/groups/{groupId}/admins/{userId}
  ▼
GroupController.makeAdmin(groupId, userId)  ── currentUserId() ──no auth──► 401
  ▼
GroupService.makeAdmin(actorId, groupId, targetUserId)   [@Transactional]
  ▼
requireAdmin(actorId, groupId)
  ├─ requireMembership(groupId, actorId) ──not member──► ApiException(403) → 403
  └─ role != ADMIN ──► ApiException(403 "Only an admin can do that.") → 403
  ▼
requireMembership(groupId, targetUserId) ──target not member──► ApiException(403) → 403
  ▼
target.setRole(ADMIN)
  ▼
groupMemberRepository.save(target) — persist role change
  ▼
return getMembers(actorId, groupId)
  ▼
──► ApiResponse.ok("Member promoted to admin", List<GroupMemberResponse>) ──► 200 JSON
```

## Touched files
- `group/GroupController.java` — `makeAdmin`
- `group/GroupService.java` — `makeAdmin`, `requireAdmin`, `requireMembership`, `getMembers`, `toMemberResponse`
- `group/dtos/GroupMemberResponse.java` — response DTO
- `group/GroupMember.java`, `group/GroupRole.java`
- `group/GroupMemberRepository.java` — `findByGroupIdAndUserId`, `save`, `findByGroupId`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/ApiException.java`