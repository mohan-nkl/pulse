# `PUT /api/messages/{messageId}`
> Sender-only edit of a TEXT message within a 30-minute window: update content, mark `edited`, and broadcast a `MessageEditedEvent` to all conversation participants.

**Auth:** REST → `SecurityUtil.currentUserId()` from the `SecurityContext` (401 if missing).
**Request:**
- Path var: `messageId` (Long).
- Body DTO: `EditMessageRequest { content: String }`. The controller passes `request.getContent()` into the service.
**Result:** `200` with `ApiResponse.ok(null)`. Side effect: a WS push of `MessageEditedEvent{ messageId, conversationId, content }` to `/user/{recipientId}/queue/message-edited` for every participant (DM: both users; group: all current members — sender included).
**Errors:**
- Message not found → `ApiException(404)` "Message not found."
- Caller is not the sender → `ApiException(403)` "You can only edit your own messages."
- Message is deleted → `ApiException(400)` "You cannot edit a deleted message."
- Message type is not `TEXT` → `ApiException(400)` "Only text messages can be edited."
- `content` null/blank → `ApiException(400)` "Edited message cannot be empty."
- Older than `EDIT_WINDOW` (30 minutes, `createdAt` → `Instant.now()`) → `ApiException(400)` "This message is too old to edit."

## Flow
```
Client ──► PUT /api/messages/{messageId}   body: EditMessageRequest{ content }
  ▼
MessageActionController.editMessage(messageId, request)
  ├─ currentUserId = SecurityUtil.currentUserId()
  └─ calls service with request.getContent()
  ▼
MessageActionService.editMessage(userId, messageId, newContent)   @Transactional
  ▼
findMessageOrThrow(messageId)  (empty → 404)
  ▼
sender == userId ?            ──no──► 403 "You can only edit your own messages."
  ▼ yes
message.isDeleted() ?         ──yes─► 400 "You cannot edit a deleted message."
  ▼ no
message.getType() != TEXT ?   ──yes─► 400 "Only text messages can be edited."
  ▼ no
content null/blank ?          ──yes─► 400 "Edited message cannot be empty."
  ▼ no
isOlderThan(message, 30m) ?   ──yes─► 400 "This message is too old to edit."
  ▼ no
message.setContent(newContent.trim()); message.setEdited(true)
  ▼
messageRepository.save(message)
  ▼
broadcastEdited(message)
  ├─ event = new MessageEditedEvent(id, conversationId, content)
  ├─ recipientsOf(conversationId): DM → dmParticipants(); group → findByGroupId members
  └─ for each recipientId:
        messagingTemplate.convertAndSendToUser(recipientId, "/queue/message-edited", event)
  ▼
Controller returns ApiResponse.ok(null)  → 200
```

## Touched files
- `message/MessageActionController.java`
- `message/MessageActionService.java`
- `message/dtos/EditMessageRequest.java`
- `message/dtos/MessageEditedEvent.java`
- `message/Message.java` / `message/MessageType.java` / `message/MessageRepository.java`
- `group/GroupMemberRepository.java` / `group/GroupMember.java`
- `common/SecurityUtil.java` / `common/ConversationUtil.java`
- `common/ApiException.java` / `common/ApiResponse.java` / `common/GlobalExceptionHandler.java`
- `config/WebSocketConfig.java`