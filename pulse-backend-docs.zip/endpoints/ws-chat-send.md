# `STOMP SEND /app/chat.send`
> Send a 1:1 direct message: persist it, create the receiver's delivery status, push the message to both parties, and notify the receiver. Response is a WS push (no HTTP status / no return value to the sender's SEND frame).

**Auth:** WS → authenticated `Principal` from the handshake. `WebSocketAuthInterceptor` validates `?token=` (JWT), stores `userId` in handshake attributes; `WebSocketHandshakeHandler.determineUser` makes a `Principal` whose `getName()` is the user id. Handler does `senderId = Long.valueOf(principal.getName())`.
**Request:** STOMP payload `SendMessageRequest { receiverId: Long, content: String, messageType = "TEXT", mediaUrl: String, replyToId: Long, replyToStatusId: Long }`.
**Result (pushes, not a return):**
- To receiver `/user/{receiverId}/queue/messages` ← `ChatMessageResponse` (only if not blocked).
- To receiver `/user/{receiverId}/queue/notifications` ← `NotificationDto` (only if not blocked).
- To sender `/user/{senderId}/queue/messages` ← `ChatMessageResponse` (always — echo).
Initial `status` in the response = aggregate from `currentStatus`: DELIVERED if receiver online (and not blocked) else SENT; if blocked, no status rows exist → aggregate falls back to SENT.
**Errors (no HTTP status; surfaced via the messaging error channel / dropped):**
- `receiverId` null → `ApiException(400)` "Receiver id is required".
- TEXT with blank content → `400` "Message content must not be empty"; non-TEXT with blank `mediaUrl` → `400` "Media URL is required for media messages" (`validateContent`).
- sender == receiver → `400` "You cannot message yourself".
- sender / receiver not found → `404`.
- `replyToId` missing / different conversation → `400` (`resolveReplyTo`).

## Flow
```
Client ──► (SEND /app/chat.send  SendMessageRequest)
  ▼
ChatController.sendMessage(request, principal)   senderId = Long.valueOf(principal.getName())
  ▼
ChatService.sendDirectMessage(senderId, request)   @Transactional
  ├─ receiverId null? ──► 400
  ├─ validateContent(messageType, content, mediaUrl)
  ├─ sender = findUser(senderId); receiver = findUser(receiverId)   (missing → 404)
  ├─ sender == receiver? ──► 400 "You cannot message yourself"
  ▼
conversationId = ConversationUtil.dmConversationId(sender, receiver)   // "dm:min:max"
  ▼
build Message{ conversationId, DIRECT, sender, type, content, mediaUrl,
               replyTo = resolveReplyTo(replyToId, conversationId), replyToStatusId }
  ▼
saved = messageRepository.save(message)
  ▼
blocked = blockService.isBlockedBetween(sender, receiver)
  ├─ if !blocked → messageStatusService.createRecipientStatuses(saved, [receiverId])
  │                  (DELIVERED+deliveredAt if presenceService.isOnline(receiver) else SENT)
  ▼
statusPreview = buildStatusPreview(replyToStatusId)
status = messageStatusService.currentStatus(saved.id)   // aggregate
response = toResponse(saved, senderId, conversationId, statusPreview, status.name())
  ▼
if !blocked:
   sendTo(receiverId, response)            → convertAndSendToUser(receiver, /queue/messages, response)
   notificationService.sendNotification(receiverId, conversationId,
        notificationNameFor(receiver, sender), content)   → /user/{receiver}/queue/notifications
  ▼
sendTo(senderId, response)                 → convertAndSendToUser(sender, /queue/messages, response)  (echo)
```
Note: when `blocked`, the message is still saved but no status rows, no delivery to receiver, no notification — only the sender's echo.

## Touched files
- `message/ChatController.java`
- `message/ChatService.java`
- `message/MessageStatusService.java` (`createRecipientStatuses`, `currentStatus`)
- `message/dtos/SendMessageRequest.java` / `message/dtos/ChatMessageResponse.java` / `message/dtos/ReplySummary.java`
- `message/Message.java` / `message/MessageType.java` / `message/ConversationType.java` / `message/MessageRepository.java`
- `notification/NotificationService.java` / `notification/dtos/NotificationDto.java`
- `block/BlockService.java`
- `user/PresenceService.java` (`isOnline`) / `user/UserRepository.java`
- `storage/StorageService.java` (presign mediaUrl)
- `common/ConversationUtil.java` / `common/ApiException.java`
- `config/WebSocketConfig.java` / `auth/WebSocketAuthInterceptor.java` / `auth/WebSocketHandshakeHandler.java`