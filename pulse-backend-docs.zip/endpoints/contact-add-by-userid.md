# `POST /api/v1/contacts/user/{userId}`
> Add a contact directly by target user id, with an optional alias.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`.
**Request:** path var `userId` (Long). Body is OPTIONAL — `@RequestBody(required = false) UpdateAliasRequest` `{ alias }`. If body is null, alias defaults to null; no `@Valid` on this body.
**Success:** `201 CREATED` — `ApiResponse.ok("Contact added.", ContactResponse)`. Alias trimmed via `cleanAlias` (blank → null).
**Errors:**
- Owner id not found → `ApiException(NOT_FOUND)` → `404` ("User not found.").
- Target `userId` not found → `ApiException(NOT_FOUND)` → `404` ("User not found.").
- Adding yourself → `ApiException(BAD_REQUEST)` → `400` ("You cannot add yourself as a contact.").
- Already a contact → `ApiException(CONFLICT)` → `409` ("Contact already added.").
- Non-numeric `userId` → type mismatch → `500` (no dedicated handler). Not logged in → `401`.

## Flow
```
Client ──► POST /api/v1/contacts/user/{userId}  (UpdateAliasRequest {alias}? — optional)
  │
  ▼
ContactController.addContactByUserId(@PathVariable userId, @RequestBody(required=false) request)
  │  alias = (request == null) ? null : request.getAlias()   [optional alias]
  │  SecurityUtil.currentUserId() ──no auth──► 401
  ▼
ContactService.addContactByUserId(ownerId, targetUserId, alias)
  ├─ findUserOrThrow(ownerId) ── empty ──► ApiException(404 "User not found.")
  ├─ findUserOrThrow(targetUserId) ── empty ──► ApiException(404 "User not found.")
  ├─ ensureNotSelf(ownerId, contactUser.id) ── self ──► ApiException(400) → 400
  ├─ ensureNotAlreadyContact(ownerId, contactUser.id)
  │     contactRepository.findByOwner_IdAndContact_Id(...).isPresent() ──► ApiException(409) → 409
  ▼
new Contact{ owner, contact=contactUser, alias=cleanAlias(alias) }
  ▼
contactRepository.save(contact) — inserts row
  ▼
toResponse(savedContact) (block-aware: hides avatar/lastSeen if blocked)
  ▼
ApiResponse.ok("Contact added.", response) ──► 201 JSON
```

## Touched files
- `contact/ContactController.java` — `addContactByUserId()`
- `contact/ContactService.java` — `addContactByUserId`, `findUserOrThrow`, `ensureNotSelf`, `ensureNotAlreadyContact`, `cleanAlias`, `toResponse`
- `contact/ContactRepository.java` — `findByOwner_IdAndContact_Id`, `save`
- `contact/Contact.java`
- `contact/dtos/UpdateAliasRequest.java`, `contact/dtos/ContactResponse.java`
- `user/UserRepository.java` — `findById`
- `block/BlockService.java` — `isBlockedBetween` (via toResponse)
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/GlobalExceptionHandler.java`