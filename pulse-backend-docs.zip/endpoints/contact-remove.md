# `DELETE /api/v1/contacts/{id}`
> Remove a contact owned by the current user.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`.
**Request:** path var `id` (Long, the contact record id). No body.
**Success:** `200 OK` — `ApiResponse.ok("Contact removed.", null)` (data is null; not 204).
**Errors:**
- Contact not found OR not owned by current user → `findByIdAndOwner_Id` empty → `ApiException(NOT_FOUND)` → `404` ("Contact not found.") — ownership-scoped, so deleting someone else's contact reads as 404.
- Non-numeric `id` → `500`. Not logged in → `401`. Unexpected → `500`.

## Flow
```
Client ──► DELETE /api/v1/contacts/{id}
  │
  ▼
ContactController.removeContact(@PathVariable id)
  │  SecurityUtil.currentUserId() ──no auth──► 401
  ▼
ContactService.removeContact(ownerId, contactId)
  ▼
findOwnedContactOrThrow(contactId, ownerId)
  └─ contactRepository.findByIdAndOwner_Id(id, ownerId)  [OWNERSHIP-SCOPED]
       ── empty ──► ApiException(404 "Contact not found.") → 404
  ▼
contactRepository.delete(contact) — removes the row
  ▼
return void
  ▼
ApiResponse.ok("Contact removed.", null) ──► 200 JSON
```

## Touched files
- `contact/ContactController.java` — `removeContact()`
- `contact/ContactService.java` — `removeContact`, `findOwnedContactOrThrow`
- `contact/ContactRepository.java` — `findByIdAndOwner_Id`, `delete`
- `contact/Contact.java`
- `common/SecurityUtil.java`, `common/GlobalExceptionHandler.java`
