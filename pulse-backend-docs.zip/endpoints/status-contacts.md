# `GET /api/v1/statuses`
> List active statuses from the current user's contacts, excluding blocked/blocking users and statuses hidden from this viewer.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`.
**Request:** no path vars, no body.
**Success:** `200 OK` — `ApiResponse.ok(List<StatusResponse>)`. Items are other users' statuses, so `viewCount = null` (not author) and `viewedByMe` reflects whether this viewer has a `StatusView` row. Empty list when no contacts / all excluded.
**Errors:**
- No JWT → **401**
- (No 404/410 — non-visible/expired statuses are filtered, not errored.)

## Flow
```
Client ──► GET /api/v1/statuses
  ▼
StatusController.getContactStatuses()
  ├─ SecurityUtil.currentUserId() ──no auth──► 401
  ▼
StatusService.getContactStatuses(userId)  [@Transactional(readOnly=true)]
  ▼
contactUserIdsOf(userId) → contactRepository.findByOwner_Id(userId) → map contact.getContact().getId()
  ├─ contactIds.isEmpty() ──true──► return List.of()  (200, empty)
  ▼
excludedIds = blockedOrBlockingIds(userId) = blockService.blockedIdsOf(userId) ∪ blockService.blockersOf(userId)
  ▼
visibleAuthorIds = contactIds − excludedIds
  ├─ visibleAuthorIds.isEmpty() ──true──► return List.of()  (200, empty)
  ▼
statusRepository.findActiveByAuthorIds(visibleAuthorIds, Instant.now())
   — SELECT s WHERE s.author.id IN :authorIds AND s.expiresAt > now ORDER BY s.createdAt DESC
  ▼
removeHiddenForViewer(statuses, userId)
  ├─ collect statusIds
  ├─ hiddenStatusRepository.findByViewer_IdAndStatus_IdIn(userId, statusIds) → hiddenIds set
  └─ keep only statuses whose id NOT in hiddenIds
  ▼
toResponses(visibleStatuses, userId) → for each: toResponse(status, userId)
  ├─ isAuthor = false → viewCount = null
  ├─ viewedByMe = statusViewRepository.existsByStatusIdAndViewerId(id, userId)
  ├─ authorAvatarUrl / mediaUrl = storageService.presignedUrl(...)
  ▼
return List<StatusResponse> ──► ApiResponse.ok(list) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `status/StatusController.java` — `getContactStatuses`
- `status/StatusService.java` — `getContactStatuses`, `contactUserIdsOf`, `blockedOrBlockingIds`, `removeHiddenForViewer`, `toResponses`, `toResponse`
- `status/StatusRepository.java` — `findActiveByAuthorIds`
- `status/HiddenStatusRepository.java` — `findByViewer_IdAndStatus_IdIn`
- `status/StatusViewRepository.java` — `existsByStatusIdAndViewerId`
- `contact/ContactRepository.java` — `findByOwner_Id`
- `block/BlockService.java` — `blockedIdsOf`, `blockersOf`
- `status/dtos/StatusResponse.java`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/GlobalExceptionHandler.java`