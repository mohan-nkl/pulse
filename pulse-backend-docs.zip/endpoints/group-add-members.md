# `POST /api/groups/{groupId}/members`
> Admin adds one or more users to a group; already-members are silently skipped, new members are notified in realtime.

**Auth:** requires JWT — actorId via `SecurityUtil.currentUserId()` (else 401). Admin-only.
**Request:** path var `groupId` (`Long`); body `AddMembersRequest` — `memberIds` (`List<Long>`, `@NotEmpty`).
**Success:** `200 OK`, `ApiResponse.ok("Members added", List<GroupMemberResponse>)` — returns the full refreshed member list (`getMembers`).
**Errors:**
- Empty/missing `memberIds` → `MethodArgumentNotValidException` → 400 ("memberIds: At least one member id is required").
- Caller not a member → `requireAdmin`→`requireMembership` → 403 "You are not a member of this group.".
- Caller is a member but not ADMIN → `requireAdmin` → 403 "Only an admin can do that.".
- Group not found → `findGroupOrThrow` → 404 "Group not found".
- A `memberId` to add not found → `findUserOrThrow` → 404 "User not found".
- No JWT → 401.

## Flow
```
Client ──► POST /api/groups/{groupId}/members (AddMembersRequest body)
  ▼
GroupController.addMembers(groupId, request)  ── currentUserId() ──no auth──► 401
  ▼  @Valid ──memberIds empty/null──► MethodArgumentNotValidException → 400
GroupService.addMembers(actorId, groupId, request)   [@Transactional]
  ▼
requireAdmin(actorId, groupId)
  ├─ requireMembership(groupId, actorId) ──not member──► ApiException(403) → 403
  └─ role != ADMIN ──► throw ApiException(403 "Only an admin can do that.") → 403
  ▼
findGroupOrThrow(groupId) → groupRepository.findById ──empty──► ApiException(404 "Group not found") → 404
  ▼
for each memberId in request.memberIds:
  ├─ existsByGroupIdAndUserId(groupId, memberId) ──true (already member)──► skip
  └─ else:
       ├─ findUserOrThrow(memberId) ──not found──► ApiException(404 "User not found") → 404
       ├─ addMembership(group, member, MEMBER) → groupMemberRepository.save
       └─ notifyAddedToGroup(group, member.id)
             └─ messagingTemplate.convertAndSendToUser(memberId, "/queue/group-added", GroupResponse[MEMBER])
  ▼
return getMembers(actorId, groupId)  (re-runs requireMembership + findByGroupId)
  ▼
──► ApiResponse.ok("Members added", List<GroupMemberResponse>) ──► 200 JSON
```

## Touched files
- `group/GroupController.java` — `addMembers`
- `group/GroupService.java` — `addMembers`, `requireAdmin`, `requireMembership`, `findGroupOrThrow`, `findUserOrThrow`, `addMembership`, `notifyAddedToGroup`, `getMembers`, `toMemberResponse`, `countMembers`, `toGroupResponse`
- `group/dtos/AddMembersRequest.java` — request DTO + validation
- `group/dtos/GroupMemberResponse.java`, `group/dtos/GroupResponse.java` — response DTOs
- `group/Group.java`, `group/GroupMember.java`, `group/GroupRole.java`
- `group/GroupRepository.java`, `group/GroupMemberRepository.java`
- `user/UserRepository.java` — `findById`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/ApiException.java`, `common/GlobalExceptionHandler.java`