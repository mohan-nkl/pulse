# `PUT /api/groups/{groupId}`
> Admin renames a group (the new name is trimmed).

**Auth:** requires JWT — actorId via `SecurityUtil.currentUserId()` (else 401). Admin-only.
**Request:** path var `groupId` (`Long`); body `UpdateGroupRequest` — `name` (`@NotBlank`, required).
**Success:** `200 OK`, `ApiResponse.ok("Group updated", GroupResponse)` → `data:{ id, name(trimmed), avatarUrl, myRole:"ADMIN", memberCount, createdAt }`.
**Errors:**
- Missing/blank `name` → `MethodArgumentNotValidException` → 400 ("name: Group name is required").
- Caller not a member → `requireAdmin`→`requireMembership` → 403.
- Caller not ADMIN → `requireAdmin` → 403 "Only an admin can do that.".
- Group not found → `findGroupOrThrow` → 404 "Group not found".
- No JWT → 401.

## Flow
```
Client ──► PUT /api/groups/{groupId} (UpdateGroupRequest body)
  ▼
GroupController.updateGroup(groupId, request)  ── currentUserId() ──no auth──► 401
  ▼  @Valid ──blank name──► MethodArgumentNotValidException → 400
GroupService.updateGroup(actorId, groupId, request)   [@Transactional]
  ▼
requireAdmin(actorId, groupId)
  ├─ requireMembership(groupId, actorId) ──not member──► ApiException(403) → 403
  └─ role != ADMIN ──► ApiException(403 "Only an admin can do that.") → 403
  ▼
findGroupOrThrow(groupId) → groupRepository.findById ──empty──► ApiException(404 "Group not found") → 404
  ▼
group.setName(request.name.trim())
  ▼
groupRepository.save(group) — persist new name
  ▼
countMembers(groupId) → groupMemberRepository.findByGroupId(...).size()
  ▼
toGroupResponse(savedGroup, ADMIN, memberCount)  (myRole hardcoded ADMIN; caller is admin)
  └─ storageService.presignedUrl(group.avatarUrl)
  ▼
return GroupResponse ──► ApiResponse.ok("Group updated", group) ──► 200 JSON
```

## Touched files
- `group/GroupController.java` — `updateGroup`
- `group/GroupService.java` — `updateGroup`, `requireAdmin`, `requireMembership`, `findGroupOrThrow`, `countMembers`, `toGroupResponse`
- `group/dtos/UpdateGroupRequest.java` — request DTO + validation
- `group/dtos/GroupResponse.java` — response DTO
- `group/Group.java`, `group/GroupRole.java`
- `group/GroupRepository.java`, `group/GroupMemberRepository.java`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/ApiException.java`, `common/GlobalExceptionHandler.java`