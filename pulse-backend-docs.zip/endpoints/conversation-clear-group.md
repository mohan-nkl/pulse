# `DELETE /api/conversations/group/{groupId}`
> Clear (hide for me) a group conversation by recording/refreshing a "cleared up to now" timestamp — does NOT delete any messages or affect other members.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`; throws `ApiException(401)` if missing.
**Request:** path var `groupId` (Long). No body, no query params.
**Success:** `200` — `ApiResponse<Void>` with message `"Conversation deleted."` and `data: null`.
**Errors:**
- No / invalid JWT → `401`.
- Unexpected → `500`.
- (Note: unlike `GET /group/{groupId}`, this clear path performs NO group-membership check — it simply upserts a cleared row keyed on `"group:<id>"`.)

## Flow
```
Client ──► DELETE /api/conversations/group/{groupId}
  ▼
ConversationController.clearGroupConversation(groupId)
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(401) → 401
  ▼
ConversationService.clearGroupConversation(userId, groupId)   @Transactional
  ▼
ConversationUtil.groupConversationId(groupId) → "group:<groupId>"
  ▼
clearConversation(userId, conversationId)
  ├─ now = Instant.now()
  ├─ clearedConversationRepository.findByUser_IdAndConversationId(userId, id)
  │     ├─ present ─► cleared.setClearedAt(now) → save (UPDATE)  ──► return
  │     └─ empty   ─► new ClearedConversation{ user=userRepository.getReferenceById(userId),
  │                       conversationId=id, clearedAt=now } → save (INSERT)
  ▼
ApiResponse.ok("Conversation deleted.", null) ──► 200 JSON
```

Notes:
- Per-user, soft hide: messages persist; this only sets `clearedAt`, later consulted by `clearedForMe` in `getGroupConversation` (filters msgs with `createdAt <= clearedAt`) and by `GET /hidden`.
- Idempotent: re-clearing advances the timestamp to `now`.

## Touched files
- message/ConversationController.java
- message/ConversationService.java
- message/ClearedConversationRepository.java
- common/ConversationUtil.java
- common/SecurityUtil.java
- common/GlobalExceptionHandler.java
- message/ClearedConversation.java
- user/UserRepository.java