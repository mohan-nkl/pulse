# `POST /api/auth/signup`
> Register a new account by phone + password and return a freshly minted JWT.

**Auth:** Public. `/api/auth/**` is in `SecurityConfig.PUBLIC_ENDPOINTS` (`permitAll`). No caller id is needed; the user is created here and `JwtUtil.generateToken` mints a token for the new row.

**Request:** JSON body `SignupRequest` (validated with `@Valid`):
- `phone` — String, `@NotBlank("Phone number is required")`
- `password` — String, `@NotBlank("Password is required")`, `@Size(min = 6, "Password must be at least 6 characters")`
- `name` — String, `@NotBlank("Name is required")`

**Success:** HTTP `200 OK` (method returns plain `ApiResponse<AuthResponse>`, so Spring uses 200). Body via `ApiResponse.ok("Account created successfully", result)`:
```
{ "success": true, "message": "Account created successfully",
  "data": { "token": "...", "userId": 1, "phone": "...", "name": "...", "avatarUrl": null },
  "timestamp": "..." }
```
(`avatarUrl` is null for a brand-new user; `ApiResponse` is `@JsonInclude(NON_NULL)`.)

**Errors:**
- Bean validation fails (blank phone/name, blank/short password) → `MethodArgumentNotValidException` → `GlobalExceptionHandler.handleValidation` → **400**, message = joined `field: message` list.
- Phone already exists → `ApiException(CONFLICT, "Phone number is already registered")` → `handleApiException` → **409**.
- Presigned-URL generation only runs if `avatarUrl` is non-null; for signup it is null, so MinIO is not contacted.

## Flow
```
Client ──► POST /api/auth/signup (SignupRequest JSON)
  │
  ▼
JwtAuthFilter.doFilterInternal() — no/any token; public route, just passes through
  │
  ▼
DispatcherServlet → AuthController.signup(@Valid SignupRequest)
  │  @Valid SignupRequest ──(blank phone/name | password<6)──►
  │        MethodArgumentNotValidException → GlobalExceptionHandler.handleValidation → 400
  ▼
AuthService.signup(request)
  ├─ userRepository.existsByPhone(phone)  -- SELECT count(*)>0 FROM users WHERE phone = ?
  │     ──(true)──► throw ApiException(CONFLICT,"Phone number is already registered")
  │                 → GlobalExceptionHandler.handleApiException → 409
  ▼
passwordEncoder.encode(password)            -- BCryptPasswordEncoder hashes the raw password
  ▼
new User(); setPhone/setPasswordHash/setName
  ▼
userRepository.save(user)                   -- INSERT INTO users (phone, password_hash, name, ...)
  ▼
AuthService.buildAuthResponse(savedUser)
  ├─ jwtUtil.generateToken(user.getId())    -- HS signs JWT: subject=userId, iat=now, exp=now+expiration-ms
  ├─ storageService.presignedUrl(avatarUrl) -- avatarUrl is null ──► returns null (no MinIO call)
  ▼
new AuthResponse(token, id, phone, name, avatarUrl=null)
  ▼
return AuthResponse ──► AuthController wraps ApiResponse.ok("Account created successfully", result)
  ▼
200 JSON
```

## Touched files
- `auth/AuthController.java` — `signup()` endpoint, `@Valid`, wraps `ApiResponse.ok`.
- `auth/AuthService.java` — `signup()`, helper `buildAuthResponse()`.
- `auth/JwtUtil.java` — `generateToken(Long userId)` (HMAC-signed JWT).
- `auth/JwtAuthFilter.java` — runs but is a no-op for this public route.
- `storage/StorageService.java` — `presignedUrl()` (returns null for null avatar).
- `config/SecurityConfig.java` — `BCryptPasswordEncoder` bean, `/api/auth/**` permitAll.
- `common/ApiResponse.java` — `ok(message, data)` envelope.
- `common/GlobalExceptionHandler.java` — `handleValidation` (400), `handleApiException` (409).
- `common/ApiException.java` — carries `HttpStatus` + message.
- `auth/dtos/SignupRequest.java`, `auth/dtos/AuthResponse.java` — request/response DTOs.
- `user/UserRepository.java` — `existsByPhone`, `save`; `user/User.java` entity.
