# `GET /api/conversations/summaries`
> Return the last-message timestamp for every conversation (direct + group) the current user participates in — used to sort the chat list.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`; throws `ApiException(401)` if missing.
**Request:** no path vars, no query params.
**Success:** `200` — `ApiResponse<Map<String, Instant>>` keyed by `conversationId` (`"dm:1:2"`, `"group:5"`) → last message `createdAt`. Conversations with no messages yet are absent from the map (aggregate query returns no row for them).
**Errors:**
- No / invalid JWT → `401`.
- Unexpected → `500`.

## Flow
```
Client ──► GET /api/conversations/summaries
  ▼
ConversationController.getConversationSummaries()
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(401) → 401
  ▼
ConversationService.getConversationSummaries(currentUserId)
  ▼
conversationIds = Set<String>:
   ├─ messageRepository.findDirectConversationIdsBySender(currentUserId)        (direct, I sent)
   ├─ recipientStatusRepository.findDirectConversationIdsForRecipient(currentUserId) (direct, I received)
   └─ for each groupMemberRepository.findByUserId(currentUserId):
            conversationIds.add( ConversationUtil.groupConversationId(membership.group.id) )  ("group:<id>")
  ▼
if conversationIds.isEmpty() ──► return {} (empty map)
  ▼
messageRepository.findLastMessageTimes(conversationIds)
   └─ JPQL: SELECT m.conversationId, MAX(m.createdAt) FROM Message m
            WHERE m.conversationId IN :ids GROUP BY m.conversationId
      ▼  List<Object[]> rows of [conversationId(String), lastMessageAt(Instant)]
  ▼
for each row → lastMessageByConversation.put(conversationId, lastMessageAt)
  ▼
return Map<String,Instant>
  ▼
ApiResponse.ok(map) ──► 200 JSON
```

Notes:
- Group conversations are included via group membership (not just messages sent/received), so empty groups still resolve into the id set — but only appear in the map if they have at least one message.
- No block filtering and no cleared/hidden filtering happens here; this is a raw last-activity index.

## Touched files
- message/ConversationController.java
- message/ConversationService.java
- message/MessageRepository.java
- message/MessageRecipientStatusRepository.java
- group/GroupMemberRepository.java
- common/ConversationUtil.java
- common/SecurityUtil.java
- common/GlobalExceptionHandler.java