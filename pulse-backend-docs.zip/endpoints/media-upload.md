# `POST /api/v1/media/upload`
> Upload a multipart file to MinIO and return its stored object key.

**Auth:** Requires JWT. `/api/v1/media/**` is NOT in `SecurityConfig.PUBLIC_ENDPOINTS`, so `anyRequest().authenticated()` applies. `JwtAuthFilter` validates the `Authorization: Bearer <token>` header and populates the `SecurityContext`; without a valid token Spring Security rejects via `JwtAuthenticationEntryPoint` → 401. (Note: the controller/service never call `SecurityUtil.currentUserId()` — the upload is not associated with a user; only authentication is enforced.)

**Request:** `multipart/form-data` with form field `file` (`@RequestParam("file") MultipartFile`). No DTO / bean validation; size and emptiness are checked in code. Max size = 20 MB (`MediaService.MAX_SIZE = 20L * 1024 * 1024`).

**Success:** HTTP `200 OK` via `ResponseEntity.ok(ApiResponse.ok("File uploaded", url))`, where `url` is the MinIO object key (e.g. `media/<uuid>.<ext>`):
```
{ "success": true, "message": "File uploaded",
  "data": "media/3f2a...-....png", "timestamp": "..." }
```

**Errors:**
- No / invalid JWT → `JwtAuthenticationEntryPoint.commence` → **401** (`{"success":false,"message":"Authentication required. Please log in.",...}`).
- Missing `file` param → `MissingServletRequestParameterException` → `GlobalExceptionHandler.handleMissingParam` → **400** ("Required parameter 'file' is missing.").
- `file == null || file.isEmpty()` → `ApiException(BAD_REQUEST, "File must not be empty.")` → **400**.
- `file.getSize() > 20 MB` → `ApiException(BAD_REQUEST, "File must not exceed 20 MB.")` → **400**.
- MinIO `putObject` throws → `ApiException(INTERNAL_SERVER_ERROR, "Failed to upload file.")` → **500**.

## Flow
```
Client ──► POST /api/v1/media/upload (multipart: file=<binary>, Authorization: Bearer <jwt>)
  │
  ▼
JwtAuthFilter.doFilterInternal()
  ├─ extractToken(): "Bearer " header ──(absent)──► token=null
  ├─ jwtUtil.isValid(token) ──(invalid/null)──► context stays unauthenticated
  │
  ▼
Spring Security authorize: anyRequest().authenticated()
  ├─ ──(not authenticated)──► JwtAuthenticationEntryPoint.commence → 401 JSON
  ▼
DispatcherServlet → MediaController.upload(@RequestParam("file") MultipartFile)
  │  ──(no 'file' part)──► MissingServletRequestParameterException
  │                        → GlobalExceptionHandler.handleMissingParam → 400
  ▼
MediaService.upload(file)
  ├─ file == null || file.isEmpty()
  │     ──(true)──► throw ApiException(BAD_REQUEST,"File must not be empty.") → 400
  ├─ file.getSize() > MAX_SIZE (20 MB)
  │     ──(true)──► throw ApiException(BAD_REQUEST,"File must not exceed 20 MB.") → 400
  ▼
StorageService.upload("media", file)
  ├─ (re-checks empty) → buildObjectKey("media", originalFilename)
  │     objectKey = "media/" + UUID.randomUUID() + extension(filename)
  ├─ saveToMinio(objectKey, file)
  │     minioClient.putObject(bucket, objectKey, stream, size, partSize=-1, contentType)
  │     ──(any Exception)──► throw ApiException(500,"Failed to upload file.") → 500
  ▼
return objectKey (String)
  ▼
MediaController wraps ResponseEntity.ok(ApiResponse.ok("File uploaded", url))
  ▼
200 JSON  (data = object key, NOT a presigned URL)
```

## Touched files
- `media/MediaController.java` — `upload()` endpoint, `@RequestParam("file")`, `ResponseEntity` + `ApiResponse.ok`.
- `media/MediaService.java` — `upload()`, `MAX_SIZE` 20 MB guard, empty-file guard.
- `storage/StorageService.java` — `upload()`, `buildObjectKey()`, `saveToMinio()`, `extension()`.
- `auth/JwtAuthFilter.java` — token extraction/validation, populates SecurityContext.
- `auth/JwtAuthenticationEntryPoint.java` — 401 JSON when unauthenticated.
- `config/SecurityConfig.java` — `anyRequest().authenticated()` (media not public).
- `common/ApiResponse.java` — `ok(message, data)`.
- `common/GlobalExceptionHandler.java` — `handleMissingParam` (400), `handleApiException` (400/500).
- `common/ApiException.java` — status + message.
- MinIO `MinioClient` bean (PutObject); `${minio.bucket}` config.