# `POST /api/v1/blocks/{userId}`
> Block another user (idempotent, no self-block).

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (throws `ApiException(401)` if no/invalid auth principal).
**Request:** path var `userId: Long` (the user to block). No request body.
**Success:** `200 OK` — `ApiResponse.ok(null)` → `{ "success": true, "data": null, "timestamp": <Instant> }` (`message`/`data` omitted when null via `@JsonInclude(NON_NULL)`).
**Errors:**
- blocking yourself (`blockerId.equals(blockedId)`) → `ApiException(BAD_REQUEST, "You cannot block yourself.")` → `400`
- blocker user not found → `ApiException(NOT_FOUND, "User not found.")` → `404`
- blocked user not found → `ApiException(NOT_FOUND, "User to block not found.")` → `404`
- not authenticated → `ApiException(UNAUTHORIZED, ...)` → `401`
- All `ApiException`s are rendered by `GlobalExceptionHandler.handleApiException` → `ApiResponse.error(message)` with the exception's status.

Note: already-blocked is **not** an error — it returns silently (idempotent).

## Flow
```
Client ──► POST /api/v1/blocks/{userId} (no body)
  ▼
BlockController.block(userId)
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(UNAUTHORIZED) → 401
  ▼
BlockService.block(blockerId, blockedId)            [@Transactional]
  ├─ blockerId.equals(blockedId) ──true──► throw ApiException(BAD_REQUEST,"You cannot block yourself.") → 400
  ▼
blockRepository.existsByBlocker_IdAndBlocked_Id(blockerId, blockedId) — already blocked?
  ├─ true ──► return (idempotent, no save) ──► 200 {success:true,data:null}
  ▼ false
findUserOrThrow(blockerId,"User not found.")
  └─ userRepository.findById(blockerId) ──empty──► throw ApiException(NOT_FOUND,"User not found.") → 404
  ▼
findUserOrThrow(blockedId,"User to block not found.")
  └─ userRepository.findById(blockedId) ──empty──► throw ApiException(NOT_FOUND,"User to block not found.") → 404
  ▼
new Block(); setBlocker(blocker); setBlocked(blocked)
  ▼
blockRepository.save(block) — insert into blocks (unique constraint on blocker_id+blocked_id; createdAt auto-set)
  ▼
return void ──► BlockController returns ApiResponse.ok(null) ──► 200 JSON
```

## Touched files
- `block/BlockController.java` — `block(@PathVariable Long userId)`
- `block/BlockService.java` — `block`, `findUserOrThrow`
- `block/BlockRepository.java` — `existsByBlocker_IdAndBlocked_Id`, `save`
- `block/Block.java` — entity (unique constraint blocker_id+blocked_id, `@CreationTimestamp`)
- `user/UserRepository.java` — `findById`
- `common/SecurityUtil.java` — `currentUserId`
- `common/ApiResponse.java` — `ok`
- `common/ApiException.java` / `common/GlobalExceptionHandler.java` — error rendering
