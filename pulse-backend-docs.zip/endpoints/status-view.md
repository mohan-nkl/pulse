# `POST /api/v1/statuses/{statusId}/view`
> Record that the current user viewed a status, then push a realtime view event to the author.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (the `viewerId`).
**Request:** path var `statusId` (Long). No body.
**Success:** `200 OK` — `ApiResponse.ok("Viewed.", null)` (`data` is null). Idempotent: author-viewing and duplicate views silently return without creating a new row.
**Errors:**
- Status not found → `ApiException(NOT_FOUND, "Status not found.")` → **404**
- Status expired (`expiresAt < now`) → `ApiException(GONE, "This status has expired.")` → **410**
- Viewer user not found (only reached for a genuinely new non-author view) → `ApiException(NOT_FOUND, "User not found.")` → **404**
- No JWT → **401**

## Flow
```
Client ──► POST /api/v1/statuses/{statusId}/view
  ▼
StatusController.viewStatus(statusId)
  ├─ SecurityUtil.currentUserId() ──no auth──► 401
  ▼
StatusService.viewStatus(viewerId, statusId)  [@Transactional]
  ▼
findStatusOrThrow(statusId) → statusRepository.findById ──empty──► throw ApiException(NOT_FOUND,"Status not found.") → 404
  ├─ status.expiresAt.isBefore(now) ──expired──► throw ApiException(GONE,"This status has expired.") → 410
  ├─ status.author.id == viewerId ──author viewing own──► return (no-op, 200)
  ├─ statusViewRepository.existsByStatusIdAndViewerId(statusId, viewerId) ──already viewed──► return (no-op, 200)
  ▼
findUserOrThrow(viewerId) ──empty──► throw ApiException(NOT_FOUND,"User not found.") → 404
new StatusView{status, viewer}
  ▼
statusViewRepository.save(view) — INSERT into status_views (unique status_id+viewer_id)
  ▼
messagingTemplate.convertAndSendToUser(authorId, "/queue/status-views", new StatusViewEvent(statusId))
   — realtime push to status author
  ▼
return void ──► ApiResponse.ok("Viewed.", null) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `status/StatusController.java` — `viewStatus`
- `status/StatusService.java` — `viewStatus`, `findStatusOrThrow`, `findUserOrThrow`, `STATUS_VIEWS_QUEUE`
- `status/StatusView.java` — entity (unique `status_id`+`viewer_id`)
- `status/StatusViewRepository.java` — `existsByStatusIdAndViewerId`, `save`
- `status/dtos/StatusViewEvent.java` — realtime payload
- `storage/StorageService.java` — (not used here)
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/GlobalExceptionHandler.java`
- `SimpMessagingTemplate` — WebSocket/STOMP delivery to `/user/queue/status-views`