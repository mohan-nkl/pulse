# `POST /api/groups/{groupId}/avatar`
> Admin uploads a group photo; the file is validated, stored in MinIO, and the stored object key is saved on the group.

**Auth:** requires JWT — actorId via `SecurityUtil.currentUserId()` (else 401). Admin-only.
**Request:** path var `groupId` (`Long`); multipart form-data `file` (`@RequestParam("file") MultipartFile`). Constraints: non-empty, size ≤ 5 MB (`MAX_AVATAR_SIZE`), content-type in {image/jpeg, image/png, image/webp}.
**Success:** `200 OK`, `ApiResponse.ok("Group photo updated", GroupResponse)` → `data.avatarUrl` is a fresh presigned GET URL for the uploaded object.
**Errors:**
- Missing `file` param → `MissingServletRequestParameterException` → 400 ("Required parameter 'file' is missing.").
- Caller not member / not ADMIN → `requireAdmin` → 403 ("You are not a member of this group." / "Only an admin can do that.").
- Empty file → `validateAvatar` → 400 "File must not be empty.".
- File > 5 MB → `validateAvatar` → 400 "Group photo must not exceed 5 MB.".
- Wrong content-type → `validateAvatar` → 400 "Group photo must be JPEG, PNG, or WebP.".
- Group not found → `findGroupOrThrow` → 404 "Group not found".
- MinIO put/presign failure → `StorageService` → `ApiException(INTERNAL_SERVER_ERROR)` → 500 ("Failed to upload file." / "Failed to generate file URL.").
- No JWT → 401.

## Flow
```
Client ──► POST /api/groups/{groupId}/avatar (multipart: file)
  ▼
GroupController.updateGroupAvatar(groupId, file)  ── currentUserId() ──no auth──► 401
  ▼  ──file param missing──► MissingServletRequestParameterException → 400
GroupService.updateGroupAvatar(actorId, groupId, file)   [@Transactional]
  ▼
requireAdmin(actorId, groupId)
  ├─ requireMembership(groupId, actorId) ──not member──► ApiException(403) → 403
  └─ role != ADMIN ──► ApiException(403 "Only an admin can do that.") → 403
  ▼
validateAvatar(file)
  ├─ null/empty ──► ApiException(400 "File must not be empty.") → 400
  ├─ size > 5 MB ──► ApiException(400 "Group photo must not exceed 5 MB.") → 400
  └─ contentType not in [jpeg,png,webp] ──► ApiException(400 "...JPEG, PNG, or WebP.") → 400
  ▼
findGroupOrThrow(groupId) → groupRepository.findById ──empty──► ApiException(404) → 404
  ▼
storageService.upload("groups", file)
  ├─ buildObjectKey: "groups/" + UUID + extension
  └─ saveToMinio: minioClient.putObject(...) ──fail──► ApiException(500 "Failed to upload file.") → 500
  ▼ returns objectKey
group.setAvatarUrl(avatarKey)  (stores the object KEY, not a URL)
  ▼
groupRepository.save(group)
  ▼
countMembers(groupId) → findByGroupId(...).size()
  ▼
toGroupResponse(savedGroup, ADMIN, memberCount)
  └─ storageService.presignedUrl(avatarKey) → minioClient.getPresignedObjectUrl ──fail──► ApiException(500 "Failed to generate file URL.") → 500
  ▼
return GroupResponse ──► ApiResponse.ok("Group photo updated", group) ──► 200 JSON
```

## Touched files
- `group/GroupController.java` — `updateGroupAvatar`
- `group/GroupService.java` — `updateGroupAvatar`, `validateAvatar`, `requireAdmin`, `requireMembership`, `findGroupOrThrow`, `countMembers`, `toGroupResponse` (`ALLOWED_AVATAR_TYPES`, `MAX_AVATAR_SIZE`)
- `group/dtos/GroupResponse.java` — response DTO
- `group/Group.java` (`avatarUrl`), `group/GroupRole.java`
- `group/GroupRepository.java`, `group/GroupMemberRepository.java`
- `storage/StorageService.java` — `upload`, `buildObjectKey`, `saveToMinio`, `presignedUrl`, `generatePresignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/ApiException.java`, `common/GlobalExceptionHandler.java`