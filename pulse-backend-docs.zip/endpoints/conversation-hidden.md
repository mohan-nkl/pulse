# `GET /api/conversations/hidden`
> Return the ids of conversations the user cleared that have had NO newer messages since — i.e. conversations that should stay hidden from the chat list.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`; throws `ApiException(401)` if missing.
**Request:** no path vars, no query params.
**Success:** `200` — `ApiResponse<List<String>>` of `conversationId`s still hidden (cleared with no newer message). A cleared conversation that received a new message after the clear timestamp is NOT returned (it should resurface in the list).
**Errors:**
- No / invalid JWT → `401`.
- Unexpected → `500`.

## Flow
```
Client ──► GET /api/conversations/hidden
  ▼
ConversationController.getHiddenConversations()
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(401) → 401
  ▼
ConversationService.getHiddenConversations(userId)
  ▼
clearedList = clearedConversationRepository.findByUser_Id(userId)
  ├─ clearedList.isEmpty() ──► return [] (empty list)
  ▼
build:
   ├─ clearedIds : Set<String> of conversationId
   └─ clearedAtById : Map<conversationId, clearedAt>
  ▼
lastMessageById = {} ; for each row in messageRepository.findLastMessageTimes(clearedIds):
        put(conversationId, MAX(createdAt))      (conversations with no messages → absent → null below)
  ▼
hidden = []
for each conversationId in clearedIds:
   ├─ clearedAt = clearedAtById.get(id)
   ├─ lastMessageAt = lastMessageById.get(id)   (may be null)
   ├─ hasNewerMessage = (lastMessageAt != null && lastMessageAt.isAfter(clearedAt))
   └─ if !hasNewerMessage ──► hidden.add(id)     (no activity since clear → keep hidden)
       else                ──► omitted           (newer message → resurface, not hidden)
  ▼
return List<String> hidden
  ▼
ApiResponse.ok(list) ──► 200 JSON
```

Notes:
- Pairs with `DELETE /api/conversations/...` (clear), which upserts the `ClearedConversation.clearedAt` row consulted here.
- A cleared conversation with zero messages (lastMessageAt == null) counts as hidden.

## Touched files
- message/ConversationController.java
- message/ConversationService.java
- message/ClearedConversationRepository.java
- message/MessageRepository.java
- common/SecurityUtil.java
- common/GlobalExceptionHandler.java
- message/ClearedConversation.java