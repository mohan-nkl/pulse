# `GET /api/v1/statuses/mine`
> List the current user's own active (non-expired) statuses, oldest first.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`.
**Request:** no path vars, no body.
**Success:** `200 OK` — `ApiResponse.ok(List<StatusResponse>)`. Each item is the author's own status, so `viewCount` is populated (count of views) and `viewedByMe = false`.
**Errors:**
- No JWT → **401**
- (No 404/410 here — expired statuses are simply filtered out by the query, not error.)

## Flow
```
Client ──► GET /api/v1/statuses/mine
  ▼
StatusController.getMyStatuses()
  ├─ SecurityUtil.currentUserId() ──no auth──► 401
  ▼
StatusService.getMyStatuses(userId)  [@Transactional(readOnly=true)]
  ▼
statusRepository.findByAuthorIdAndExpiresAtAfterOrderByCreatedAtAsc(userId, Instant.now())
   — SELECT statuses WHERE author_id = userId AND expires_at > now ORDER BY created_at ASC
   — (expired statuses excluded automatically)
  ▼
toResponses(statuses, userId) → for each: toResponse(status, userId)
  ├─ isAuthor = true → viewCount = statusViewRepository.countByStatusId(id)
  ├─ viewedByMe = false
  ├─ authorAvatarUrl = storageService.presignedUrl(...)
  └─ mediaUrl = storageService.presignedUrl(...)
  ▼
return List<StatusResponse> ──► ApiResponse.ok(list) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `status/StatusController.java` — `getMyStatuses`
- `status/StatusService.java` — `getMyStatuses`, `toResponses`, `toResponse`
- `status/StatusRepository.java` — `findByAuthorIdAndExpiresAtAfterOrderByCreatedAtAsc`
- `status/StatusViewRepository.java` — `countByStatusId`
- `status/dtos/StatusResponse.java`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/GlobalExceptionHandler.java`