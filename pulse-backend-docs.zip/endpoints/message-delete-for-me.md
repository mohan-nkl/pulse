# `DELETE /api/messages/{messageId}/for-me`
> Hide a single message from the calling user only (a per-user soft-hide); the message stays visible for everyone else.

**Auth:** REST → `SecurityUtil.currentUserId()` reads the authenticated principal from the `SecurityContext`; throws `ApiException(401)` if not logged in / principal is not a `Long`.
**Request:**
- Path var: `messageId` (Long).
- No body.
**Result:** `200` with `ApiResponse.ok(null)` (envelope `{ success, message, data: null }`). No WS push (purely client-local hide — no event is broadcast).
**Errors:**
- Message not found → `ApiException(404)` "Message not found." (`MessageActionService.findMessageOrThrow`).
- Caller not a participant of the conversation → `ApiException(403)` "You are not part of this conversation." (DM) / "You are not a member of this group." (group) (`ensureMember`).
- Already hidden for this user → no error, early return (idempotent; unique constraint on `(message_id, user_id)`).
- Any → `GlobalExceptionHandler.handleApiException` maps `ApiException.status`; unexpected → `500`.

## Flow
```
Client ──► DELETE /api/messages/{messageId}/for-me
  ▼
MessageActionController.deleteForMe(messageId)
  ├─ currentUserId = SecurityUtil.currentUserId()
  ▼
MessageActionService.deleteForMe(userId, messageId)   @Transactional
  ▼
findMessageOrThrow(messageId)  → messageRepository.findById  (empty → 404)
  ▼
ensureMember(userId, message.getConversationId())
  ├─ ConversationUtil.isDirect → dmParticipants(): userId must be one of the two ──no──► 403
  └─ ConversationUtil.isGroup  → groupMemberRepository.existsByGroupIdAndUserId ──false──► 403
  ▼
deletedMessageRepository.existsByMessage_IdAndUser_Id(messageId, userId)
  ├─ true  ──► return (idempotent, nothing saved)
  └─ false
       ▼
     new DeletedMessage{ message, user = userRepository.getReferenceById(userId) }
       ▼
     deletedMessageRepository.save(hidden)
  ▼
Controller returns ApiResponse.ok(null)  → 200
```

## Touched files
- `message/MessageActionController.java`
- `message/MessageActionService.java`
- `message/DeletedMessage.java`
- `message/DeletedMessageRepository.java`
- `message/Message.java` / `message/MessageRepository.java`
- `group/GroupMemberRepository.java`
- `user/UserRepository.java` (`getReferenceById`)
- `common/SecurityUtil.java`
- `common/ConversationUtil.java`
- `common/ApiException.java` / `common/ApiResponse.java` / `common/GlobalExceptionHandler.java`