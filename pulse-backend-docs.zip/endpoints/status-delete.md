# `DELETE /api/v1/statuses/{statusId}`
> Delete the current user's own status, cascading its view and hidden-viewer rows.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (the `authorId`).
**Request:** path var `statusId` (Long). No body.
**Success:** `200 OK` — `ApiResponse.ok("Status deleted.", null)` (`data` null).
**Errors:**
- Status not found OR caller is not the author → `ApiException(NOT_FOUND, "Status not found or you are not the author.")` → **404** (single combined check via `findByIdAndAuthorId`; non-authors get 404, not 403).
- No JWT → **401**

## Flow
```
Client ──► DELETE /api/v1/statuses/{statusId}
  ▼
StatusController.deleteStatus(statusId)
  ├─ SecurityUtil.currentUserId() ──no auth──► 401
  ▼
StatusService.deleteStatus(authorId, statusId)  [@Transactional]
  ▼
statusRepository.findByIdAndAuthorId(statusId, authorId)
   — SELECT s WHERE s.id = :id AND s.author.id = :authorId
  ├─ Optional.isEmpty() ──not found / not author──► throw ApiException(NOT_FOUND,"Status not found or you are not the author.") → 404
  ▼
statusViewRepository.deleteByStatusId(statusId)      — DELETE status_views for this status
  ▼
hiddenStatusRepository.deleteByStatus_Id(statusId)   — DELETE hidden_statuses for this status
  ▼
statusRepository.delete(status)                      — DELETE the status row
  ▼
return void ──► ApiResponse.ok("Status deleted.", null) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `status/StatusController.java` — `deleteStatus`
- `status/StatusService.java` — `deleteStatus`
- `status/StatusRepository.java` — `findByIdAndAuthorId`, `delete`
- `status/StatusViewRepository.java` — `deleteByStatusId` (cascade views)
- `status/HiddenStatusRepository.java` — `deleteByStatus_Id` (cascade hidden rows)
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/GlobalExceptionHandler.java`