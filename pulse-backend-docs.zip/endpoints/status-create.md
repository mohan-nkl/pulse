# `POST /api/v1/statuses`
> Create a 24-hour status (story) with text and/or media, hidden from blocked/blocking users.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (becomes `authorId`).
**Request:** JSON body `@Valid CreateStatusRequest` — `content` (`@Size(min=1,max=700)`, optional), `mediaUrl` (optional, the object key from `/upload`). At least one of text/media is required (checked in service, not bean validation).
**Success:** `201 CREATED` — `ApiResponse.ok("Status posted.", StatusResponse)`. `StatusResponse` = `{ id, authorId, authorName, authorAvatarUrl, content, mediaUrl(presigned), createdAt, expiresAt, viewCount, viewedByMe }`. For the author response, `viewCount = 0` (counted) and `viewedByMe = false`.
**Errors:**
- No text and no media → `ApiException(BAD_REQUEST, "A status must have text, an image, or both.")` → **400**
- `content` present but length out of `[1,700]` → `MethodArgumentNotValidException` → **400** (validation handler)
- Author user not found → `ApiException(NOT_FOUND, "User not found.")` → **404**
- No JWT → **401**

## Flow
```
Client ──► POST /api/v1/statuses (CreateStatusRequest JSON)
  ▼
[@Valid] CreateStatusRequest ──size violation──► MethodArgumentNotValidException → 400
  ▼
StatusController.createStatus(request)
  ├─ SecurityUtil.currentUserId() ──no auth──► 401
  ▼
StatusService.createStatus(authorId, request)  [@Transactional]
  ├─ hasText = content != null && !blank
  ├─ hasMedia = mediaUrl != null && !blank
  ├─ !hasText && !hasMedia ──true──► throw ApiException(BAD_REQUEST,"A status must have text, an image, or both.") → 400
  ▼
findUserOrThrow(authorId) → userRepository.findById ──empty──► throw ApiException(NOT_FOUND,"User not found.") → 404
  ▼
content = trim if hasText ; mediaUrl = trim if hasMedia
expiresAt = Instant.now().plus(24, HOURS)
new Status{author, content, mediaUrl, expiresAt}
  ▼
statusRepository.save(status) — INSERT into statuses, createdAt via @CreationTimestamp
  ▼
hideFromBlockedViewers(savedStatus, authorId)
  ├─ blockedOrBlockingIds(authorId) = blockService.blockedIdsOf(authorId) ∪ blockService.blockersOf(authorId)
  ├─ empty ──► return (no hidden rows)
  └─ else for each viewerId: new HiddenStatus{status, viewer=getReferenceById(viewerId)}
        ▼
        hiddenStatusRepository.saveAll(rows) — INSERT into hidden_statuses
  ▼
toResponse(savedStatus, authorId)
  ├─ isAuthor = true → viewCount = statusViewRepository.countByStatusId(id) (0)
  ├─ viewedByMe = false (only computed when !isAuthor)
  ├─ authorAvatarUrl = storageService.presignedUrl(author.avatarUrl)
  └─ mediaUrl = storageService.presignedUrl(status.mediaUrl)
  ▼
return StatusResponse ──► ApiResponse.ok("Status posted.", response)
  ▼
ResponseEntity.status(CREATED).body(...) ──► 201 JSON
```

## Touched files
- `status/StatusController.java` — `createStatus`
- `status/StatusService.java` — `createStatus`, `hideFromBlockedViewers`, `blockedOrBlockingIds`, `toResponse`, `findUserOrThrow`
- `status/Status.java` — entity (`expiresAt`, `@CreationTimestamp createdAt`)
- `status/HiddenStatus.java` — entity for blocked-viewer hiding
- `status/dtos/CreateStatusRequest.java` — input + `@Size`
- `status/dtos/StatusResponse.java` — output
- `status/StatusRepository.java` / `status/HiddenStatusRepository.java` / `status/StatusViewRepository.java` — persistence
- `block/BlockService.java` — `blockedIdsOf`, `blockersOf`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/GlobalExceptionHandler.java`, `common/ApiResponse.java`