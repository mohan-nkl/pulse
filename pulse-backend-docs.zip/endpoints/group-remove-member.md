# `DELETE /api/groups/{groupId}/members/{userId}`
> Admin removes another member from the group; an admin cannot remove themselves (must use leave).

**Auth:** requires JWT — actorId via `SecurityUtil.currentUserId()` (else 401). Admin-only.
**Request:** path vars `groupId` (`Long`), `userId` (`Long`, the target to remove). No body.
**Success:** `200 OK`, `ApiResponse.ok("Member removed", List<GroupMemberResponse>)` — refreshed member list.
**Errors:**
- Caller not a member → `requireAdmin`→`requireMembership` → 403.
- Caller not ADMIN → `requireAdmin` → 403 "Only an admin can do that.".
- Removing yourself (`userId == actorId`) → `ApiException(BAD_REQUEST)` → 400 "To leave the group, use leave — not remove.".
- Target not a member → `requireMembership` → 403 "You are not a member of this group.".
- No JWT → 401.

## Flow
```
Client ──► DELETE /api/groups/{groupId}/members/{userId}
  ▼
GroupController.removeMember(groupId, userId)  ── currentUserId() ──no auth──► 401
  ▼
GroupService.removeMember(actorId, groupId, targetUserId)   [@Transactional]
  ▼
requireAdmin(actorId, groupId)
  ├─ requireMembership(groupId, actorId) ──not member──► ApiException(403) → 403
  └─ role != ADMIN ──► ApiException(403 "Only an admin can do that.") → 403
  ▼
targetUserId.equals(actorId)? ──yes──► throw ApiException(400 "To leave the group, use leave — not remove.") → 400
  ▼ no
requireMembership(groupId, targetUserId) ──target not member──► ApiException(403 "You are not a member...") → 403
  ▼
groupMemberRepository.delete(target) — remove membership row
  ▼
return getMembers(actorId, groupId)  (requireMembership + findByGroupId → responses)
  ▼
──► ApiResponse.ok("Member removed", List<GroupMemberResponse>) ──► 200 JSON
```

## Touched files
- `group/GroupController.java` — `removeMember`
- `group/GroupService.java` — `removeMember`, `requireAdmin`, `requireMembership`, `getMembers`, `toMemberResponse`
- `group/dtos/GroupMemberResponse.java` — response DTO
- `group/GroupMember.java`, `group/GroupRole.java`
- `group/GroupMemberRepository.java` — `findByGroupIdAndUserId`, `delete`, `findByGroupId`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/ApiException.java`