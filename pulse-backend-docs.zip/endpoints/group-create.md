# `POST /api/groups`
> Create a new group; the creator becomes its first ADMIN and any initial members are added.

**Auth:** requires JWT — actorId via `SecurityUtil.currentUserId()` (else 401 "You are not logged in.").
**Request:** body `CreateGroupRequest` — `name` (`@NotBlank`, required), `memberIds` (`List<Long>`, optional/nullable).
**Success:** `200 OK`, `ApiResponse.ok("Group created", GroupResponse)` → `{ success:true, message:"Group created", data:{ id, name, avatarUrl, myRole:"ADMIN", memberCount, createdAt }, timestamp }`.
**Errors:**
- Missing/blank `name` → `MethodArgumentNotValidException` → 400 ("name: Group name is required").
- Creator user not found → `findUserOrThrow` → `ApiException(NOT_FOUND)` → 404 "User not found".
- An entry in `memberIds` not found → `findUserOrThrow` → `ApiException(NOT_FOUND)` → 404 "User not found".
- No JWT/principal → `ApiException(UNAUTHORIZED)` → 401.

## Flow
```
Client ──► POST /api/groups (CreateGroupRequest body)
  ▼
GroupController.createGroup()  ── SecurityUtil.currentUserId() ──no auth──► ApiException(401) → 401
  ▼  @Valid ──invalid──► MethodArgumentNotValidException → 400
GroupService.createGroup(creatorId, request)   [@Transactional]
  ▼
findUserOrThrow(creatorId) → userRepository.findById ──empty──► ApiException(404 "User not found")
  ▼
new Group(); setName(request.name); setCreatedBy(creator)
  ▼
groupRepository.save(group) — persist group row
  ▼
addMembership(savedGroup, creator, ADMIN) → groupMemberRepository.save — creator becomes ADMIN
  ▼
addInitialMembers(savedGroup, creatorId, request.memberIds)
  ├─ memberIds == null ──► skip
  └─ for each memberId:
       ├─ isCreator (== creatorId) ──► skip
       ├─ existsByGroupIdAndUserId already member ──► skip
       └─ else: findUserOrThrow(memberId) ──not found──► ApiException(404) → 404
              ▼
            addMembership(group, member, MEMBER) → groupMemberRepository.save
              ▼
            notifyAddedToGroup(group, member.id)
              └─ messagingTemplate.convertAndSendToUser(memberId, "/queue/group-added", GroupResponse[MEMBER])
  ▼
countMembers(savedGroup.id) → groupMemberRepository.findByGroupId(...).size()
  ▼
toGroupResponse(savedGroup, ADMIN, memberCount)
  └─ storageService.presignedUrl(group.avatarUrl)  (null avatar → null URL)
  ▼
return GroupResponse ──► ApiResponse.ok("Group created", group) ──► 200 JSON
```

## Touched files
- `group/GroupController.java` — `createGroup`
- `group/GroupService.java` — `createGroup`, `findUserOrThrow`, `addMembership`, `addInitialMembers`, `notifyAddedToGroup`, `countMembers`, `toGroupResponse`
- `group/dtos/CreateGroupRequest.java` — request DTO + validation
- `group/dtos/GroupResponse.java` — response DTO
- `group/Group.java`, `group/GroupMember.java`, `group/GroupRole.java` — entities/enum
- `group/GroupRepository.java`, `group/GroupMemberRepository.java` — persistence
- `user/UserRepository.java` — `findById`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/ApiException.java`, `common/GlobalExceptionHandler.java`