# `POST /api/groups/{groupId}/leave`
> Current user leaves the group; if that empties the group it is deleted, and if no admin remains the earliest-joined member is auto-promoted.

**Auth:** requires JWT — actorId via `SecurityUtil.currentUserId()` (else 401).
**Request:** path var `groupId` (`Long`). No body.
**Success:** `200 OK`, `ApiResponse.ok("You left the group", null)` → `{ success:true, message:"You left the group", data omitted (NON_NULL), timestamp }`.
**Errors:**
- Caller not a member → `requireMembership` → 403 "You are not a member of this group.".
- No JWT → 401.

## Flow
```
Client ──► POST /api/groups/{groupId}/leave
  ▼
GroupController.leaveGroup(groupId)  ── currentUserId() ──no auth──► 401
  ▼
GroupService.leaveGroup(actorId, groupId)   [@Transactional]
  ▼
requireMembership(groupId, actorId)
  └─ groupMemberRepository.findByGroupIdAndUserId ──empty──► ApiException(403 "You are not a member...") → 403
  ▼
groupMemberRepository.delete(membership) — remove caller's membership
  ▼
remainingMembers = groupMemberRepository.findByGroupId(groupId)
  ▼
remainingMembers.isEmpty()? ──yes──► groupRepository.deleteById(groupId) — delete the now-empty group; return
  ▼ no
anyAdmin(remainingMembers)? — scan roles for ADMIN
  ├─ true ──► nothing more to do
  └─ false ──► promoteEarliestMemberToAdmin(remainingMembers)
                 ├─ pick member with earliest joinedAt (member.joinedAt.isBefore(...))
                 ├─ earliest.setRole(ADMIN)
                 └─ groupMemberRepository.save(earliest)
  ▼
(void) ──► ApiResponse.ok("You left the group", null) ──► 200 JSON
```

## Touched files
- `group/GroupController.java` — `leaveGroup`
- `group/GroupService.java` — `leaveGroup`, `requireMembership`, `anyAdmin`, `promoteEarliestMemberToAdmin`
- `group/GroupMember.java` (`joinedAt`, `role`), `group/GroupRole.java`
- `group/GroupRepository.java` — `deleteById`
- `group/GroupMemberRepository.java` — `findByGroupIdAndUserId`, `delete`, `findByGroupId`, `save`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/ApiException.java`
