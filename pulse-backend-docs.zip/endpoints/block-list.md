# `GET /api/v1/blocks`
> List all users the caller has blocked, with contact-alias display names.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (throws `ApiException(401)` if no/invalid auth principal).
**Request:** no path vars, no query params, no body.
**Success:** `200 OK` — `ApiResponse.ok(List<BlockedUserResponse>)`:
```
{ "success": true,
  "data": [ { "userId": Long,
              "name": String|null,       // saved alias only — null if no/blank alias
              "phone": String,           // blocked user's phone
              "avatarUrl": String|null,  // presigned via StorageService
              "blockedAt": Instant } ],  // block.createdAt
  "timestamp": Instant }
```
Important: `name` is the caller's **saved alias** for the blocked user (alias-or-null), never the registered user name. Phone is always the blocked user's number.
**Errors:**
- not authenticated → `ApiException(UNAUTHORIZED, ...)` → `401`
- `ApiException`s rendered by `GlobalExceptionHandler.handleApiException`.

## Flow
```
Client ──► GET /api/v1/blocks
  ▼
BlockController.listBlocked()
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(UNAUTHORIZED) → 401
  ▼
BlockService.listBlocked(blockerId)                 [@Transactional(readOnly)]
  ▼
blockRepository.findByBlocker_Id(blockerId) — List<Block> caller blocked
  ▼
for each Block:  toBlockedUserResponse(block, blockerId)
  ├─ blockedUser = block.getBlocked()
  ├─ avatarUrl = storageService.presignedUrl(blockedUser.getAvatarUrl())
  ├─ displayName = savedAlias(blockerId, blockedUser.getId())
  │     └─ contactRepository.findByOwner_IdAndContact_Id(blockerId, blockedUserId)
  │          .map(Contact::getAlias)
  │          .filter(alias != null && !alias.isBlank())
  │          .orElse(null)              ◄── alias-or-null, never registered name
  └─ new BlockedUserResponse(id, displayName, phone, avatarUrl, block.createdAt)
  ▼
return List<BlockedUserResponse> ──► ApiResponse.ok(list) ──► 200 JSON
```

## Touched files
- `block/BlockController.java` — `listBlocked()`
- `block/BlockService.java` — `listBlocked`, `toBlockedUserResponse`, `savedAlias`
- `block/BlockRepository.java` — `findByBlocker_Id`
- `block/dtos/BlockedUserResponse.java` — response DTO (`userId,name,phone,avatarUrl,blockedAt`)
- `contact/ContactRepository.java` — `findByOwner_IdAndContact_Id`
- `contact/Contact.java` — `getAlias`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java` — `currentUserId`
- `common/ApiResponse.java` — `ok`
- `common/GlobalExceptionHandler.java` — error rendering
