# `GET /api/v1/profile`
> Return the authenticated caller's own profile (with a presigned avatar URL).

**Auth:** requires JWT — caller id via `SecurityUtil.currentUserId()` (set by JwtAuthFilter).
**Request:** no path vars, no query params, no body.
**Success:** `200 OK` — `ApiResponse.ok(data)` → `{ success: true, message: null (omitted by JsonInclude.NON_NULL), data: UserProfileResponse, timestamp }`. `UserProfileResponse` = `{ id, name, about, avatarUrl, lastSeen, createdAt }`. `avatarUrl` is a presigned MinIO URL or `null` when no avatar stored.
**Errors:**
- No / invalid auth → `SecurityUtil.currentUserId()` throws `ApiException(UNAUTHORIZED, "You are not logged in." | "Could not identify the current user.")` → `GlobalExceptionHandler.handleApiException` → `401`.
- User row missing → `UserProfileService.findById` throws `ApiException(NOT_FOUND, "User not found.")` → `404`.
- Presign failure → `StorageService.generatePresignedUrl` throws `ApiException(INTERNAL_SERVER_ERROR, "Failed to generate file URL.")` → `500`.

## Flow
```
Client ──► GET /api/v1/profile
  │
  ▼
DispatcherServlet → UserProfileController.getMyProfile()
  ├─ SecurityUtil.currentUserId() ──(auth null / !authenticated / principal !Long)──► throw ApiException(401) → GlobalExceptionHandler → 401
  ▼
UserProfileService.getMyProfile(userId)
  ▼
findById(userId) → userRepository.findById(userId)
  ├─ empty ──► throw ApiException(NOT_FOUND, "User not found.") → GlobalExceptionHandler → 404
  ▼
toResponse(user)
  ├─ storageService.presignedUrl(user.getAvatarUrl())
  │     ├─ key null/blank ──► return null
  │     └─ else generatePresignedUrl(key) → MinIO getPresignedObjectUrl (GET, expiryMinutes)
  │             └─(MinIO error)──► throw ApiException(500, "Failed to generate file URL.") → 500
  ▼
new UserProfileResponse(id, name, about, avatarUrl, lastSeen, createdAt)
  ▼
ApiResponse.ok(response) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `user/UserProfileController.java` — `getMyProfile()`
- `user/UserProfileService.java` — `getMyProfile(Long)`, helpers `findById(Long)`, `toResponse(User)`
- `user/User.java` — entity (id, name, about, avatarUrl, lastSeen, createdAt)
- `user/UserRepository.java` — `findById`
- `storage/StorageService.java` — `presignedUrl(String)` → `generatePresignedUrl(String)` (MinIO)
- `user/dtos/UserProfileResponse.java` — response DTO
- `common/ApiResponse.java` — envelope `ok(data)`
- `common/SecurityUtil.java` — `currentUserId()`
- `common/GlobalExceptionHandler.java` — `handleApiException`
- `common/ApiException.java` — error type