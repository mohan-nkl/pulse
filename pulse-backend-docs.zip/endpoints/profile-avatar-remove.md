# `DELETE /api/v1/profile/avatar`
> Clear the caller's stored avatar key and return the refreshed (avatar-less) profile.

**Auth:** requires JWT — caller id via `SecurityUtil.currentUserId()` (set by JwtAuthFilter).
**Request:** no path vars, no query params, no body.
**Success:** `200 OK` — `ApiResponse.ok("Photo removed.", UserProfileResponse)` → `{ success: true, message: "Photo removed.", data: { id, name, about, avatarUrl: null, lastSeen, createdAt }, timestamp }`. Note: after clearing the key, `toResponse` calls `presignedUrl(null)` which returns `null`, so `avatarUrl` is `null`.
**Errors:**
- No / invalid auth → `ApiException(401)` → `401`.
- User row missing → `ApiException(NOT_FOUND, "User not found.")` → `404`.

(No MinIO object deletion is performed; only the DB key is set to null. `presignedUrl(null)` short-circuits to `null`, so no MinIO call and no presign error path here.)

## Flow
```
Client ──► DELETE /api/v1/profile/avatar
  │
  ▼
DispatcherServlet → UserProfileController.removeAvatar()
  ├─ SecurityUtil.currentUserId() ──(unauthenticated)──► throw ApiException(401) → 401
  ▼
UserProfileService.removeAvatar(userId)
  ▼
findById(userId) → userRepository.findById(userId)
  ├─ empty ──► throw ApiException(NOT_FOUND, "User not found.") → 404
  ▼
user.setAvatarUrl(null)
  ▼
userRepository.save(user)  — persist cleared avatar key
  ▼
toResponse(savedUser)
  └─ storageService.presignedUrl(null) ──► returns null (no MinIO call)
  ▼
new UserProfileResponse(id, name, about, null, lastSeen, createdAt)
  ▼
ApiResponse.ok("Photo removed.", response) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `user/UserProfileController.java` — `removeAvatar()`
- `user/UserProfileService.java` — `removeAvatar(Long)`, helpers `findById`, `toResponse`
- `user/User.java` — `setAvatarUrl(null)`
- `user/UserRepository.java` — `findById`, `save`
- `storage/StorageService.java` — `presignedUrl(String)` (returns null for null key)
- `user/dtos/UserProfileResponse.java` — response DTO
- `common/ApiResponse.java` — `ok(message, data)`
- `common/SecurityUtil.java` — `currentUserId()`
- `common/GlobalExceptionHandler.java` — `handleApiException`
