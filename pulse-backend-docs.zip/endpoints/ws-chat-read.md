# `STOMP SEND /app/chat.read`
> A recipient marks a conversation as read: flip their non-READ status rows to READ, push aggregated status updates to each message's sender, and clear the recipient's in-memory unread counter for that conversation. Response is a WS push (no HTTP status).

**Auth:** WS → authenticated `Principal` from the handshake (`recipientId = Long.valueOf(principal.getName())`).
**Request:** STOMP payload `ConversationAckRequest { conversationId: String }`. Unlike `chat.delivered`, a **null `conversationId` is a no-op** (read requires a specific conversation).
**Result (pushes, not a return):**
- For each affected message, one `MessageStatusUpdate { messageId, conversationId, status, deliveredCount, readCount, totalRecipients }` to the message SENDER at `/user/{senderId}/queue/status`.
- Side effect (no push): `NotificationService.clearUnread(recipientId, conversationId)` removes that conversation's entry from the recipient's in-memory unread map.
**Behavior / edge cases (no HTTP status):**
- `conversationId == null` → return immediately (no rows touched, but `clearUnread` is still called afterwards in the controller with a null conversationId, which is a harmless no-op on the map).
- Selects rows with status != READ for this recipient+conversation. For each: if `deliveredAt` was null, set it to now (covers SENT→READ skipping DELIVERED); set status = READ and `readAt = now`.
- Empty selection → early return (no push), but `clearUnread` still runs.
- Aggregate per message via `aggregate(total, delivered, read)`.

## Flow
```
Client ──► (SEND /app/chat.read  ConversationAckRequest{ conversationId })
  ▼
ChatController.markRead(request, principal)   recipientId = Long.valueOf(principal.getName())
  ├─► MessageStatusService.markRead(recipientId, conversationId)   @Transactional
  │     ▼
  │   conversationId == null ? ──yes──► return (no-op)
  │     ▼ no
  │   myRows = statusRepository.findByRecipient_IdAndMessage_ConversationIdAndStatusNot(
  │                 recipientId, conversationId, READ)
  │     ▼
  │   myRows.isEmpty() ? ──yes──► return (no push)
  │     ▼ no
  │   for each row: if deliveredAt==null → deliveredAt=now; status=READ; readAt=now
  │   statusRepository.saveAll(myRows)
  │     ▼
  │   notifySenders(myRows)
  │     ├─ messageIds = distinct ids; allRows = findByMessage_IdIn(messageIds); group by messageId
  │     └─ per message: aggregate(total, delivered, read) →
  │          MessageStatusUpdate(messageId, conversationId, status, delivered, read, total)
  │          convertAndSendToUser(message.sender.id, "/queue/status", update)
  ▼
  └─► NotificationService.clearUnread(recipientId, conversationId)
        └─ unreadByUser[recipientId].remove(conversationId)   (in-memory only, no push)
```

## Touched files
- `message/ChatController.java`
- `message/MessageStatusService.java` (`markRead`, `notifySenders`, `aggregate`)
- `message/dtos/ConversationAckRequest.java` / `message/dtos/MessageStatusUpdate.java`
- `message/MessageRecipientStatus.java` / `message/MessageRecipientStatusRepository.java` / `message/MessageStatus.java`
- `message/Message.java`
- `notification/NotificationService.java` (`clearUnread`)
- `config/WebSocketConfig.java` / `auth/WebSocketAuthInterceptor.java` / `auth/WebSocketHandshakeHandler.java`