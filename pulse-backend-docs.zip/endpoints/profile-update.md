# `PUT /api/v1/profile`
> Update the caller's own display name and/or about text, returning the refreshed profile.

**Auth:** requires JWT — caller id via `SecurityUtil.currentUserId()` (set by JwtAuthFilter).
**Request:** body DTO `UpdateProfileRequest` (`@Valid @RequestBody`):
- `name` — `@Size(min = 1, max = 100, message = "Name must be between 1 and 100 characters")`. Optional (null skips update); if present it is `trim()`-ed before save.
- `about` — `@Size(max = 200, message = "About must not exceed 200 characters")`. Optional (null skips update); if present it is `trim()`-ed before save.
**Success:** `200 OK` — `ApiResponse.ok("Profile updated.", UserProfileResponse)` → `{ success: true, message: "Profile updated.", data: { id, name, about, avatarUrl(presigned|null), lastSeen, createdAt }, timestamp }`.
**Errors:**
- No / invalid auth → `ApiException(401)` → `401`.
- Bean-validation failure (name/about size) → Spring throws `MethodArgumentNotValidException` → `GlobalExceptionHandler.handleValidation` → `400` with `"name: Name must be between 1 and 100 characters"` style message.
- User row missing → `ApiException(NOT_FOUND, "User not found.")` → `404`.
- Presign failure in `toResponse` → `ApiException(500, "Failed to generate file URL.")` → `500`.

## Flow
```
Client ──► PUT /api/v1/profile (JSON {name?, about?})
  │
  ▼
DispatcherServlet → @Valid binds UpdateProfileRequest
  ├─ @Size violation ──► MethodArgumentNotValidException → GlobalExceptionHandler.handleValidation → 400
  ▼
UserProfileController.updateProfile(request)
  ├─ SecurityUtil.currentUserId() ──(unauthenticated)──► throw ApiException(401) → 401
  ▼
UserProfileService.updateProfile(userId, request)
  ▼
findById(userId) → userRepository.findById(userId)
  ├─ empty ──► throw ApiException(NOT_FOUND, "User not found.") → 404
  ▼
if request.getName() != null → user.setName(name.trim())
if request.getAbout() != null → user.setAbout(about.trim())
  ▼
userRepository.save(user)  — persist updated name/about
  ▼
toResponse(savedUser) → storageService.presignedUrl(avatarUrl)
  └─(MinIO error)──► throw ApiException(500) → 500
  ▼
ApiResponse.ok("Profile updated.", response) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `user/UserProfileController.java` — `updateProfile(UpdateProfileRequest)`
- `user/UserProfileService.java` — `updateProfile(Long, UpdateProfileRequest)`, helpers `findById`, `toResponse`
- `user/dtos/UpdateProfileRequest.java` — request DTO + `@Size` validation
- `user/dtos/UserProfileResponse.java` — response DTO
- `user/User.java` — entity setters `setName`, `setAbout`
- `user/UserRepository.java` — `findById`, `save`
- `storage/StorageService.java` — `presignedUrl(String)`
- `common/ApiResponse.java` — `ok(message, data)`
- `common/SecurityUtil.java` — `currentUserId()`
- `common/GlobalExceptionHandler.java` — `handleValidation`, `handleApiException`