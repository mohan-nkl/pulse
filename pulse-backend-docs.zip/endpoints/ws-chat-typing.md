# `STOMP SEND /app/chat.typing`
> Relay a typing indicator to the other participant(s) of a conversation, skipping the sender and anyone in a block relationship with the sender. Response is a WS push (no HTTP status, nothing persisted).

**Auth:** WS → authenticated `Principal` from the handshake (`senderId = Long.valueOf(principal.getName())`).
**Request:** STOMP payload `TypingRequest { conversationId: String, typing: boolean }`.
**Result (pushes, not a return):**
- DM: `TypingEvent { conversationId, userId = senderId, typing }` to the OTHER participant at `/user/{recipientId}/queue/typing`.
- Group: the same `TypingEvent` to every other group member at `/user/{memberId}/queue/typing`.
- Nothing is written to the DB.
**Behavior / edge cases (no HTTP status; failures = silent return):**
- `conversationId == null` → return.
- Not a DM and not a group prefix → no action (`handleTyping` falls through).
- DM: sender must be one of the two participants, else return; relay is suppressed if `blockService.isBlockedBetween(sender, recipient)` (symmetric block check — either direction blocks the relay).
- Group: sender must be a member (`existsByGroupIdAndUserId`), else return; each member is skipped if it is the sender or if `isBlockedBetween(sender, member)` is true.

## Flow
```
Client ──► (SEND /app/chat.typing  TypingRequest{ conversationId, typing })
  ▼
ChatController.typing(request, principal)   senderId = Long.valueOf(principal.getName())
  ▼
TypingService.handleTyping(senderId, conversationId, typing)
  ├─ conversationId == null ? ──► return
  ▼
ConversationUtil.isDirect(conversationId) ?
  ├─ yes → relayDirect(senderId, conversationId, typing)
  │          ├─ participants = ConversationUtil.dmParticipants(conversationId)
  │          ├─ senderIsParticipant? ──no──► return
  │          ├─ recipientId = the other participant
  │          ├─ blockService.isBlockedBetween(sender, recipient)? ──yes──► return
  │          └─ send(recipientId, TypingEvent(conversationId, senderId, typing))
  │                 → convertAndSendToUser(recipientId, "/queue/typing", event)
  │
  └─ else isGroup(conversationId) ?
       └─ yes → relayGroup(senderId, conversationId, typing)
                  ├─ groupId = ConversationUtil.groupIdFrom(conversationId)
                  ├─ groupMemberRepository.existsByGroupIdAndUserId(groupId, sender)? ──no──► return
                  ├─ members = groupMemberRepository.findByGroupId(groupId)
                  └─ for each member:
                        skip if member == sender OR isBlockedBetween(sender, member)
                        else send(memberId, TypingEvent(conversationId, senderId, typing))
                               → convertAndSendToUser(memberId, "/queue/typing", event)
```

## Touched files
- `message/ChatController.java`
- `message/TypingService.java` (`handleTyping`, `relayDirect`, `relayGroup`)
- `message/dtos/TypingRequest.java` / `message/dtos/TypingEvent.java`
- `block/BlockService.java` (`isBlockedBetween`)
- `group/GroupMemberRepository.java` / `group/GroupMember.java`
- `common/ConversationUtil.java`
- `config/WebSocketConfig.java` / `auth/WebSocketAuthInterceptor.java` / `auth/WebSocketHandshakeHandler.java`