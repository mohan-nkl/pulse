# `POST /api/v1/auth/logout`
> Record the caller's last-seen timestamp and force their presence offline on logout.

**Auth:** requires JWT — caller id via `SecurityUtil.currentUserId()` (set by JwtAuthFilter).
**Request:** no path vars, no query params, no body.
**Success:** `200 OK` — `ApiResponse.ok("Logged out.", null)` → `{ success: true, message: "Logged out.", data omitted (JsonInclude.NON_NULL), timestamp }`. Controller returns `ApiResponse<Void>`.
**Errors:**
- No / invalid auth → `SecurityUtil.currentUserId()` throws `ApiException(401)` → `GlobalExceptionHandler.handleApiException` → `401`.
- User row missing → `UserProfileService.recordLastSeen` → `findById` → `ApiException(NOT_FOUND, "User not found.")` → `404`.

(No token revocation/blacklist is performed server-side; logout is stateless beyond updating last-seen and presence. The JWT remains valid until expiry.)

## Flow
```
Client ──► POST /api/v1/auth/logout
  │
  ▼
DispatcherServlet → UserProfileController.logout()
  ├─ SecurityUtil.currentUserId() ──(unauthenticated)──► throw ApiException(401) → 401
  ▼
UserProfileService.recordLastSeen(userId)
  ▼
findById(userId) → userRepository.findById(userId)
  ├─ empty ──► throw ApiException(NOT_FOUND, "User not found.") → 404
  ▼
user.setLastSeen(Instant.now()) → userRepository.save(user)  — persist last-seen
  ▼
presenceService.forceOffline(userId)   (synchronized)
  ├─ connections.remove(userId) → previousCount
  ├─ previousCount == null (was offline) ──► no broadcast
  └─ previousCount != null (was online) ──► broadcast(PresenceUpdate(userId, online=false, Instant.now()))
        → for each connected user not in collectHiddenUserIds(userId):
              messagingTemplate.convertAndSendToUser(id, "/topic/presence", update)
  ▼
controller returns ApiResponse.ok("Logged out.", null) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `user/UserProfileController.java` — `logout()`
- `user/UserProfileService.java` — `recordLastSeen(Long)`, helper `findById`
- `user/User.java` — `setLastSeen(Instant)`
- `user/UserRepository.java` — `findById`, `save`
- `user/PresenceService.java` — `forceOffline(Long)` → `broadcast` → `collectHiddenUserIds`, `SimpMessagingTemplate.convertAndSendToUser` (`/topic/presence`)
- `block/BlockService.java` — `blockersOf`, `blockedIdsOf` (via `collectHiddenUserIds` in broadcast)
- `user/dtos/PresenceUpdate.java` — broadcast payload
- `common/ApiResponse.java` — `ok(message, data)` (data null, omitted)
- `common/SecurityUtil.java` — `currentUserId()`
- `common/GlobalExceptionHandler.java` — `handleApiException`