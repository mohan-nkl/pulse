# `GET /api/conversations/{otherUserId}`
> Fetch one page of a direct (1:1) conversation's message history, newest-first by cursor, returned oldest-first.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` reads the principal from the SecurityContext; throws `ApiException(401)` if missing/unauthenticated.
**Request:**
- Path var: `otherUserId` (Long).
- Query: `before` (Long, optional cursor = message id; page contains messages with `id < before`) and `limit` (int, default `30`).
**Success:** `200` — `ApiResponse<PagedMessages>` where `PagedMessages = { messages: MessageResponse[] (oldest-first), hasMore: boolean }`. Each `MessageResponse` carries content, type, presigned `mediaUrl`, aggregated status (`SENT/DELIVERED/READ`) with delivered/read/total counts, reply summary, status preview, reactions, `edited`, `deleted`.
**Errors:**
- No / invalid JWT → `ApiException(UNAUTHORIZED)` → `401`.
- Unexpected error → `Exception` handler → `500` ("Something went wrong.").
- (No membership check for direct conversations; conversationId is derived deterministically from the two user ids.)

## Flow
```
Client ──► GET /api/conversations/{otherUserId}?before&limit
  ▼
ConversationController.getConversation(otherUserId, before, limit=30)
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(401) → 401
  ▼
ConversationService.getDirectConversation(currentUserId, otherUserId, before, limit)
  ▼
ConversationUtil.dmConversationId(a,b)  →  "dm:<min>:<max>"  (order-independent id)
  ▼
clearedAtFor(currentUserId, conversationId)
  └─ clearedConversationRepository.findByUser_IdAndConversationId(...) → Instant clearedAt | null
  ▼
fetchPage(conversationId, before, limit, currentUserId, clearedAt)
  ├─ before == null ─► messageRepository.findByConversationIdOrderByCreatedAtDesc(id, PageRequest.of(0,limit))
  └─ before != null ─► messageRepository.findByConversationIdAndIdLessThanOrderByCreatedAtDesc(id, before, page)
  ▼
hasMore = (newestFirst.size() == limit)
  ▼
Collections.reverse(newestFirst) → oldestFirst
  ▼
toResponses(oldestFirst, currentUserId, clearedAt, conversationId)
  ├─ directConversation = ConversationUtil.isDirect(id) = true
  ├─ hiddenMessageIdsFor: deletedMessageRepository.findByUser_IdAndMessage_IdIn(...)  (delete-for-me)
  ├─ deliveredToMe = recipientStatusRepository.findDeliveredMessageIds(currentUserId, ids)
  ├─ joinTimeFor(id, viewer) = null   (not a group)
  ├─ statusByMessageId = messageStatusService.statusForMessages(ids)  (aggregate SENT/DELIVERED/READ + counts)
  ├─ reactionsByMessageId = reactionService.reactionsForMessages(ids)
  ├─ repliedStatusesFor(messages) → statusRepository.findAllById(replyToStatusIds)
  ▼
  for each message:
    ├─ clearedForMe(msg, clearedAt): clearedAt != null && msg.createdAt <= clearedAt ──skip──►
    ├─ hiddenMessageIds.contains(id) (deleted-for-me) ──skip──►
    ├─ hiddenByBlock(msg, viewer, direct=true, deliveredToMe, joinedAt=null):
    │     ownMessage || deliveredToViewer → visible
    │     else (direct) → HIDDEN  (block hides peer msgs never delivered to me) ──skip──►
    ▼
    buildMessageResponse: ReplySummary.from(replyTo) + StatusPreviewDto
        + storageService.presignedUrl(mediaUrl) + status counts + reactions
  ▼
return new PagedMessages(responses, hasMore)
  ▼
ApiResponse.ok(paged) ──► 200 JSON
```

## Touched files
- message/ConversationController.java
- message/ConversationService.java
- message/MessageRepository.java
- message/MessageRecipientStatusRepository.java
- message/DeletedMessageRepository.java
- message/ClearedConversationRepository.java
- message/MessageStatusService.java
- reaction/ReactionService.java
- storage/StorageService.java
- status/StatusRepository.java
- common/ConversationUtil.java
- common/SecurityUtil.java
- common/GlobalExceptionHandler.java
- message/dtos/PagedMessages.java, MessageResponse.java
