# `GET /api/presence/{userId}`
> Return a single user's online/last-seen presence, hidden if the viewer and target have blocked each other.

**Auth:** Requires JWT. `/api/presence/**` is NOT public, so `anyRequest().authenticated()` applies. `JwtAuthFilter` validates the Bearer token and populates the `SecurityContext`; the controller then calls `SecurityUtil.currentUserId()` to obtain the viewer id from the authenticated principal.

**Request:** Path variable `userId` — `Long` (`@PathVariable Long userId`), the target whose presence is requested. No body, no query params.

**Success:** HTTP `200 OK` via `ApiResponse.ok(PresenceUpdate)`:
```
{ "success": true,
  "data": { "userId": 7, "online": true,  "lastSeen": null },           // online
           { "userId": 7, "online": false, "lastSeen": "2026-..." } ,    // offline, has last seen
  "timestamp": "..." }
```
`lastSeen` is null when online (and when hidden by block, or user not found).

**Errors:**
- No / invalid JWT → `JwtAuthenticationEntryPoint.commence` → **401**.
- Authenticated but principal not resolvable → `SecurityUtil.currentUserId()` throws `ApiException(UNAUTHORIZED, ...)` → **401**.
- Non-numeric `{userId}` path segment → type-mismatch → falls to `GlobalExceptionHandler.handleUnexpected` → **500** (no dedicated handler for `MethodArgumentTypeMismatchException`).
- Blocked relationship → no error; returns `PresenceUpdate(userId, false, null)` (presence hidden).

## Flow
```
Client ──► GET /api/presence/{userId} (Authorization: Bearer <jwt>)
  │
  ▼
JwtAuthFilter.doFilterInternal() → validates token, sets UsernamePasswordAuthenticationToken(principal=userId)
  ├─ ──(no/invalid token)──► unauthenticated → JwtAuthenticationEntryPoint → 401
  ▼
DispatcherServlet → PresenceController.getPresence(@PathVariable Long userId)
  │
  ▼
viewerId = SecurityUtil.currentUserId()
  ├─ auth==null || !authenticated ──► ApiException(401,"You are not logged in.")
  ├─ principal not a Long ──► ApiException(401,"Could not identify the current user.")
  ▼
PresenceService.getPresenceFor(viewerId, userId)   @Transactional(readOnly = true)
  ├─ blockService.isBlockedBetween(viewerId, userId)
  │     BlockRepository.existsBlockBetween(...)
  │       JPQL: SELECT COUNT(b)>0 FROM Block b
  │             WHERE (b.blocker.id=:viewer AND b.blocked.id=:target)
  │                OR (b.blocker.id=:target AND b.blocked.id=:viewer)
  │     ──(true / hiddenByBlock)──► return PresenceUpdate(userId, online=false, lastSeen=null)
  ▼
PresenceService.getPresence(userId)
  ├─ isOnline(userId): connections (in-memory ConcurrentHashMap) containsKey(userId)
  │     ──(true)──► return PresenceUpdate(userId, online=true, lastSeen=null)
  ▼  (offline branch)
  lastSeenOf(userId): userRepository.findById(userId) -- SELECT * FROM users WHERE id = ?
  │     ──(empty)──► lastSeen=null
  ▼
return PresenceUpdate(userId, online=false, lastSeen)
  ▼
PresenceController wraps ApiResponse.ok(presenceUpdate)
  ▼
200 JSON
```

## Touched files
- `user/PresenceController.java` — `getPresence()` endpoint, `@PathVariable`, `SecurityUtil.currentUserId()`.
- `user/PresenceService.java` — `getPresenceFor()`, `getPresence()`, `isOnline()`, `lastSeenOf()`; in-memory `connections` map; `@Transactional(readOnly=true)`.
- `block/BlockService.java` — `isBlockedBetween()`.
- `block/BlockRepository.java` — `existsBlockBetween()` JPQL.
- `common/SecurityUtil.java` — `currentUserId()` (reads SecurityContext principal).
- `auth/JwtAuthFilter.java`, `auth/JwtAuthenticationEntryPoint.java` — JWT auth + 401.
- `config/SecurityConfig.java` — `anyRequest().authenticated()`.
- `common/ApiResponse.java` — `ok(data)`.
- `common/GlobalExceptionHandler.java` — `handleApiException` (401), `handleUnexpected` (500).
- `user/dtos/PresenceUpdate.java` — response DTO; `user/UserRepository.java` (`findById`), `user/User.java`.