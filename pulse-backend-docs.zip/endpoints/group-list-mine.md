# `GET /api/groups`
> List every group the current user is a member of, with the caller's role and member count per group.

**Auth:** requires JWT — actorId via `SecurityUtil.currentUserId()` (else 401).
**Request:** no path vars, no body.
**Success:** `200 OK`, `ApiResponse.ok(List<GroupResponse>)` → `{ success:true, message:null, data:[ { id, name, avatarUrl, myRole, memberCount, createdAt }, ... ], timestamp }`. Empty list if the user has no memberships.
**Errors:**
- No JWT/principal → `ApiException(UNAUTHORIZED)` → 401.
- (No membership/admin guard here — read-only over own memberships.)

## Flow
```
Client ──► GET /api/groups
  ▼
GroupController.listMyGroups()  ── SecurityUtil.currentUserId() ──no auth──► ApiException(401) → 401
  ▼
GroupService.listMyGroups(userId)   [@Transactional(readOnly=true)]
  ▼
groupMemberRepository.findByUserId(userId) — all memberships of this user
  ▼
for each membership:
  ├─ group = membership.getGroup()
  ├─ countMembers(group.id) → groupMemberRepository.findByGroupId(...).size()
  └─ toGroupResponse(group, membership.getRole(), memberCount)
        └─ storageService.presignedUrl(group.avatarUrl)
  ▼
return List<GroupResponse> ──► ApiResponse.ok(list) ──► 200 JSON
```

## Touched files
- `group/GroupController.java` — `listMyGroups`
- `group/GroupService.java` — `listMyGroups`, `countMembers`, `toGroupResponse`
- `group/dtos/GroupResponse.java` — response DTO
- `group/Group.java`, `group/GroupMember.java`, `group/GroupRole.java` — entities/enum
- `group/GroupMemberRepository.java` — `findByUserId`, `findByGroupId`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`