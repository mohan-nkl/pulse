# `POST /api/v1/statuses/{statusId}/reply`
> Reply to someone's status by sending them a direct message that carries a status preview.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (the `replyerId`).
**Request:** path var `statusId` (Long) + JSON body `@Valid StatusReplyRequest` — `content` (`@NotBlank`, `@Size(max=1000)`).
**Success:** `200 OK` — `ApiResponse.ok("Reply sent.", ChatMessageResponse)`. The reply becomes a DIRECT message to the status author with `statusPreview = { authorName, content, mediaUrl(presigned) }` built from the status. Realtime: `ChatService` pushes the message to both author and replyer via `/user/queue/...`, plus a notification (when not blocked).
**Errors:**
- Status not found → `ApiException(NOT_FOUND, "Status not found.")` → **404**
- Status expired → `ApiException(GONE, "This status has expired.")` → **410**
- Replying to your own status → `ApiException(BAD_REQUEST, "You cannot reply to your own status.")` → **400**
- Blank/oversized `content` → `MethodArgumentNotValidException` → **400**
- Downstream in `ChatService.sendDirectMessage`: sender/receiver not found → **404**; messaging yourself → **400** (not reachable via this path since own-status is blocked first)
- No JWT → **401**

## Flow
```
Client ──► POST /api/v1/statuses/{statusId}/reply (StatusReplyRequest JSON)
  ▼
[@Valid] StatusReplyRequest ──blank/>1000──► MethodArgumentNotValidException → 400
  ▼
StatusController.replyToStatus(statusId, request)
  ├─ SecurityUtil.currentUserId() ──no auth──► 401
  ▼
StatusService.replyToStatus(replyerId, statusId, request)  [@Transactional]
  ▼
findStatusOrThrow(statusId) → statusRepository.findById ──empty──► throw ApiException(NOT_FOUND,"Status not found.") → 404
  ├─ status.expiresAt.isBefore(now) ──expired──► throw ApiException(GONE,"This status has expired.") → 410
  ├─ status.author.id == replyerId ──own status──► throw ApiException(BAD_REQUEST,"You cannot reply to your own status.") → 400
  ▼
build SendMessageRequest{ receiverId = status.author.id, content = request.content, replyToStatusId = statusId }
  ▼
chatService.sendDirectMessage(replyerId, dmRequest)
  ├─ validateContent(...) / findUser sender & receiver ──missing──► ApiException(NOT_FOUND) → 404
  ├─ messagingYourself ──► ApiException(BAD_REQUEST) (guarded earlier by own-status check)
  ├─ messageRepository.save(message) with replyToStatusId set
  ├─ statusPreview = buildStatusPreview(replyToStatusId) → StatusPreviewDto{authorName, content, presigned mediaUrl}
  ├─ if !blocked: createRecipientStatuses + sendTo(receiver) + notificationService.sendNotification
  └─ sendTo(sender) — convertAndSendToUser(/user/queue/...)
  ▼
return ChatMessageResponse ──► ApiResponse.ok("Reply sent.", response) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `status/StatusController.java` — `replyToStatus`
- `status/StatusService.java` — `replyToStatus`, `findStatusOrThrow`
- `status/dtos/StatusReplyRequest.java` — input (`@NotBlank`, `@Size`)
- `status/dtos/StatusPreviewDto.java` — preview embedded in the DM
- `message/ChatService.java` — `sendDirectMessage`, `buildStatusPreview`, `sendTo`
- `message/dtos/SendMessageRequest.java` — `receiverId`, `content`, `replyToStatusId`
- `message/dtos/ChatMessageResponse.java` — output (carries `statusPreview`)
- `block/BlockService.java` — `isBlockedBetween` (in ChatService)
- `storage/StorageService.java` — `presignedUrl` (preview media)
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/GlobalExceptionHandler.java`
- `SimpMessagingTemplate` — realtime DM delivery
