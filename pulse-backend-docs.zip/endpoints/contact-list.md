# `GET /api/v1/contacts`
> List the current user's contacts, excluding anyone in a block relationship with them.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` reads the principal from the `SecurityContext`; throws `ApiException(401)` if unauthenticated / principal is not a `Long`.
**Request:** no path vars, no query params, no body.
**Success:** `200 OK` — `ApiResponse.ok(List<ContactResponse>)`. Each `ContactResponse` = `{ id, contactId, name, phone, alias, avatarUrl, lastSeen, addedAt }`. Blocked contacts are omitted entirely from the list.
**Errors:**
- Not logged in / unidentifiable principal → `ApiException` → `401` (from `SecurityUtil`).
- Unexpected error → `Exception` handler → `500`.
- (No 404 path: an empty list returns `200` with `[]`.)

## Flow
```
Client ──► GET /api/v1/contacts
  │
  ▼
ContactController.listContacts()
  │  SecurityUtil.currentUserId() ──no/invalid auth──► ApiException(401) → 401
  ▼
ContactService.listContacts(ownerId)
  ▼
contactRepository.findByOwner_Id(ownerId) — all Contact rows owned by ownerId
  ▼
for each Contact:
  isBlocked(ownerId, contact)
    └─ blockService.isBlockedBetween(ownerId, contact.getContact().getId())
         ──true──► skip (continue) [contact EXCLUDED]
  ▼
toResponse(contact) (block-aware)
  └─ hiddenByBlock = blockService.isBlockedBetween(contactUserId, ownerId)
       ──true──► avatarUrl=null, lastSeen=null
       ──false─► avatarUrl=storageService.presignedUrl(...), lastSeen=user.getLastSeen()
  └─ always returns id, contactId, name, phone, alias, addedAt
  ▼
return List<ContactResponse>
  ▼
ApiResponse.ok(list) ──► 200 JSON
```

## Touched files
- `contact/ContactController.java` — `listContacts()`
- `contact/ContactService.java` — `listContacts`, `isBlocked`, `toResponse`
- `contact/ContactRepository.java` — `findByOwner_Id`
- `contact/Contact.java` — entity (`owner`, `contact`, `alias`, `addedAt`)
- `contact/dtos/ContactResponse.java`
- `block/BlockService.java` — `isBlockedBetween`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java` — `currentUserId`
- `common/GlobalExceptionHandler.java`