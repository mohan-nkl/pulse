# `GET /api/v1/blocks/{userId}/status`
> Check whether the caller has blocked a given user.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (throws `ApiException(401)` if no/invalid auth principal).
**Request:** path var `userId: Long` (the user to check). No body.
**Success:** `200 OK` — `ApiResponse.ok(Map.of("blocked", boolean))`:
```
{ "success": true, "data": { "blocked": true|false }, "timestamp": Instant }
```
`blocked` is one-directional: true only if **caller → userId** block row exists (not the reverse).
**Errors:**
- not authenticated → `ApiException(UNAUTHORIZED, ...)` → `401`
- `ApiException`s rendered by `GlobalExceptionHandler.handleApiException`.

## Flow
```
Client ──► GET /api/v1/blocks/{userId}/status
  ▼
BlockController.status(userId)
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(UNAUTHORIZED) → 401
  ▼
BlockService.hasBlocked(blockerId, blockedId)        [@Transactional(readOnly)]
  ▼
blockRepository.existsByBlocker_IdAndBlocked_Id(blockerId, blockedId)
                                — boolean: does caller→target block row exist?
  ▼
return boolean
  ▼
BlockController wraps: Map.of("blocked", blocked)
  ▼
ApiResponse.ok(map) ──► 200 {"success":true,"data":{"blocked":<bool>}}
```

## Touched files
- `block/BlockController.java` — `status(@PathVariable Long userId)`
- `block/BlockService.java` — `hasBlocked`
- `block/BlockRepository.java` — `existsByBlocker_IdAndBlocked_Id`
- `common/SecurityUtil.java` — `currentUserId`
- `common/ApiResponse.java` — `ok`
- `common/GlobalExceptionHandler.java` — error rendering