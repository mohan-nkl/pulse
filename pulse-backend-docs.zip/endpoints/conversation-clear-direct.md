# `DELETE /api/conversations/{otherUserId}`
> Clear (hide for me) a direct conversation by recording/refreshing a "cleared up to now" timestamp — does NOT delete any messages.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`; throws `ApiException(401)` if missing.
**Request:** path var `otherUserId` (Long). No body, no query params.
**Success:** `200` — `ApiResponse<Void>` with message `"Conversation deleted."` and `data: null`.
**Errors:**
- No / invalid JWT → `401`.
- Unexpected → `500`.
- (No membership/existence check; clearing a never-used dm just creates a cleared row keyed on the derived id.)

## Flow
```
Client ──► DELETE /api/conversations/{otherUserId}
  ▼
ConversationController.clearDirectConversation(otherUserId)
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(401) → 401
  ▼
ConversationService.clearDirectConversation(userId, otherUserId)   @Transactional
  ▼
ConversationUtil.dmConversationId(userId, otherUserId) → "dm:<min>:<max>"
  ▼
clearConversation(userId, conversationId)
  ├─ now = Instant.now()
  ├─ clearedConversationRepository.findByUser_IdAndConversationId(userId, id)
  │     ├─ present ─► cleared.setClearedAt(now) → save (UPDATE)  ──► return
  │     └─ empty   ─► new ClearedConversation{ user=userRepository.getReferenceById(userId),
  │                       conversationId=id, clearedAt=now } → save (INSERT)
  ▼
ApiResponse.ok("Conversation deleted.", null) ──► 200 JSON
```

Notes:
- Per-user, soft hide: messages persist; this only sets `clearedAt`, later consulted by `clearedForMe` in `getDirectConversation` (filters msgs with `createdAt <= clearedAt`) and by `GET /hidden`.
- Idempotent: re-clearing just advances the timestamp to `now`.

## Touched files
- message/ConversationController.java
- message/ConversationService.java
- message/ClearedConversationRepository.java
- common/ConversationUtil.java
- common/SecurityUtil.java
- common/GlobalExceptionHandler.java
- message/ClearedConversation.java
- user/UserRepository.java