# `PATCH /api/v1/contacts/{id}/alias`
> Update the alias on a contact owned by the current user.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`.
**Request:** path var `id` (Long, the contact record id). Body `UpdateAliasRequest` `{ alias }` — NOT annotated `@Valid` and not `required=false`, so an absent/empty body throws on `request.getAlias()`. Alias is trimmed via `cleanAlias` (blank → null, effectively clearing it).
**Success:** `200 OK` — `ApiResponse.ok("Alias updated.", ContactResponse)`.
**Errors:**
- Contact not found OR not owned by current user → `findByIdAndOwner_Id` empty → `ApiException(NOT_FOUND)` → `404` ("Contact not found.") — ownership-scoped, so another user's contact reads as 404.
- Missing body → `HttpMessageNotReadableException` → `500` (no dedicated handler). Non-numeric `id` → `500`. Not logged in → `401`.

## Flow
```
Client ──► PATCH /api/v1/contacts/{id}/alias  (UpdateAliasRequest {alias})
  │
  ▼
ContactController.updateAlias(@PathVariable id, @RequestBody request)
  │  SecurityUtil.currentUserId() ──no auth──► 401
  ▼
ContactService.updateAlias(ownerId, contactId, request)
  ▼
findOwnedContactOrThrow(contactId, ownerId)
  └─ contactRepository.findByIdAndOwner_Id(id, ownerId)  [OWNERSHIP-SCOPED]
       ── empty ──► ApiException(404 "Contact not found.") → 404
  ▼
contact.setAlias(cleanAlias(request.getAlias()))   (trim; blank → null)
  ▼
contactRepository.save(contact) — updates alias column
  ▼
toResponse(savedContact) (block-aware: hides avatar/lastSeen if blocked)
  ▼
ApiResponse.ok("Alias updated.", response) ──► 200 JSON
```

## Touched files
- `contact/ContactController.java` — `updateAlias()`
- `contact/ContactService.java` — `updateAlias`, `findOwnedContactOrThrow`, `cleanAlias`, `toResponse`
- `contact/ContactRepository.java` — `findByIdAndOwner_Id`, `save`
- `contact/Contact.java`
- `contact/dtos/UpdateAliasRequest.java`, `contact/dtos/ContactResponse.java`
- `block/BlockService.java` — `isBlockedBetween` (via toResponse)
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/GlobalExceptionHandler.java`
