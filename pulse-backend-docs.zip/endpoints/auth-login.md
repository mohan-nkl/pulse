# `POST /api/auth/login`
> Authenticate by phone + password, refresh `lastSeen`, and return a JWT.

**Auth:** Public. `/api/auth/**` is in `SecurityConfig.PUBLIC_ENDPOINTS` (`permitAll`). Caller id is not read from the security context; identity is established by matching the password and the JWT is minted for the matched user.

**Request:** JSON body `LoginRequest` (validated with `@Valid`):
- `phone` — String, `@NotBlank("Phone number is required")`
- `password` — String, `@NotBlank("Password is required")`

**Success:** HTTP `200 OK` (returns `ApiResponse<AuthResponse>`). Body via `ApiResponse.ok("Logged in successfully", result)`:
```
{ "success": true, "message": "Logged in successfully",
  "data": { "token": "...", "userId": 1, "phone": "...", "name": "...", "avatarUrl": "<presigned or null>" },
  "timestamp": "..." }
```

**Errors:**
- Bean validation fails (blank phone/password) → `MethodArgumentNotValidException` → `GlobalExceptionHandler.handleValidation` → **400**.
- Phone not found → `ApiException(UNAUTHORIZED, "Invalid phone or password")` → **401**.
- Password mismatch → `ApiException(UNAUTHORIZED, "Invalid phone or password")` → **401**.
- MinIO presign fails (only if user has an `avatarUrl`) → `ApiException(INTERNAL_SERVER_ERROR, "Failed to generate file URL.")` → **500**.

## Flow
```
Client ──► POST /api/auth/login (LoginRequest JSON)
  │
  ▼
JwtAuthFilter.doFilterInternal() — public route, passes through
  │
  ▼
DispatcherServlet → AuthController.login(@Valid LoginRequest)
  │  @Valid LoginRequest ──(blank phone|password)──►
  │        MethodArgumentNotValidException → GlobalExceptionHandler.handleValidation → 400
  ▼
AuthService.login(request)
  ├─ findUserByPhoneOrThrow(phone)
  │     userRepository.findByPhone(phone)  -- SELECT * FROM users WHERE phone = ?
  │     ──(empty)──► throw ApiException(UNAUTHORIZED,"Invalid phone or password")
  │                  → handleApiException → 401
  ▼
passwordEncoder.matches(rawPassword, user.passwordHash)   -- BCrypt verify
  ├─ ──(false)──► throw ApiException(UNAUTHORIZED,"Invalid phone or password") → 401
  ▼
user.setLastSeen(Instant.now()); userRepository.save(user) -- UPDATE users SET last_seen = ? WHERE id = ?
  ▼
AuthService.buildAuthResponse(user)
  ├─ jwtUtil.generateToken(user.getId())    -- HMAC-signed JWT, subject=userId, exp=now+expiration-ms
  ├─ storageService.presignedUrl(avatarUrl)
  │     ──(avatarUrl null/blank)──► null
  │     ──(else)──► minioClient.getPresignedObjectUrl(GET, bucket, key, expiry)
  │                 ──(MinIO error)──► ApiException(500,"Failed to generate file URL.")
  ▼
new AuthResponse(token, id, phone, name, avatarUrl)
  ▼
return AuthResponse ──► AuthController wraps ApiResponse.ok("Logged in successfully", result)
  ▼
200 JSON
```

## Touched files
- `auth/AuthController.java` — `login()` endpoint, `@Valid`, wraps `ApiResponse.ok`.
- `auth/AuthService.java` — `login()`, helpers `findUserByPhoneOrThrow()`, `buildAuthResponse()`.
- `auth/JwtUtil.java` — `generateToken(Long userId)`.
- `auth/JwtAuthFilter.java` — runs but no-op for this public route.
- `storage/StorageService.java` — `presignedUrl()` / `generatePresignedUrl()` (MinIO GET presign).
- `config/SecurityConfig.java` — `BCryptPasswordEncoder` bean, `/api/auth/**` permitAll.
- `common/ApiResponse.java` — `ok(message, data)`.
- `common/GlobalExceptionHandler.java` — `handleValidation` (400), `handleApiException` (401/500).
- `common/ApiException.java` — status + message.
- `auth/dtos/LoginRequest.java`, `auth/dtos/AuthResponse.java` — DTOs.
- `user/UserRepository.java` — `findByPhone`, `save`; `user/User.java` entity.