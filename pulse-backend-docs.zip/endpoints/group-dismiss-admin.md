# `DELETE /api/groups/{groupId}/admins/{userId}`
> Admin demotes another admin back to MEMBER; an admin cannot dismiss themselves.

**Auth:** requires JWT — actorId via `SecurityUtil.currentUserId()` (else 401). Admin-only.
**Request:** path vars `groupId` (`Long`), `userId` (`Long`, target to demote). No body.
**Success:** `200 OK`, `ApiResponse.ok("Admin dismissed", List<GroupMemberResponse>)` — refreshed member list. (Controller method `dismissAdmin` delegates to `GroupService.demoteAdmin`.)
**Errors:**
- Caller not a member → `requireAdmin`→`requireMembership` → 403.
- Caller not ADMIN → `requireAdmin` → 403 "Only an admin can do that.".
- Demoting yourself (`userId == actorId`) → `ApiException(BAD_REQUEST)` → 400 "You cannot dismiss yourself as admin.".
- Target not a member → `requireMembership` → 403 "You are not a member of this group.".
- No JWT → 401.

## Flow
```
Client ──► DELETE /api/groups/{groupId}/admins/{userId}
  ▼
GroupController.dismissAdmin(groupId, userId)  ── currentUserId() ──no auth──► 401
  ▼
GroupService.demoteAdmin(actorId, groupId, targetUserId)   [@Transactional]
  ▼
requireAdmin(actorId, groupId)
  ├─ requireMembership(groupId, actorId) ──not member──► ApiException(403) → 403
  └─ role != ADMIN ──► ApiException(403 "Only an admin can do that.") → 403
  ▼
targetUserId.equals(actorId)? ──yes──► throw ApiException(400 "You cannot dismiss yourself as admin.") → 400
  ▼ no
requireMembership(groupId, targetUserId) ──target not member──► ApiException(403) → 403
  ▼
target.setRole(MEMBER)
  ▼
groupMemberRepository.save(target) — persist role change
  ▼
return getMembers(actorId, groupId)
  ▼
──► ApiResponse.ok("Admin dismissed", List<GroupMemberResponse>) ──► 200 JSON
```

## Touched files
- `group/GroupController.java` — `dismissAdmin`
- `group/GroupService.java` — `demoteAdmin`, `requireAdmin`, `requireMembership`, `getMembers`, `toMemberResponse`
- `group/dtos/GroupMemberResponse.java` — response DTO
- `group/GroupMember.java`, `group/GroupRole.java`
- `group/GroupMemberRepository.java` — `findByGroupIdAndUserId`, `save`, `findByGroupId`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/ApiException.java`