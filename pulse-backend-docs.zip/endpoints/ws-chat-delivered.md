# `STOMP SEND /app/chat.delivered`
> A recipient acknowledges receipt: flip their still-SENT status rows to DELIVERED and push aggregated status updates back to each affected message's sender. Response is a WS push (no HTTP status).

**Auth:** WS → authenticated `Principal` from the handshake (`recipientId = Long.valueOf(principal.getName())`).
**Request:** STOMP payload `ConversationAckRequest { conversationId: String }`. `conversationId` may be null → marks delivered across ALL of this recipient's SENT rows (every conversation).
**Result (pushes, not a return):**
- For each affected message, one `MessageStatusUpdate { messageId, conversationId, status, deliveredCount, readCount, totalRecipients }` to the message SENDER at `/user/{senderId}/queue/status`.
- No push if there were no SENT rows to update (early return).
**Behavior / edge cases (no HTTP status):**
- Only rows currently in status SENT are promoted to DELIVERED (with `deliveredAt = now`). Already DELIVERED/READ rows are untouched.
- Aggregate per message via `aggregate(total, delivered, read)`: READ if all read, else DELIVERED if all delivered, else SENT.
- No validation that the caller is actually a member of `conversationId`; it simply filters by `recipientId` (the principal), so a user can only ever flip their own rows.

## Flow
```
Client ──► (SEND /app/chat.delivered  ConversationAckRequest{ conversationId? })
  ▼
ChatController.markDelivered(request, principal)   recipientId = Long.valueOf(principal.getName())
  ▼
MessageStatusService.markDelivered(recipientId, conversationId)   @Transactional
  ▼
conversationId == null ?
  ├─ yes → myRows = statusRepository.findByRecipient_IdAndStatus(recipientId, SENT)
  └─ no  → myRows = statusRepository.findByRecipient_IdAndMessage_ConversationIdAndStatus(
                        recipientId, conversationId, SENT)
  ▼
myRows.isEmpty() ? ──yes──► return (no push)
  ▼ no
for each row: row.status = DELIVERED; row.deliveredAt = now
statusRepository.saveAll(myRows)
  ▼
notifySenders(myRows)
  ├─ messageIds = distinct message ids of changed rows
  ├─ allRows = statusRepository.findByMessage_IdIn(messageIds)   // full recipient set per message
  ├─ group rows by messageId
  └─ for each message group:
        total/delivered/read counts → aggregate(...)
        update = MessageStatusUpdate(messageId, conversationId, status, delivered, read, total)
        messagingTemplate.convertAndSendToUser(message.sender.id, "/queue/status", update)
```

## Touched files
- `message/ChatController.java`
- `message/MessageStatusService.java` (`markDelivered`, `notifySenders`, `aggregate`, counts)
- `message/dtos/ConversationAckRequest.java` / `message/dtos/MessageStatusUpdate.java`
- `message/MessageRecipientStatus.java` / `message/MessageRecipientStatusRepository.java` / `message/MessageStatus.java`
- `message/Message.java`
- `config/WebSocketConfig.java` / `auth/WebSocketAuthInterceptor.java` / `auth/WebSocketHandshakeHandler.java`
