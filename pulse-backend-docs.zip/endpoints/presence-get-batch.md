# `POST /api/presence`
> Return presence for a batch of user ids in one call, applying block-aware filtering and de-duplication.

**Auth:** Requires JWT. `/api/presence/**` is NOT public, so `anyRequest().authenticated()` applies. `JwtAuthFilter` validates the Bearer token and populates the `SecurityContext`; the controller calls `SecurityUtil.currentUserId()` to obtain the viewer id from the authenticated principal.

**Request:** JSON body `List<Long>` of target user ids (`@RequestBody List<Long> userIds`). No `@Valid` / DTO wrapper; the list is consumed directly. Order is preserved per first occurrence; duplicates are collapsed (`distinct`).

**Success:** HTTP `200 OK` via `ApiResponse.ok(List<PresenceUpdate>)` — one entry per distinct id, in first-seen order:
```
{ "success": true,
  "data": [ { "userId": 7, "online": true,  "lastSeen": null },
            { "userId": 9, "online": false, "lastSeen": "2026-..." },
            { "userId": 4, "online": false, "lastSeen": null } ],   // hidden by block
  "timestamp": "..." }
```

**Errors:**
- No / invalid JWT → `JwtAuthenticationEntryPoint.commence` → **401**.
- Authenticated but principal not resolvable → `SecurityUtil.currentUserId()` → `ApiException(UNAUTHORIZED, ...)` → **401**.
- Malformed JSON body / wrong element type → `HttpMessageNotReadableException` → no dedicated handler → `handleUnexpected` → **500**.
- Blocked ids are not errors: each blocked target yields `PresenceUpdate(id, false, null)`.

## Flow
```
Client ──► POST /api/presence  (JSON body: [7, 9, 4, 7], Authorization: Bearer <jwt>)
  │
  ▼
JwtAuthFilter.doFilterInternal() → validates token, sets principal=userId
  ├─ ──(no/invalid token)──► JwtAuthenticationEntryPoint → 401
  ▼
DispatcherServlet → PresenceController.getPresenceFor(@RequestBody List<Long> userIds)
  │  ──(unparseable body)──► HttpMessageNotReadableException → handleUnexpected → 500
  ▼
viewerId = SecurityUtil.currentUserId()
  ├─ not authenticated / bad principal ──► ApiException(401) → handleApiException → 401
  ▼
PresenceService.getPresenceForViewer(viewerId, userIds)   @Transactional(readOnly = true)
  ├─ collectHiddenUserIds(viewerId):
  │     blockService.blockersOf(viewerId)  -- JPQL: SELECT b.blocker.id FROM Block b WHERE b.blocked.id=:viewer
  │     blockService.blockedIdsOf(viewerId)-- JPQL: SELECT b.blocked.id FROM Block b WHERE b.blocker.id=:viewer
  │     union → Set<Long> hiddenUserIds
  ├─ loadLastSeenByUserId(userIds):
  │     userRepository.findAllById(userIds) -- SELECT * FROM users WHERE id IN (?)
  │     → Map<userId, lastSeen>
  ▼
for each id in distinct(userIds):           -- preserves first-seen order, removes dups
  ├─ hiddenUserIds.contains(id) ──► PresenceUpdate(id, online=false, lastSeen=null)
  ├─ else isOnline(id) (in-memory connections map) ──► PresenceUpdate(id, online=true, lastSeen=null)
  └─ else ──► PresenceUpdate(id, online=false, lastSeen = lastSeenByUserId.get(id))  // may be null
  ▼
return List<PresenceUpdate>
  ▼
PresenceController wraps ApiResponse.ok(list)
  ▼
200 JSON
```

## Touched files
- `user/PresenceController.java` — `getPresenceFor()` (`@PostMapping`), `@RequestBody List<Long>`, `SecurityUtil.currentUserId()`.
- `user/PresenceService.java` — `getPresenceForViewer()`, helpers `collectHiddenUserIds()`, `loadLastSeenByUserId()`, `distinct()`, `isOnline()`; in-memory `connections` map; `@Transactional(readOnly=true)`.
- `block/BlockService.java` — `blockersOf()`, `blockedIdsOf()`.
- `block/BlockRepository.java` — `findBlockerIdsByBlocked()`, `findBlockedIdsByBlocker()` JPQL.
- `common/SecurityUtil.java` — `currentUserId()`.
- `auth/JwtAuthFilter.java`, `auth/JwtAuthenticationEntryPoint.java` — JWT auth + 401.
- `config/SecurityConfig.java` — `anyRequest().authenticated()`.
- `common/ApiResponse.java` — `ok(data)`.
- `common/GlobalExceptionHandler.java` — `handleApiException` (401), `handleUnexpected` (500).
- `user/dtos/PresenceUpdate.java` — response element DTO; `user/UserRepository.java` (`findAllById`), `user/User.java`.