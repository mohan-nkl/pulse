# `GET /api/conversations/unread-counts`
> Return how many unread (not-yet-READ) incoming messages the current user has per conversation.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`; throws `ApiException(401)` if missing.
**Request:** no path vars, no query params.
**Success:** `200` — `ApiResponse<Map<String, Integer>>` keyed by `conversationId` (e.g. `"dm:1:2"`, `"group:5"`) → unread count. Conversations with zero unread are absent (GROUP BY only yields rows that exist).
**Errors:**
- No / invalid JWT → `401`.
- Unexpected → `500`.

## Flow
```
Client ──► GET /api/conversations/unread-counts
  ▼
ConversationController.getUnreadCounts()
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(401) → 401
  ▼
ConversationService.getUnreadCounts(userId)
  ▼
recipientStatusRepository.countUnreadPerConversation(userId)
   └─ JPQL: SELECT mrs.message.conversationId, COUNT(mrs)
            FROM MessageRecipientStatus mrs
            WHERE mrs.recipient.id = :userId AND mrs.status <> READ
            GROUP BY mrs.message.conversationId
      ▼  returns List<Object[]> rows of [conversationId(String), count(Long)]
  ▼
for each row → unreadByConversation.put(conversationId, ((Long)count).intValue())
  ▼
return Map<String,Integer>
  ▼
ApiResponse.ok(map) ──► 200 JSON
```

Notes:
- Counts are based on the recipient-status rows for the current user (rows where they are a recipient). Status `SENT` and `DELIVERED` both count as unread; only `READ` is excluded.
- Sender-side rows are never counted (the sender is not their own recipient).

## Touched files
- message/ConversationController.java
- message/ConversationService.java
- message/MessageRecipientStatusRepository.java
- common/SecurityUtil.java
- common/GlobalExceptionHandler.java