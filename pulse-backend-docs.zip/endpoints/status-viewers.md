# `GET /api/v1/statuses/{statusId}/viewers`
> List who viewed a status (author-only), newest view first.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (the `requesterId`).
**Request:** path var `statusId` (Long). No body.
**Success:** `200 OK` — `ApiResponse.ok(List<StatusViewerResponse>)`. Each = `{ viewerId, viewerName, viewerAvatarUrl(presigned), viewedAt }`, ordered by `viewedAt` desc.
**Errors:**
- Status not found → `ApiException(NOT_FOUND, "Status not found.")` → **404**
- Requester is not the author → `ApiException(FORBIDDEN, "Only the author can see viewers.")` → **403**
- No JWT → **401**

## Flow
```
Client ──► GET /api/v1/statuses/{statusId}/viewers
  ▼
StatusController.getViewers(statusId)
  ├─ SecurityUtil.currentUserId() ──no auth──► 401
  ▼
StatusService.getStatusViewers(requesterId, statusId)  [@Transactional(readOnly=true)]
  ▼
findStatusOrThrow(statusId) → statusRepository.findById ──empty──► throw ApiException(NOT_FOUND,"Status not found.") → 404
  ├─ status.author.id == requesterId ?
  └─ !requesterIsAuthor ──true──► throw ApiException(FORBIDDEN,"Only the author can see viewers.") → 403
  ▼
statusViewRepository.findByStatusIdOrderByViewedAtDesc(statusId)
   — SELECT status_views WHERE status_id = :id ORDER BY viewed_at DESC
  ▼
for each StatusView → toViewerResponse(view)
   └─ avatarUrl = storageService.presignedUrl(viewer.avatarUrl)
      new StatusViewerResponse(viewer.id, viewer.name, avatarUrl, view.viewedAt)
  ▼
return List<StatusViewerResponse> ──► ApiResponse.ok(list) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `status/StatusController.java` — `getViewers`
- `status/StatusService.java` — `getStatusViewers`, `toViewerResponse`, `findStatusOrThrow`
- `status/StatusViewRepository.java` — `findByStatusIdOrderByViewedAtDesc`
- `status/StatusView.java` — entity (`viewedAt`)
- `status/dtos/StatusViewerResponse.java`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/ApiResponse.java`, `common/GlobalExceptionHandler.java`