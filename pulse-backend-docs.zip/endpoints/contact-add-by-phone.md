# `POST /api/v1/contacts`
> Add a contact by looking up a Pulse user via phone number.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`.
**Request:** JSON body `AddContactRequest` `{ phone (required, @NotBlank), alias (optional) }`. `@Valid` triggers bean validation.
**Success:** `201 CREATED` — `ApiResponse.ok("Contact added.", ContactResponse)`. `alias` is trimmed via `cleanAlias` (blank → null).
**Errors:**
- Blank/missing `phone` → `MethodArgumentNotValidException` → `400` ("phone: Phone number is required.").
- Owner id not found → `ApiException(NOT_FOUND)` → `404` ("User not found.").
- No user with that phone → `ApiException(NOT_FOUND)` → `404` ("No Pulse user found with that phone number.").
- Adding yourself → `ApiException(BAD_REQUEST)` → `400` ("You cannot add yourself as a contact.").
- Already a contact → `ApiException(CONFLICT)` → `409` ("Contact already added.").
- Not logged in → `401`. Unexpected → `500`.

## Flow
```
Client ──► POST /api/v1/contacts  (AddContactRequest {phone, alias?})
  │
  ▼
ContactController.addContact(@Valid AddContactRequest)
  │  @Valid blank phone ──invalid──► MethodArgumentNotValidException → 400
  │  SecurityUtil.currentUserId() ──no auth──► 401
  ▼
ContactService.addContact(ownerId, request)
  ├─ findUserOrThrow(ownerId) ── empty ──► ApiException(404 "User not found.")
  ├─ findUserByPhoneOrThrow(request.getPhone())
  │     userRepository.findByPhone(phone) ── empty ──► ApiException(404 "No Pulse user found...")
  ├─ ensureNotSelf(ownerId, contactUser.id) ── self ──► ApiException(400) → 400
  ├─ ensureNotAlreadyContact(ownerId, contactUser.id)
  │     contactRepository.findByOwner_IdAndContact_Id(...).isPresent() ──► ApiException(409) → 409
  ▼
new Contact{ owner, contact=contactUser, alias=cleanAlias(request.alias) }
  ▼
contactRepository.save(contact) — inserts row (unique constraint on owner_id+contact_id)
  ▼
toResponse(savedContact) (block-aware: hides avatar/lastSeen if blocked)
  ▼
ApiResponse.ok("Contact added.", response) ──► 201 JSON
```

## Touched files
- `contact/ContactController.java` — `addContact()`
- `contact/ContactService.java` — `addContact`, `findUserOrThrow`, `findUserByPhoneOrThrow`, `ensureNotSelf`, `ensureNotAlreadyContact`, `cleanAlias`, `toResponse`
- `contact/ContactRepository.java` — `findByOwner_IdAndContact_Id`, `save`
- `contact/Contact.java` — entity + unique constraint
- `contact/dtos/AddContactRequest.java`, `contact/dtos/ContactResponse.java`
- `user/UserRepository.java` — `findById`, `findByPhone`
- `block/BlockService.java` — `isBlockedBetween` (via toResponse)
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java`, `common/GlobalExceptionHandler.java`