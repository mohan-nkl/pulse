# Endpoint Flowcharts — Index

One file per API endpoint. Each file is a top-to-bottom **flowchart**: every node is a real
step (`Class.method`) with a brief note on what's happening, branch points show where each
path goes, and the resulting HTTP status (or realtime push) is shown. REST status codes and
errors route through `GlobalExceptionHandler`.

**How to read a node:** `SomeService.method(...)  -- brief what-happens`. Branches look like
`├─ check ──(fail)──► throw ApiException(STATUS) → STATUS`.

## Auth & account
- [POST /api/auth/signup](auth-signup.md)
- [POST /api/auth/login](auth-login.md)
- [POST /api/v1/auth/logout](auth-logout.md)

## Profile & presence
- [GET /api/v1/profile](profile-get-mine.md)
- [PUT /api/v1/profile](profile-update.md)
- [POST /api/v1/profile/avatar](profile-avatar-upload.md)
- [DELETE /api/v1/profile/avatar](profile-avatar-remove.md)
- [GET /api/v1/users/{userId}/profile](profile-get-user.md)
- [GET /api/presence/{userId}](presence-get-one.md)
- [POST /api/presence](presence-get-batch.md)

## Contacts
- [GET /api/v1/contacts](contact-list.md)
- [GET /api/v1/contacts/search](contact-search.md)
- [POST /api/v1/contacts](contact-add-by-phone.md)
- [POST /api/v1/contacts/user/{userId}](contact-add-by-userid.md)
- [POST /api/v1/contacts/sync](contact-sync.md)
- [PATCH /api/v1/contacts/{id}/alias](contact-update-alias.md)
- [DELETE /api/v1/contacts/{id}](contact-remove.md)

## Blocks
- [POST /api/v1/blocks/{userId}](block-add.md)
- [DELETE /api/v1/blocks/{userId}](block-remove.md)
- [GET /api/v1/blocks](block-list.md)
- [GET /api/v1/blocks/{userId}/status](block-status.md)

## Conversations (chat history & lists — REST)
- [GET /api/conversations/{otherUserId}](conversation-get-direct.md)
- [GET /api/conversations/group/{groupId}](conversation-get-group.md)
- [GET /api/conversations/unread-counts](conversation-unread-counts.md)
- [GET /api/conversations/partners](conversation-partners.md)
- [GET /api/conversations/summaries](conversation-summaries.md)
- [GET /api/conversations/hidden](conversation-hidden.md)
- [DELETE /api/conversations/{otherUserId}](conversation-clear-direct.md)
- [DELETE /api/conversations/group/{groupId}](conversation-clear-group.md)

## Messages — actions & info (REST)
- [DELETE /api/messages/{messageId}/for-me](message-delete-for-me.md)
- [DELETE /api/messages/{messageId}/for-everyone](message-delete-for-everyone.md)
- [PUT /api/messages/{messageId}](message-edit.md)
- [GET /api/messages/{messageId}/status](message-info.md)

## Messages — realtime (WebSocket / STOMP `/app/...`)
- [SEND /app/chat.send](ws-chat-send.md)
- [SEND /app/group.send](ws-group-send.md)
- [SEND /app/chat.delivered](ws-chat-delivered.md)
- [SEND /app/chat.read](ws-chat-read.md)
- [SEND /app/chat.typing](ws-chat-typing.md)

## Reactions
- [POST /api/messages/{messageId}/reactions](reaction-add.md)
- [DELETE /api/messages/{messageId}/reactions](reaction-remove.md)

## Groups
- [POST /api/groups](group-create.md)
- [GET /api/groups](group-list-mine.md)
- [GET /api/groups/{groupId}/members](group-get-members.md)
- [POST /api/groups/{groupId}/members](group-add-members.md)
- [DELETE /api/groups/{groupId}/members/{userId}](group-remove-member.md)
- [POST /api/groups/{groupId}/admins/{userId}](group-make-admin.md)
- [DELETE /api/groups/{groupId}/admins/{userId}](group-dismiss-admin.md)
- [POST /api/groups/{groupId}/leave](group-leave.md)
- [PUT /api/groups/{groupId}](group-update.md)
- [POST /api/groups/{groupId}/avatar](group-avatar-upload.md)
- [DELETE /api/groups/{groupId}/avatar](group-avatar-remove.md)

## Status (stories)
- [POST /api/v1/statuses/upload](status-upload-media.md)
- [POST /api/v1/statuses](status-create.md)
- [GET /api/v1/statuses/mine](status-mine.md)
- [GET /api/v1/statuses](status-contacts.md)
- [POST /api/v1/statuses/{statusId}/view](status-view.md)
- [GET /api/v1/statuses/{statusId}/viewers](status-viewers.md)
- [POST /api/v1/statuses/{statusId}/reply](status-reply.md)
- [DELETE /api/v1/statuses/{statusId}](status-delete.md)

## Media
- [POST /api/v1/media/upload](media-upload.md)