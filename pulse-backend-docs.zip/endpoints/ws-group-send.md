# `STOMP SEND /app/group.send`
> Send a group message: persist it, create status rows for deliverable members, push the message + a group notification to each deliverable recipient, and echo to the sender. Response is a WS push (no HTTP status).

**Auth:** WS → authenticated `Principal` from the handshake (`senderId = Long.valueOf(principal.getName())`).
**Request:** STOMP payload `SendGroupMessageRequest { groupId: Long, content: String, messageType = "TEXT", mediaUrl: String, replyToId: Long }`.
**Result (pushes, not a return):**
- To each `deliverableRecipientIds` member `/user/{memberId}/queue/messages` ← `ChatMessageResponse`.
- To each `deliverableRecipientIds` member `/user/{memberId}/queue/notifications` ← `NotificationDto` (group form: title = group name, preview = "senderLabel: <preview>").
- To sender `/user/{senderId}/queue/messages` ← `ChatMessageResponse` (echo).
`deliverableRecipientIds` = all group members EXCEPT the sender AND EXCEPT anyone in a block relationship with the sender (either direction — `isBlockedBetween`). Status rows are created only for these recipients (DELIVERED if member online else SENT).
**Errors (no HTTP status; surfaced via messaging error channel):**
- `groupId` null → `ApiException(400)` "Group id is required".
- Content/media validation → `400` (`validateContent`).
- Sender not found → `404`.
- Sender not a member → `ApiException(403)` "You are not a member of this group."
- `replyToId` invalid / different conversation → `400`.
- Note: `members.get(0)` is used for the group name — assumes the group has at least one member (the sender membership guarantees this).

## Flow
```
Client ──► (SEND /app/group.send  SendGroupMessageRequest)
  ▼
ChatController.sendGroupMessage(request, principal)   senderId = Long.valueOf(principal.getName())
  ▼
ChatService.sendGroupMessage(senderId, request)   @Transactional
  ├─ groupId null? ──► 400 "Group id is required"
  ├─ validateContent(messageType, content, mediaUrl)
  ├─ sender = findUser(senderId)   (missing → 404)
  ├─ groupMemberRepository.existsByGroupIdAndUserId(groupId, senderId)? ──no──► 403
  ▼
conversationId = ConversationUtil.groupConversationId(groupId)   // "group:{id}"
  ▼
build Message{ conversationId, GROUP, sender, type, content, mediaUrl,
               replyTo = resolveReplyTo(replyToId, conversationId) }
  ▼
saved = messageRepository.save(message)
  ▼
members = groupMemberRepository.findByGroupId(groupId)
recipientIds = deliverableRecipientIds(members, senderId)
   └─ for each member: skip if member == sender; skip if blockService.isBlockedBetween(sender, member)
  ▼
messageStatusService.createRecipientStatuses(saved, recipientIds)
   └─ per recipient: DELIVERED+deliveredAt if presenceService.isOnline(recipient) else SENT
  ▼
status = messageStatusService.currentStatus(saved.id)   // aggregate over recipientIds
response = toResponse(saved, senderId, conversationId, null, status.name())
  ▼
groupName = members.get(0).getGroup().getName()
for each recipientId in recipientIds:
   sendTo(recipientId, response)            → convertAndSendToUser(recipient, /queue/messages, response)
   notificationService.sendGroupNotification(recipientId, conversationId, groupName,
        notificationNameFor(recipient, sender), content)   → /user/{recipient}/queue/notifications
  ▼
sendTo(senderId, response)                  → convertAndSendToUser(sender, /queue/messages, response)  (echo)
```

## Touched files
- `message/ChatController.java`
- `message/ChatService.java` (`sendGroupMessage`, `deliverableRecipientIds`)
- `message/MessageStatusService.java` (`createRecipientStatuses`, `currentStatus`)
- `message/dtos/SendGroupMessageRequest.java` / `message/dtos/ChatMessageResponse.java`
- `message/Message.java` / `message/ConversationType.java` / `message/MessageRepository.java`
- `group/GroupMemberRepository.java` / `group/GroupMember.java` / `group/Group.java`
- `notification/NotificationService.java` (`sendGroupNotification`) / `notification/dtos/NotificationDto.java`
- `block/BlockService.java` / `user/PresenceService.java` (`isOnline`)
- `storage/StorageService.java` / `common/ConversationUtil.java` / `common/ApiException.java`
- `config/WebSocketConfig.java` / `auth/WebSocketAuthInterceptor.java` / `auth/WebSocketHandshakeHandler.java`