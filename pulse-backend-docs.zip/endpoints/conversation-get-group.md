# `GET /api/conversations/group/{groupId}`
> Fetch one page of a group conversation's message history (members only), newest-first by cursor, returned oldest-first.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`; throws `ApiException(401)` if missing/unauthenticated.
**Request:**
- Path var: `groupId` (Long).
- Query: `before` (Long, optional cursor = message id, page is `id < before`) and `limit` (int, default `30`).
**Success:** `200` — `ApiResponse<PagedMessages>` = `{ messages: MessageResponse[] (oldest-first), hasMore }`. Each `MessageResponse` has content, type, presigned `mediaUrl`, aggregated status + delivered/read/total counts (across all group recipients), reply summary, status preview, reactions, `edited`, `deleted`.
**Errors:**
- Not a member of the group → `ApiException(FORBIDDEN, "You are not a member of this group.")` → `403`.
- No / invalid JWT → `ApiException(UNAUTHORIZED)` → `401`.
- Unexpected → `500`.

## Flow
```
Client ──► GET /api/conversations/group/{groupId}?before&limit
  ▼
ConversationController.getGroupConversation(groupId, before, limit=30)
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(401) → 401
  ▼
ConversationService.getGroupConversation(currentUserId, groupId, before, limit)
  ├─ groupMemberRepository.existsByGroupIdAndUserId(groupId, currentUserId)
  │      └─ false ──► throw ApiException(403 "not a member") → 403
  ▼
ConversationUtil.groupConversationId(groupId)  →  "group:<groupId>"
  ▼
clearedAtFor(currentUserId, conversationId)
  └─ clearedConversationRepository.findByUser_IdAndConversationId(...) → Instant clearedAt | null
  ▼
fetchPage(conversationId, before, limit, currentUserId, clearedAt)
  ├─ before == null ─► messageRepository.findByConversationIdOrderByCreatedAtDesc(id, page)
  └─ before != null ─► messageRepository.findByConversationIdAndIdLessThanOrderByCreatedAtDesc(id, before, page)
  ▼
hasMore = (newestFirst.size() == limit)
  ▼
Collections.reverse → oldestFirst
  ▼
toResponses(oldestFirst, currentUserId, clearedAt, conversationId)
  ├─ directConversation = ConversationUtil.isDirect(id) = false
  ├─ hiddenMessageIdsFor: deletedMessageRepository.findByUser_IdAndMessage_IdIn(...) (delete-for-me)
  ├─ deliveredToMe = recipientStatusRepository.findDeliveredMessageIds(currentUserId, ids)
  ├─ joinedGroupAt = joinTimeFor(id, viewer):
  │       ConversationUtil.groupIdFrom(id) → groupMemberRepository.findByGroupIdAndUserId(..).joinedAt
  ├─ statusByMessageId = messageStatusService.statusForMessages(ids)
  ├─ reactionsByMessageId = reactionService.reactionsForMessages(ids)
  ├─ repliedStatusesFor → statusRepository.findAllById(replyToStatusIds)
  ▼
  for each message:
    ├─ clearedForMe(msg, clearedAt): clearedAt != null && createdAt <= clearedAt ──skip──►
    ├─ hiddenMessageIds.contains(id) (deleted-for-me) ──skip──►
    ├─ hiddenByBlock(msg, viewer, direct=false, deliveredToMe, joinedGroupAt):
    │     ownMessage || deliveredToViewer → visible
    │     else (group) → wasMemberWhenSent(msg, joinedGroupAt):
    │            joinedGroupAt != null && msg.createdAt >= joinedGroupAt → HIDDEN ──skip──►
    │            (i.e. msgs I should have received post-join but were not delivered — block-hidden;
    │             pre-join history stays visible)
    ▼
    buildMessageResponse: ReplySummary.from(replyTo) + StatusPreviewDto
        + storageService.presignedUrl(mediaUrl) + status counts + reactions
  ▼
return new PagedMessages(responses, hasMore)
  ▼
ApiResponse.ok(paged) ──► 200 JSON
```

## Touched files
- message/ConversationController.java
- message/ConversationService.java
- message/MessageRepository.java
- message/MessageRecipientStatusRepository.java
- message/DeletedMessageRepository.java
- message/ClearedConversationRepository.java
- message/MessageStatusService.java
- reaction/ReactionService.java
- group/GroupMemberRepository.java
- storage/StorageService.java
- status/StatusRepository.java
- common/ConversationUtil.java
- common/SecurityUtil.java
- common/GlobalExceptionHandler.java
- message/dtos/PagedMessages.java, MessageResponse.java
