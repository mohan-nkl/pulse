# `DELETE /api/messages/{messageId}/reactions`
> Remove the caller's reaction from a message (idempotent) and broadcast the updated reaction set. No author notification.

**Auth:** requires JWT — `SecurityUtil.currentUserId()` (throws `ApiException(401)` if no/invalid auth principal).
**Request:** path var `messageId: Long`. No body.
**Success:** `200 OK` — `ApiResponse.ok(null)` → `{ "success": true, "data": null, "timestamp": Instant }`. Updated reactions delivered over WebSocket (see realtime).
**Errors:**
- message not found → `ApiException(NOT_FOUND, "Message not found.")` → `404`
- DM: caller not one of the two participants → `ApiException(FORBIDDEN, "You are not part of this conversation.")` → `403`
- group: caller not a member → `ApiException(FORBIDDEN, "You are not a member of this group.")` → `403`
- not authenticated → `ApiException(UNAUTHORIZED, ...)` → `401`
- No error if the caller had no reaction — it is a no-op (still broadcasts current state).
- `ApiException`s rendered by `GlobalExceptionHandler.handleApiException`.

## Flow
```
Client ──► DELETE /api/messages/{messageId}/reactions (no body)
  ▼
ReactionController.unreact(messageId)
  ├─ SecurityUtil.currentUserId() ──no auth──► throw ApiException(UNAUTHORIZED) → 401
  ▼
ReactionService.unreact(userId, messageId)            [@Transactional]
  ▼
findMessageOrThrow(messageId)
  └─ messageRepository.findById(messageId) ──empty──► throw ApiException(NOT_FOUND,"Message not found.") → 404
  ▼
ensureMember(userId, message.getConversationId())     ◄── membership gate
  ├─ isDirect: dmParticipants → not p0/p1 ──► ApiException(FORBIDDEN,"...not part of this conversation.") → 403
  └─ isGroup:  groupMemberRepository.existsByGroupIdAndUserId(groupId,userId)==false ──► ApiException(FORBIDDEN,"...not a member of this group.") → 403
  ▼
reactionRepository.findByMessage_IdAndUser_Id(messageId, userId) — Optional<Reaction>
  ├─ empty ──► do nothing (idempotent)
  ▼ present
reactionRepository.delete(existingReaction.get()) — remove row
  ▼
broadcast(message)                                    ◄── realtime ReactionUpdate (no notifyAuthor here)
  ├─ update = new ReactionUpdate(messageId, convId, currentReactions(messageId))
  │      └─ reactionRepository.findByMessage_Id(messageId) → remaining [ReactionEntry]
  ├─ isDirect(convId): dmParticipants → send(p0); send(p1)
  └─ isGroup(convId): groupMemberRepository.findByGroupId(groupId) → send(each member.user.id)
        └─ send: messagingTemplate.convertAndSendToUser(recipientId, "/queue/reactions", update)
  ▼
return void ──► ReactionController returns ApiResponse.ok(null) ──► 200 JSON
```

## Touched files
- `reaction/ReactionController.java` — `unreact`
- `reaction/ReactionService.java` — `unreact`, `findMessageOrThrow`, `ensureMember`, `broadcast`, `currentReactions`, `toEntry`, `send`
- `reaction/ReactionRepository.java` — `findByMessage_IdAndUser_Id`, `delete`, `findByMessage_Id`
- `reaction/Reaction.java` — entity
- `reaction/dtos/ReactionUpdate.java` — broadcast payload
- `reaction/dtos/ReactionEntry.java` — `userId,userName,emoji`
- `message/MessageRepository.java` — `findById`
- `group/GroupMemberRepository.java` — `existsByGroupIdAndUserId`, `findByGroupId`
- `common/ConversationUtil.java` — `isDirect`, `isGroup`, `dmParticipants`, `groupIdFrom`
- `common/SecurityUtil.java` — `currentUserId`
- `common/ApiResponse.java` — `ok`
- `common/GlobalExceptionHandler.java` — error rendering