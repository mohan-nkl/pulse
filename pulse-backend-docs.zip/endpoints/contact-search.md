# `GET /api/v1/contacts/search?q=`
> Search the current user's contacts by alias, name, or phone, excluding blocked contacts.

**Auth:** requires JWT — `SecurityUtil.currentUserId()`.
**Request:** query param `q` (required by `@RequestParam String q`; missing → `MissingServletRequestParameterException` → 400). Blank/empty `q` falls back to listing all contacts.
**Success:** `200 OK` — `ApiResponse.ok(List<ContactResponse>)`; same shape as list. Filtered in-memory; blocked contacts excluded.
**Errors:**
- Missing `q` param → `MissingServletRequestParameterException` → `400` ("Required parameter 'q' is missing.").
- Not logged in → `ApiException` → `401`.
- Unexpected error → `500`.

## Flow
```
Client ──► GET /api/v1/contacts/search?q=<text>
  │
  ▼
ContactController.searchContacts(@RequestParam String q)
  │  missing q ──► MissingServletRequestParameterException → 400
  │  SecurityUtil.currentUserId() ──no auth──► ApiException(401) → 401
  ▼
ContactService.searchContacts(ownerId, q)
  ├─ q == null || q.isBlank() ──► return listContacts(ownerId) [all contacts, block-filtered]
  ▼
trimmedQuery = q.trim()
contactRepository.findByOwner_Id(ownerId) — all owned contacts
  ▼
for each Contact:
  isBlocked(ownerId, contact)
    └─ blockService.isBlockedBetween(ownerId, contact.getContact().getId())
         ──true──► skip [EXCLUDED]
  matchesQuery(contact, trimmedQuery)
    ├─ alias.toLowerCase().contains(q.toLowerCase())
    ├─ contact name.toLowerCase().contains(q.toLowerCase())
    └─ phone.contains(q)  (raw, case-sensitive)
       ──no match──► skip
  ▼
toResponse(contact) (block-aware: hides avatar/lastSeen if blocked)
  ▼
return List<ContactResponse>
  ▼
ApiResponse.ok(list) ──► 200 JSON
```

## Touched files
- `contact/ContactController.java` — `searchContacts()`
- `contact/ContactService.java` — `searchContacts`, `matchesQuery`, `isBlocked`, `toResponse`, `listContacts`
- `contact/ContactRepository.java` — `findByOwner_Id`
- `contact/Contact.java`
- `contact/dtos/ContactResponse.java`
- `block/BlockService.java` — `isBlockedBetween`
- `storage/StorageService.java` — `presignedUrl`
- `common/SecurityUtil.java` — `currentUserId`
- `common/GlobalExceptionHandler.java` — missing-param / validation handlers