# `GET /api/v1/users/{userId}/profile`
> Return another user's profile as seen by the caller, with block-aware hiding and contact-alias display name.

**Auth:** requires JWT — caller (viewer) id via `SecurityUtil.currentUserId()` (set by JwtAuthFilter).
**Request:** path var `userId` (`@PathVariable Long userId`) = owner whose profile is requested. No body/params.
**Success:** `200 OK` — `ApiResponse.ok(UserProfileResponse)` → `{ success: true, message: null (omitted), data: { id, name, about, avatarUrl, lastSeen, createdAt }, timestamp }`.
Field semantics differ from "my profile":
- `name` = `displayNameFor(viewerId, owner)` — the viewer's saved **contact alias** for the owner if present and non-blank, otherwise the owner's **phone**. It is **never** the owner's registered `name`.
- When a block exists in **either** direction between viewer and owner (`blockService.isBlockedBetween`), `avatarUrl` and `lastSeen` are forced to `null` (hidden); `about`, `id`, `createdAt`, and the alias/phone `name` are still returned.
**Errors:**
- No / invalid auth → `ApiException(401)` → `401`.
- Owner row missing → `UserProfileService.findById(ownerId)` → `ApiException(NOT_FOUND, "User not found.")` → `404`.
- Presign failure (only when not block-hidden) → `ApiException(500, "Failed to generate file URL.")` → `500`.
- Non-numeric `{userId}` path → type-mismatch handled by fallback `handleUnexpected` → `500` `"Something went wrong. Please try again."` (no dedicated handler).

## Flow
```
Client ──► GET /api/v1/users/{userId}/profile
  │
  ▼
DispatcherServlet → UserProfileController.getUserProfile(userId)
  ├─ SecurityUtil.currentUserId() ──(unauthenticated)──► throw ApiException(401) → 401
  │     (viewerId)
  ▼
UserProfileService.getUserProfileFor(viewerId, ownerId)
  ▼
findById(ownerId) → userRepository.findById(ownerId)
  ├─ empty ──► throw ApiException(NOT_FOUND, "User not found.") → 404
  ▼
hiddenByBlock = blockService.isBlockedBetween(viewerId, ownerId)
  │   → blockRepository.existsBlockBetween(viewerId, ownerId)  (block in either direction)
  ├─ hiddenByBlock == true ──► avatarUrl = null, lastSeen = null  (skip presign)
  └─ hiddenByBlock == false ─► avatarUrl = storageService.presignedUrl(owner.getAvatarUrl())
  │                            lastSeen = owner.getLastSeen()
  │       └─(MinIO presign error)──► throw ApiException(500, "Failed to generate file URL.") → 500
  ▼
name = displayNameFor(viewerId, owner)
  → contactRepository.findByOwner_IdAndContact_Id(viewerId, owner.getId())
        .map(Contact::getAlias).filter(non-null, non-blank)
        .orElse(owner.getPhone())     // alias-or-phone, NEVER owner's registered name
  ▼
new UserProfileResponse(owner.getId(), name, owner.getAbout(), avatarUrl, lastSeen, owner.getCreatedAt())
  ▼
ApiResponse.ok(response) ──► ResponseEntity.ok(...) ──► 200 JSON
```

## Touched files
- `user/UserProfileController.java` — `getUserProfile(Long userId)`
- `user/UserProfileService.java` — `getUserProfileFor(Long viewerId, Long ownerId)`, helpers `displayNameFor(Long, User)`, `findById`
- `block/BlockService.java` — `isBlockedBetween(Long, Long)` → `BlockRepository.existsBlockBetween`
- `contact/ContactRepository.java` — `findByOwner_IdAndContact_Id(Long, Long)`
- `contact/Contact.java` — `getAlias()`
- `storage/StorageService.java` — `presignedUrl(String)` (skipped when block-hidden)
- `user/User.java` — `getAvatarUrl`, `getLastSeen`, `getAbout`, `getPhone`, `getCreatedAt`, `getId`
- `user/UserRepository.java` — `findById`
- `user/dtos/UserProfileResponse.java` — response DTO
- `common/ApiResponse.java` — `ok(data)`
- `common/SecurityUtil.java` — `currentUserId()`
- `common/GlobalExceptionHandler.java` — `handleApiException`, `handleUnexpected`