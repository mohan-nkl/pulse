# `GET /api/messages/{messageId}/status`
> Sender-only "message info": per-recipient delivery/read breakdown plus aggregate counts for one message.

**Auth:** REST → `SecurityUtil.currentUserId()` from the `SecurityContext` (401 if missing).
**Request:**
- Path var: `messageId` (Long).
- No body.
**Result:** `200` with `ApiResponse.ok(MessageInfoResponse)` where
`MessageInfoResponse { messageId, totalRecipients, deliveredCount, readCount, recipients: [RecipientStatusEntry] }`
and each `RecipientStatusEntry { userId, name, avatarUrl (presigned), status (SENT|DELIVERED|READ), deliveredAt, readAt }`.
Counts: `deliveredCount` = rows with status DELIVERED or READ; `readCount` = rows with status READ; `totalRecipients` = number of recipient-status rows.
**Errors:**
- Message not found → `ApiException(404)` "Message not found." (`findMessageOrThrow`).
- Requester is not the sender → `ApiException(403)` "You can only see delivery info for your own messages."
- Avatar presign failure → `ApiException(500)` "Failed to generate file URL." (from `StorageService`).

## Flow
```
Client ──► GET /api/messages/{messageId}/status
  ▼
MessageStatusController.getMessageInfo(messageId)
  ├─ currentUserId = SecurityUtil.currentUserId()
  ▼
MessageStatusService.getMessageInfo(requesterId, messageId)   @Transactional(readOnly)
  ▼
findMessageOrThrow(messageId)  → messageRepository.findById  (empty → 404)
  ▼
message.getSender().getId().equals(requesterId) ?
  └─ no ──► throw 403 "You can only see delivery info for your own messages."
  ▼ yes
rows = statusRepository.findByMessage_Id(messageId)
  ▼
for each row → toRecipientStatusEntry(row):
   recipient = row.getRecipient()
   avatarUrl = storageService.presignedUrl(recipient.getAvatarUrl())   (null key → null url)
   entry = RecipientStatusEntry(id, name, avatarUrl, row.status, row.deliveredAt, row.readAt)
  ▼
total     = rows.size()
delivered = countAtLeastDelivered(rows)   // status == DELIVERED || READ
read      = countRead(rows)               // status == READ
  ▼
return new MessageInfoResponse(messageId, total, delivered, read, entries)
  ▼
Controller wraps in ApiResponse.ok(...)  → 200
```

## Touched files
- `message/MessageStatusController.java`
- `message/MessageStatusService.java`
- `message/dtos/MessageInfoResponse.java`
- `message/dtos/RecipientStatusEntry.java`
- `message/MessageRecipientStatus.java` / `message/MessageRecipientStatusRepository.java`
- `message/MessageStatus.java` / `message/Message.java` / `message/MessageRepository.java`
- `storage/StorageService.java`
- `user/User.java` / `user/UserRepository.java`
- `common/SecurityUtil.java` / `common/ApiException.java` / `common/ApiResponse.java` / `common/GlobalExceptionHandler.java`