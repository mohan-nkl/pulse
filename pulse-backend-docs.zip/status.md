# Status (Stories) — Backend Flow

This document describes the **Status** feature of Pulse end to end on the backend. Status is the WhatsApp-style "Stories" feature: ephemeral posts (text and/or media) that are visible to your contacts for 24 hours, that record who viewed them, that can be replied to as a direct message, and that honor block relationships with WhatsApp-grade parity.

All package paths below are under `src/main/java/com/mohan/pulse/`.

Primary classes:
- `status/Status.java`, `status/StatusView.java`, `status/HiddenStatus.java` — JPA entities
- `status/StatusRepository.java`, `status/StatusViewRepository.java`, `status/HiddenStatusRepository.java` — Spring Data repositories
- `status/StatusController.java` — REST endpoints
- `status/StatusService.java` — business logic
- `status/dtos/*.java` — request/response/event DTOs

Audience: a developer who has to defend this code in a review. Every claim below is grounded in the actual source.

---

## 1. Data model

### 1.1 `Status` — the post itself

```java
@Entity
@Table(name = "statuses",
        indexes = {
                @Index(name = "idx_status_author_expires", columnList = "author_id, expires_at")
        })
public class Status {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id", nullable = false)
    private User author;

    @Column(length = 700)
    private String content;

    @Column(name = "media_url")
    private String mediaUrl;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @Column(nullable = false)
    private Instant expiresAt;
}
```

Field-by-field:

- **`author`** — `@ManyToOne(fetch = FetchType.LAZY)` to `User`, joined via the non-null `author_id` foreign-key column. Lazy fetch means the `User` row is **not** loaded when the `Status` is loaded; it is loaded on first access (e.g. `status.getAuthor().getId()`). Inside the service these accesses happen within `@Transactional` boundaries so the persistence context is open and the lazy proxy can resolve.
- **`content`** — the text body, capped at the DB column level with `@Column(length = 700)`. This generates a `VARCHAR(700)` column. The API-level cap is enforced independently in `CreateStatusRequest` (`@Size(min = 1, max = 700)`), so the two limits are deliberately aligned.
- **`mediaUrl`** — nullable string. This stores the **MinIO object key** (e.g. `status/<uuid>.jpg`), **not** a browser-usable URL. It is converted to a short-lived presigned URL at read time (see §4 `toResponse`). A status may have content, media, or both.
- **`createdAt`** — `@CreationTimestamp` (Hibernate) populates this at INSERT; `updatable = false` forbids later changes. This is the anchor for the 24h expiry window.
- **`expiresAt`** — `nullable = false`. Set explicitly by the service to `createdAt + 24h` (computed as `Instant.now().plus(24, ChronoUnit.HOURS)` at creation). Every read query filters on this column rather than hard-deleting expired rows (see §6).

**The index** `idx_status_author_expires` on `(author_id, expires_at)` is the workhorse for the two hot read paths:
- `findByAuthorIdAndExpiresAtAfterOrderByCreatedAtAsc(authorId, now)` ("my statuses")
- `findActiveByAuthorIds(authorIds, now)` ("contacts' statuses", `WHERE author.id IN (...) AND expiresAt > now`)

Both predicate on `author_id` and `expires_at`, so the composite index lets the DB seek by author and range-scan by expiry in one structure.

### 1.2 `StatusView` — one row per (status, viewer)

```java
@Entity
@Table(name = "status_views",
        uniqueConstraints = @UniqueConstraint(
                name = "uq_status_viewer",
                columnNames = {"status_id", "viewer_id"}
        ))
public class StatusView {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "status_id", nullable = false)
    private Status status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "viewer_id", nullable = false)
    private User viewer;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private Instant viewedAt;
}
```

`StatusView` is the read-receipt join row. The **unique constraint `uq_status_viewer` on `(status_id, viewer_id)`** is the data-integrity guarantee that a viewer is recorded **at most once** per status. The application also checks `existsByStatusIdAndViewerId` before inserting (§4 `viewStatus`), so the unique constraint is the backstop against a race that slips past the app-level check. `viewedAt` is stamped by Hibernate at INSERT and feeds the "Seen at" timestamp in the viewers list.

### 1.3 `HiddenStatus` — durable per-viewer suppression (the key entity)

```java
@Entity
@Table(name = "hidden_statuses",
        uniqueConstraints = @UniqueConstraint(
                name = "uq_hidden_status_viewer",
                columnNames = {"status_id", "viewer_id"}
        ))
public class HiddenStatus {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "status_id", nullable = false)
    private Status status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "viewer_id", nullable = false)
    private User viewer;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private Instant hiddenAt;
}
```

**Why this entity exists.** Block exclusion at read time alone is *not* enough to match WhatsApp behavior. Consider:

1. Alice blocks Bob.
2. While the block is active, Alice posts a status.
3. Later Alice unblocks Bob.

In WhatsApp, the statuses Alice posted *while Bob was blocked* must **never** become visible to Bob, even after the unblock — they belong to a window in which Bob was not a permitted audience. A pure read-time block filter would leak them: once the block row is deleted at unblock, the read filter no longer excludes Bob, and those statuses would reappear.

`HiddenStatus` solves this by recording, **at creation time**, a durable `(status, viewer)` suppression row for every user currently in a block relationship with the author. That row survives the unblock, so the status stays hidden from that viewer forever. The unique constraint `uq_hidden_status_viewer` keeps these rows idempotent per (status, viewer).

So the two mechanisms are complementary (see §5):
- **Current-block exclusion** (read time) hides *all* of a currently-blocked author's statuses, including ones posted before the block.
- **`HiddenStatus`** (write time) durably hides statuses posted *during* a block, so they don't resurface after unblock.

---

## 2. Repositories

### 2.1 `StatusRepository`

```java
public interface StatusRepository extends JpaRepository<Status, Long> {

    @Query("SELECT s FROM Status s WHERE s.author.id IN :authorIds AND s.expiresAt > :now ORDER BY s.createdAt DESC")
    List<Status> findActiveByAuthorIds(@Param("authorIds") List<Long> authorIds,
                                       @Param("now") Instant now);

    List<Status> findByAuthorIdAndExpiresAtAfterOrderByCreatedAtAsc(Long authorId, Instant now);

    @Query("SELECT s FROM Status s WHERE s.id = :id AND s.author.id = :authorId")
    Optional<Status> findByIdAndAuthorId(@Param("id") Long id, @Param("authorId") Long authorId);
}
```

- **`findActiveByAuthorIds`** — explicit JPQL. Returns all non-expired statuses for a set of authors, newest first. `s.expiresAt > :now` is the live-only filter (§6). `IN :authorIds` lets the contacts feed pull every visible author in a single query. Ordering is `createdAt DESC` (newest first) — appropriate for a feed.
- **`findByAuthorIdAndExpiresAtAfterOrderByCreatedAtAsc`** — a **derived (method-name) query**. Spring Data parses the name into the predicate `author.id = ? AND expiresAt > ?` with `ORDER BY createdAt ASC`. Note the order is **ASC** here (oldest first): "my statuses" is a self-view played in chronological order, the opposite of the feed. The `ExpiresAtAfter` keyword maps to `expiresAt > now`, the same live-only filter expressed in derived form.
- **`findByIdAndAuthorId`** — explicit JPQL combining identity + ownership in one round trip. Used by `deleteStatus` so deletion is authorized atomically: it returns empty if the status doesn't exist *or* the caller isn't the author, collapsing "not found" and "not yours" into one check (and one error message).

### 2.2 `StatusViewRepository`

```java
public interface StatusViewRepository extends JpaRepository<StatusView, Long> {
    long countByStatusId(Long statusId);
    void deleteByStatusId(Long statusId);
    boolean existsByStatusIdAndViewerId(Long statusId, Long viewerId);
    List<StatusView> findByStatusIdOrderByViewedAtDesc(Long statusId);
}
```

All four are derived queries:
- `countByStatusId` → view count for the author's badge (`toResponse`, author branch).
- `deleteByStatusId` → bulk delete of view rows during `deleteStatus` (FK cleanup, §4).
- `existsByStatusIdAndViewerId` → dedupe check before recording a view, and the `viewedByMe` flag for non-authors.
- `findByStatusIdOrderByViewedAtDesc` → viewers list, most recent viewer first.

### 2.3 `HiddenStatusRepository`

```java
public interface HiddenStatusRepository extends JpaRepository<HiddenStatus, Long> {
    List<HiddenStatus> findByViewer_IdAndStatus_IdIn(Long viewerId, List<Long> statusIds);
    void deleteByStatus_Id(Long statusId);
}
```

- **`findByViewer_IdAndStatus_IdIn`** — given a viewer and a batch of candidate status ids, returns the suppression rows that apply. The underscore `Viewer_Id` / `Status_Id` is Spring Data's explicit property-path syntax: traverse the `viewer` (resp. `status`) association then its `id`. This avoids ambiguity and resolves to a join on the FK. Used by `removeHiddenForViewer` to filter the contacts feed in one query rather than per-status.
- **`deleteByStatus_Id`** — bulk delete of suppression rows during `deleteStatus`.

---

## 3. Controller endpoints

All endpoints live in `StatusController` under base path `/api/v1/statuses`. Each resolves the caller via `SecurityUtil.currentUserId()` (the authenticated principal — the controller never trusts a client-supplied user id) and wraps the result in the shared `ApiResponse<T>` envelope.

| Method & Path | Body / Params | Service call | Success response |
|---|---|---|---|
| `POST /upload` | `multipart file` (`@RequestParam("file")`) | `uploadStatusMedia(userId, file)` | `200` `ApiResponse.ok("Image uploaded.", mediaUrl)` — the MinIO object key as a `String` |
| `POST /` | `@Valid @RequestBody CreateStatusRequest` | `createStatus(userId, request)` | `201 CREATED` `ApiResponse.ok("Status posted.", StatusResponse)` |
| `GET /mine` | — | `getMyStatuses(userId)` | `200` `List<StatusResponse>` (your live statuses, oldest first) |
| `GET /` | — | `getContactStatuses(userId)` | `200` `List<StatusResponse>` (contacts' visible live statuses, newest first) |
| `POST /{statusId}/view` | path `statusId` | `viewStatus(userId, statusId)` | `200` `ApiResponse.ok("Viewed.", null)` |
| `GET /{statusId}/viewers` | path `statusId` | `getStatusViewers(userId, statusId)` | `200` `List<StatusViewerResponse>` (author only) |
| `POST /{statusId}/reply` | path `statusId` + `@Valid @RequestBody StatusReplyRequest` | `replyToStatus(userId, statusId, request)` | `200` `ApiResponse.ok("Reply sent.", ChatMessageResponse)` |
| `DELETE /{statusId}` | path `statusId` | `deleteStatus(userId, statusId)` | `200` `ApiResponse.ok("Status deleted.", null)` |

Note `createStatus` is the only endpoint that returns `201 CREATED`; the rest return `200`. `@Valid` on `CreateStatusRequest` and `StatusReplyRequest` triggers Bean Validation before the handler body runs (size constraints / `@NotBlank`).

### DTOs

- **`CreateStatusRequest`** — `content` (`@Size(min = 1, max = 700)`), `mediaUrl` (no constraint). Validation here only bounds a *provided* text; the "must have text or media" rule is enforced in the service, not by annotations, because it's a cross-field rule.
- **`StatusReplyRequest`** — `content` (`@NotBlank`, `@Size(max = 1000)`). A reply must be non-empty text.
- **`StatusResponse`** (`@Builder`) — `id`, `authorId`, `authorName`, `authorAvatarUrl`, `content`, `mediaUrl`, `createdAt`, `expiresAt`, `viewCount` (`Long`, nullable), `viewedByMe` (`boolean`). `viewCount` is populated only for the author; `viewedByMe` only for non-authors (see `toResponse`).
- **`StatusViewerResponse`** — `viewerId`, `viewerName`, `viewerAvatarUrl`, `viewedAt`.
- **`StatusViewEvent`** — `{ statusId }`. The WebSocket push payload telling an author "someone viewed status X."
- **`StatusPreviewDto`** — `{ authorName, content, mediaUrl }`. Not used by Status code directly; it is the embedded preview that `ChatService.buildStatusPreview` attaches to a status-reply message so the chat bubble can render "replying to <your status>."

---

## 4. Service flows (`StatusService`)

Constructor-injected collaborators (`@RequiredArgsConstructor`): `StatusRepository`, `StatusViewRepository`, `HiddenStatusRepository`, `UserRepository`, `ContactRepository`, `ChatService`, `StorageService`, `BlockService`, `SimpMessagingTemplate`.

Constants:
```java
private static final String STATUS_VIEWS_QUEUE = "/queue/status-views";
private static final List<String> ALLOWED_MEDIA_TYPES = List.of(
        "image/jpeg", "image/png", "image/webp", "image/gif",
        "video/mp4", "video/webm", "video/quicktime", "video/ogg");
private static final long MAX_MEDIA_SIZE = 20L * 1024 * 1024;
```

### 4.1 `uploadStatusMedia(userId, file)` — not transactional

Media upload is decoupled from status creation: the client uploads first, gets back an object key, then includes that key as `mediaUrl` in the create call. The method validates, then delegates to MinIO:

```java
boolean fileMissing = (file == null || file.isEmpty());
if (fileMissing) throw new ApiException(HttpStatus.BAD_REQUEST, "File must not be empty.");

boolean tooLarge = file.getSize() > MAX_MEDIA_SIZE;          // 20 MB
if (tooLarge) throw new ApiException(HttpStatus.BAD_REQUEST, "Status media must not exceed 20 MB.");

boolean unsupportedType = !ALLOWED_MEDIA_TYPES.contains(file.getContentType());
if (unsupportedType) throw new ApiException(HttpStatus.BAD_REQUEST, "Status media must be an image or a video.");

return storageService.upload("status", file);
```

Validation order: presence → size → content type. `storageService.upload("status", file)` stores under the `status/` folder and returns the generated object key (`status/<uuid><ext>`). There is no `@Transactional` here — the work is a single external (MinIO) call with no DB write, so a transaction would buy nothing. (See the storage/media doc for MinIO details; summarized in §7.)

### 4.2 `createStatus(authorId, request)` — `@Transactional` (write)

```java
boolean hasText  = (request.getContent()  != null && !request.getContent().isBlank());
boolean hasMedia = (request.getMediaUrl() != null && !request.getMediaUrl().isBlank());
if (!hasText && !hasMedia) {
    throw new ApiException(HttpStatus.BAD_REQUEST, "A status must have text, an image, or both.");
}

User author = findUserOrThrow(authorId);

String content  = hasText  ? request.getContent().trim()  : null;
String mediaUrl = hasMedia ? request.getMediaUrl().trim() : null;

Instant expiresAt = Instant.now().plus(24, ChronoUnit.HOURS);

Status status = new Status();
status.setAuthor(author);
status.setContent(content);
status.setMediaUrl(mediaUrl);
status.setExpiresAt(expiresAt);

Status savedStatus = statusRepository.save(status);
hideFromBlockedViewers(savedStatus, authorId);
return toResponse(savedStatus, authorId);
```

Steps:
1. **Cross-field validation** — at least one of text/media must be present. (`@Size` on the DTO can't express "either/or", so this lives in the service.)
2. **Resolve the author** via `findUserOrThrow` (404 if missing).
3. **Normalize** — `trim()` both fields; absent fields become `null`.
4. **Set expiry** — `Instant.now().plus(24, ChronoUnit.HOURS)`. `createdAt` is filled by `@CreationTimestamp`; `expiresAt` is set explicitly here. (Tiny clock skew between the two is harmless.)
5. **Persist** with `save`.
6. **Durable block suppression** — `hideFromBlockedViewers(savedStatus, authorId)` (next).
7. **Map to DTO** with `toResponse(savedStatus, authorId)` (caller is the author, so `viewCount = 0`, `viewedByMe = false`).

#### `hideFromBlockedViewers(status, authorId)`

```java
Set<Long> blockedWithAuthor = blockedOrBlockingIds(authorId);
if (blockedWithAuthor.isEmpty()) return;

List<HiddenStatus> rows = new ArrayList<>();
for (Long viewerId : blockedWithAuthor) {
    HiddenStatus hidden = new HiddenStatus();
    hidden.setStatus(status);
    hidden.setViewer(userRepository.getReferenceById(viewerId));
    rows.add(hidden);
}
hiddenStatusRepository.saveAll(rows);
```

For every user in a block relationship with the author **in either direction** (`blockedOrBlockingIds`, §5), insert a `HiddenStatus` row. Key detail: `userRepository.getReferenceById(viewerId)` returns a **lazy Hibernate proxy** carrying only the id — it does **not** hit the DB to load the `User`. Because only the `viewer_id` FK column is written, the full row is never needed, so the proxy avoids N extra SELECTs. `saveAll` batches the inserts. If nobody is blocked, the method returns early and no rows are written.

### 4.3 `getMyStatuses(userId)` — `@Transactional(readOnly = true)`

```java
List<Status> statuses = statusRepository
        .findByAuthorIdAndExpiresAtAfterOrderByCreatedAtAsc(userId, Instant.now());
return toResponses(statuses, userId);
```

Your own **live** statuses, oldest-first (story-playback order). No block filtering — these are yours. `readOnly = true` lets Hibernate skip dirty-checking/flush and hints the driver that the tx won't write. Mapping via `toResponse` (author branch) fills `viewCount` per status.

### 4.4 `getContactStatuses(userId)` — `@Transactional(readOnly = true)`

```java
List<Long> contactIds = contactUserIdsOf(userId);
if (contactIds.isEmpty()) return List.of();

Set<Long> excludedIds = blockedOrBlockingIds(userId);

List<Long> visibleAuthorIds = new ArrayList<>();
for (Long contactId : contactIds) {
    boolean excluded = excludedIds.contains(contactId);
    if (!excluded) visibleAuthorIds.add(contactId);
}
if (visibleAuthorIds.isEmpty()) return List.of();

List<Status> statuses = statusRepository.findActiveByAuthorIds(visibleAuthorIds, Instant.now());
List<Status> visibleStatuses = removeHiddenForViewer(statuses, userId);
return toResponses(visibleStatuses, userId);
```

The contacts feed, in five steps:
1. **Audience = your contacts.** `contactUserIdsOf(userId)` resolves the contact-user ids via `ContactRepository.findByOwner_Id` (each `Contact.getContact().getId()`). Status visibility is **contact-gated**: only people you've saved as contacts can appear. Empty contacts → empty feed.
2. **Compute current-block exclusions** — `blockedOrBlockingIds(userId)` (both directions, §5).
3. **Current-block filter** — drop any contact who is currently blocked/blocking. Empty → empty feed.
4. **Fetch live statuses** for the surviving authors with `findActiveByAuthorIds(..., Instant.now())` (live-only, newest-first).
5. **Durable suppression filter** — `removeHiddenForViewer(statuses, userId)` removes statuses for which a `HiddenStatus` row exists for this viewer (the during-block window, §5).

#### `removeHiddenForViewer(statuses, viewerId)`

```java
if (statuses.isEmpty()) return statuses;

List<Long> statusIds = new ArrayList<>();
for (Status status : statuses) statusIds.add(status.getId());

Set<Long> hiddenIds = new HashSet<>();
for (HiddenStatus hidden : hiddenStatusRepository.findByViewer_IdAndStatus_IdIn(viewerId, statusIds)) {
    hiddenIds.add(hidden.getStatus().getId());
}
if (hiddenIds.isEmpty()) return statuses;

List<Status> visible = new ArrayList<>();
for (Status status : statuses) {
    boolean hidden = hiddenIds.contains(status.getId());
    if (!hidden) visible.add(status);
}
return visible;
```

Collect candidate status ids, query suppression rows for this viewer over that batch in **one** call (`findByViewer_IdAndStatus_IdIn`), build a `HashSet` of hidden ids, then filter in memory. O(n) with a single extra query rather than per-status lookups.

### 4.5 `viewStatus(viewerId, statusId)` — `@Transactional` (write)

```java
Status status = findStatusOrThrow(statusId);

boolean expired = status.getExpiresAt().isBefore(Instant.now());
if (expired) throw new ApiException(HttpStatus.GONE, "This status has expired.");

boolean viewerIsAuthor = status.getAuthor().getId().equals(viewerId);
if (viewerIsAuthor) return;                                   // authors don't count as viewers

boolean alreadyViewed = statusViewRepository.existsByStatusIdAndViewerId(statusId, viewerId);
if (alreadyViewed) return;                                    // idempotent

StatusView view = new StatusView();
view.setStatus(status);
view.setViewer(findUserOrThrow(viewerId));
statusViewRepository.save(view);

Long authorId = status.getAuthor().getId();
messagingTemplate.convertAndSendToUser(
        authorId.toString(), STATUS_VIEWS_QUEUE, new StatusViewEvent(statusId));
```

Steps:
1. Load status (404 if missing).
2. **Expiry gate** — expired → `410 GONE`. You can't "view" an expired status.
3. **Author short-circuit** — author viewing their own status is a no-op; authors are not their own viewers.
4. **Dedupe** — if a `StatusView` already exists for (status, viewer), return without writing. This pairs with the `uq_status_viewer` unique constraint, which catches any concurrent double-submit that races past this check.
5. **Record the view** — insert a `StatusView` (`viewedAt` auto-stamped).
6. **Real-time push** — `messagingTemplate.convertAndSendToUser(authorId.toString(), "/queue/status-views", new StatusViewEvent(statusId))` sends a `StatusViewEvent` to the **author** over WebSocket/STOMP so their viewers UI updates live. Routing is by user (the author), to the user-scoped destination `/queue/status-views`. (See §7 and the message/WebSocket doc for the STOMP user-destination mechanics.)

Because the method is `@Transactional`, the `StatusView` insert and the message dispatch happen within the same transaction; the WS send is a side effect (note: it is invoked before commit, so it is best-effort relative to the DB write).

### 4.6 `getStatusViewers(requesterId, statusId)` — `@Transactional(readOnly = true)`

```java
Status status = findStatusOrThrow(statusId);

boolean requesterIsAuthor = status.getAuthor().getId().equals(requesterId);
if (!requesterIsAuthor) throw new ApiException(HttpStatus.FORBIDDEN, "Only the author can see viewers.");

List<StatusView> views = statusViewRepository.findByStatusIdOrderByViewedAtDesc(statusId);
List<StatusViewerResponse> responses = new ArrayList<>();
for (StatusView view : views) responses.add(toViewerResponse(view));
return responses;
```

**Authorization: author-only.** A non-author gets `403 FORBIDDEN` — only the poster sees who viewed. Views are returned most-recent-first. `toViewerResponse` maps each `StatusView` to `StatusViewerResponse(viewerId, viewerName, presignedAvatarUrl, viewedAt)`, presigning the viewer's avatar key.

### 4.7 `replyToStatus(replyerId, statusId, request)` — `@Transactional` (write)

```java
Status status = findStatusOrThrow(statusId);

boolean expired = status.getExpiresAt().isBefore(Instant.now());
if (expired) throw new ApiException(HttpStatus.GONE, "This status has expired.");

boolean replyingToOwnStatus = status.getAuthor().getId().equals(replyerId);
if (replyingToOwnStatus) throw new ApiException(HttpStatus.BAD_REQUEST, "You cannot reply to your own status.");

SendMessageRequest dmRequest = new SendMessageRequest();
dmRequest.setReceiverId(status.getAuthor().getId());
dmRequest.setContent(request.getContent());
dmRequest.setReplyToStatusId(statusId);

return chatService.sendDirectMessage(replyerId, dmRequest);
```

A status reply **is a direct message** to the author. Steps:
1. Load status (404 if missing).
2. **Expiry gate** — `410 GONE` if expired.
3. **Self-reply guard** — `400` if you try to reply to your own status.
4. **Build a DM request** — receiver = author, content = the reply text, and crucially `replyToStatusId = statusId`. This tags the message as a status reply.
5. **Delegate to `ChatService.sendDirectMessage(replyerId, dmRequest)`** and return its `ChatMessageResponse`.

On the chat side, `sendDirectMessage` persists the message with `message.setReplyToStatusId(request.getReplyToStatusId())`, then `buildStatusPreview(replyToStatusId)` produces a `StatusPreviewDto` so the bubble renders the quoted status. It also runs the chat block check (`blockService.isBlockedBetween`) — if blocked, the message is saved but not delivered/notified. Thus the reply rides the full DM pipeline (conversation id, receipts, WS fan-out, push notifications). See the message doc for that flow.

### 4.8 `deleteStatus(authorId, statusId)` — `@Transactional` (write)

```java
Optional<Status> maybeStatus = statusRepository.findByIdAndAuthorId(statusId, authorId);
if (maybeStatus.isEmpty()) {
    throw new ApiException(HttpStatus.NOT_FOUND, "Status not found or you are not the author.");
}
statusViewRepository.deleteByStatusId(statusId);
hiddenStatusRepository.deleteByStatus_Id(statusId);
statusRepository.delete(maybeStatus.get());
```

1. **Fetch with ownership** — `findByIdAndAuthorId` returns empty if the status is missing *or* not owned by the caller; either way → `404 "Status not found or you are not the author."` (deliberately ambiguous so a non-owner can't probe existence).
2. **FK cleanup, children first** — delete dependent `status_views`, then `hidden_statuses`, then the `Status`. There is no DB-level `ON DELETE CASCADE` configured for these associations, so the service must clear the child rows before deleting the parent or the `author_id`/`status_id` FK constraints would reject the delete. Order matters: children before parent. All three happen in one transaction, so a failure rolls the whole delete back.

### 4.9 Shared helpers

- **`toResponse(status, currentUserId)`** — the mapper. `isAuthor` decides which optional fields are filled: authors get `viewCount = countByStatusId(...)` (and `viewedByMe` stays `false`); non-authors get `viewedByMe = existsByStatusIdAndViewerId(...)` (and `viewCount` stays `null`). Both `authorAvatarUrl` and `mediaUrl` are passed through `storageService.presignedUrl(...)`, which **converts stored object keys into short-lived presigned GET URLs** (and returns `null` for null/blank keys). This is why the entity stores keys, not URLs — the response always carries a fresh, time-limited link.
- **`contactUserIdsOf(ownerId)`** — maps `ContactRepository.findByOwner_Id` to the list of contact-user ids.
- **`blockedOrBlockingIds(userId)`** — union of `blockService.blockedIdsOf(userId)` and `blockService.blockersOf(userId)` (§5).
- **`findStatusOrThrow` / `findUserOrThrow`** — `findById` + 404 on absence.

---

## 5. Block interaction in depth (WhatsApp parity)

This is the most subtle part of the feature. The rule: **a blocked relationship hides statuses in both directions, and statuses posted during a block must never leak after unblock.** Two mechanisms enforce it.

### 5.1 Bidirectional block set

```java
private Set<Long> blockedOrBlockingIds(Long userId) {
    Set<Long> excludedIds = new HashSet<>();
    excludedIds.addAll(blockService.blockedIdsOf(userId));   // users this user blocked
    excludedIds.addAll(blockService.blockersOf(userId));     // users who blocked this user
    return excludedIds;
}
```

`blockedIdsOf` (people *I* blocked) ∪ `blockersOf` (people who blocked *me*). The union is symmetric: if either party blocked the other, neither sees the other's statuses. `BlockService` exposes these as `findBlockedIdsByBlocker` / `findBlockerIdsByBlocked` and is itself `@Transactional(readOnly = true)`.

### 5.2 Mechanism A — current-block exclusion at READ time

In `getContactStatuses`, after listing contacts, the service removes anyone in `blockedOrBlockingIds(userId)` *before* fetching statuses:

```java
Set<Long> excludedIds = blockedOrBlockingIds(userId);
...
boolean excluded = excludedIds.contains(contactId);
if (!excluded) visibleAuthorIds.add(contactId);
```

Effect: **while a block is active**, the viewer sees *none* of the blocked author's statuses — including ones posted before the block. This is the live, reversible part: unblock and (assuming no `HiddenStatus` rows) those still-live pre-block statuses become visible again, matching WhatsApp.

### 5.3 Mechanism B — durable `HiddenStatus` at WRITE time

In `createStatus`, the author records suppression for everyone currently in a block relationship with them:

```java
private void hideFromBlockedViewers(Status status, Long authorId) {
    Set<Long> blockedWithAuthor = blockedOrBlockingIds(authorId);
    if (blockedWithAuthor.isEmpty()) return;
    ...
    for (Long viewerId : blockedWithAuthor) {
        HiddenStatus hidden = new HiddenStatus();
        hidden.setStatus(status);
        hidden.setViewer(userRepository.getReferenceById(viewerId));
        rows.add(hidden);
    }
    hiddenStatusRepository.saveAll(rows);
}
```

These rows are **permanent** (only removed when the status itself is deleted, §4.8). At read time, `removeHiddenForViewer` strips any status with a matching `(status, viewer)` row even after the block is gone.

### 5.4 Why both are needed — the walkthrough

Block active → Alice posts S → Alice unblocks Bob:
- When S was created, `hideFromBlockedViewers` wrote `HiddenStatus(S, Bob)` because Bob was in Alice's block set.
- After unblock, **Mechanism A no longer excludes** Bob (the block row is gone), so S would survive the contact filter and be fetched by `findActiveByAuthorIds`.
- But **Mechanism B still suppresses** S: `removeHiddenForViewer` finds `HiddenStatus(S, Bob)` and drops it. Bob never sees the during-block status. WhatsApp parity achieved.

Conversely, a status Alice posted *before* blocking Bob has **no** `HiddenStatus` row, so after unblock it reappears (if still live) — also correct.

### 5.5 Block interaction on reply

`replyToStatus` delegates to `ChatService.sendDirectMessage`, which independently calls `blockService.isBlockedBetween(sender, receiver)`; if blocked, the reply message is persisted but not delivered or notified. Status reply visibility therefore inherits the chat layer's block semantics on top of the status-feed semantics above.

---

## 6. Expiry model

Status is **soft-expiring**, not hard-deleted on a timer:

- **Window** — set once at creation: `Instant expiresAt = Instant.now().plus(24, ChronoUnit.HOURS)`. `createdAt` is the `@CreationTimestamp`; `expiresAt` is the explicit 24h horizon.
- **Read filter** — every feed query excludes expired rows by comparing `expiresAt` to *now*:
  - JPQL: `... AND s.expiresAt > :now ...` (`findActiveByAuthorIds`)
  - derived: `findByAuthorIdAndExpiresAtAfter...` → `expiresAt > now`
  Both are passed `Instant.now()` at call time.
- **Action gates** — `viewStatus` and `replyToStatus` each re-check `status.getExpiresAt().isBefore(Instant.now())` and throw `410 GONE` if expired. So even a directly-referenced (non-feed) expired status can't be viewed or replied to.
- **No hard delete** — there is **no scheduled job** that purges expired rows; they simply stop matching read queries. Expired statuses remain in `statuses` (with their `status_views`/`hidden_statuses`) until the author explicitly deletes them via `DELETE /{statusId}`. The composite index `(author_id, expires_at)` keeps the `expiresAt > now` range scans cheap even as dead rows accumulate. (A reviewer may note that without a reaper these tables grow unbounded; that's a deliberate current trade-off, not a bug in the read path.)

---

## 7. Libraries & framework mechanisms — what / why / how

### JPA / Hibernate entity mapping
- **What:** `@Entity` + `@Table` map `Status`/`StatusView`/`HiddenStatus` to tables; `@ManyToOne(fetch = LAZY)` + `@JoinColumn` model the FKs to `User`/`Status`; `@Id @GeneratedValue(IDENTITY)` delegate PK generation to the DB auto-increment.
- **Why:** declarative O/R mapping; `LAZY` avoids eagerly loading associated `User`/`Status` graphs on every fetch.
- **How:** lazy associations resolve only on access, inside an open persistence context — which is why every method touching `status.getAuthor()...` is `@Transactional(...)`. Pointers: `Status.java:28-30`, `StatusView.java:30-36`, `HiddenStatus.java:29-35`.

### `@Query` JPQL vs derived queries
- **What:** two ways to declare repository methods — hand-written JPQL (`@Query`) and method-name parsing.
- **Why:** JPQL for multi-condition/`IN`/explicit-ordering reads (`findActiveByAuthorIds`, `findByIdAndAuthorId`); derived names for simple predicates (`findByAuthorIdAndExpiresAtAfterOrderByCreatedAtAsc`, the `StatusViewRepository` methods, `findByViewer_IdAndStatus_IdIn`).
- **How:** `@Param` binds named parameters; the `Property_Sub` underscore syntax navigates associations. Pointers: `StatusRepository.java:12-19`, `HiddenStatusRepository.java:9`.

### `@Index` (composite)
- **What:** `@Index(name = "idx_status_author_expires", columnList = "author_id, expires_at")` on `Status`.
- **Why:** both feed queries filter on author + expiry; a composite index serves both.
- **How:** Hibernate emits the `CREATE INDEX` in DDL; the DB seeks by `author_id` and range-scans `expires_at`. Pointer: `Status.java:14-17`.

### `@Column(length = ...)` and `@UniqueConstraint`
- **What:** `@Column(length = 700)` sizes `content` to `VARCHAR(700)`; the unique constraints `uq_status_viewer` and `uq_hidden_status_viewer` enforce one row per `(status, viewer)`.
- **Why:** DB-level cap mirrors the API cap; unique constraints are the integrity backstop behind the app-level dedupe/idempotency checks.
- **How:** generated as column type / `UNIQUE (...)` in DDL. Pointers: `Status.java:32`, `StatusView.java:16-19`, `HiddenStatus.java:15-18`.

### `java.time.Instant` + `ChronoUnit`
- **What:** UTC-instant time type; `ChronoUnit.HOURS` is the unit for the offset.
- **Why:** timezone-free, comparison-friendly instants for createdAt/expiresAt and `isBefore` gates.
- **How:** `Instant.now().plus(24, ChronoUnit.HOURS)` (`StatusService.java:95`); `getExpiresAt().isBefore(Instant.now())` in the view/reply gates.

### `@Transactional` — readOnly vs write
- **What:** declarative transaction boundary; `readOnly = true` marks a no-write tx.
- **Why:** writes (`createStatus`, `viewStatus`, `replyToStatus`, `deleteStatus`) need atomicity (e.g. multi-table FK cleanup in delete); reads (`getMyStatuses`, `getContactStatuses`, `getStatusViewers`) use `readOnly` so Hibernate skips dirty-checking/flush and the driver can optimize. `uploadStatusMedia` is intentionally non-transactional (single external call, no DB write).
- **How:** Spring AOP proxy opens/commits/rolls back around the method; `ApiException` (a `RuntimeException`) triggers rollback on writes. Pointers throughout `StatusService.java`.

### `SimpMessagingTemplate.convertAndSendToUser` (status-view event)
- **What:** STOMP/WebSocket push of `StatusViewEvent` to the author when their status is viewed.
- **Why:** real-time "seen" updates without polling.
- **How:** `messagingTemplate.convertAndSendToUser(authorId.toString(), "/queue/status-views", new StatusViewEvent(statusId))` routes to the user-scoped destination for that author (`StatusService.java:211-212`). Mechanics of user-destination routing/STOMP setup are covered in the **message / WebSocket doc**.

### MinIO via `StorageService`
- **What:** object storage for status media; entities store object **keys**, responses carry **presigned URLs**.
- **Why:** keep large binaries out of the DB; serve them via short-lived signed links.
- **How:** `storageService.upload("status", file)` returns a key; `storageService.presignedUrl(key)` (used in `toResponse`/`toViewerResponse`) returns a time-limited GET URL (null-safe). Full MinIO config (`PutObjectArgs`, presign expiry) is in the **storage / media doc**; summarized here.

### `getReferenceById` (FK proxy without a DB read)
- **What:** `userRepository.getReferenceById(viewerId)` returns a lazy `User` proxy holding only the id.
- **Why:** in `hideFromBlockedViewers` only the `viewer_id` FK is written, so loading the full `User` is wasted I/O.
- **How:** Hibernate writes the id from the proxy at INSERT; no SELECT is issued unless a non-id field is touched (it isn't). Pointer: `StatusService.java:118`. (Caveat for reviewers: if the referenced user didn't exist, the failure would surface lazily/at flush rather than as an immediate 404 — acceptable here since the ids come from the block tables.)

---

## Quick reference — request to outcome

- **Post with media:** `POST /upload` (key) → `POST /` with `mediaUrl=key` → row in `statuses` (24h expiry) + `hidden_statuses` rows for blocked parties → `201` `StatusResponse` (presigned media URL).
- **See a contact's status:** `GET /` → contacts − current-blocks → live statuses − `HiddenStatus` suppressions → list (newest first).
- **Mark viewed:** `POST /{id}/view` → dedup insert `status_views` → WS `StatusViewEvent` to author.
- **See who viewed:** `GET /{id}/viewers` → author-only → viewers newest-first.
- **Reply:** `POST /{id}/reply` → DM to author tagged `replyToStatusId` via `ChatService`.
- **Delete:** `DELETE /{id}` → ownership check → cascade-clean `status_views` + `hidden_statuses` → delete `statuses` row.
