# 00 — Foundations

This is the **common** backend doc for Pulse. Every feature doc (auth, chat, groups, media, presence, WebSocket) assumes you have read this one. It explains how the Spring Boot application boots, how a request flows from socket to database and back, the cross-cutting building blocks in `com.mohan.pulse.common`, the configuration in `com.mohan.pulse.config`, and the libraries that make all of it work.

Everything below is grounded in the actual source. File paths are relative to the repository root unless stated otherwise.

---

## 1. How the app boots

### Entry point

`src/main/java/com/mohan/pulse/PulseApplication.java:`

```java
@SpringBootApplication
public class PulseApplication {
	public static void main(String[] args) {
		SpringApplication.run(PulseApplication.class, args);
	}
}
```

This tiny class is the seed for the entire backend. Two things make it work: the `@SpringBootApplication` annotation and the `SpringApplication.run(...)` call.

### `@SpringBootApplication`

`@SpringBootApplication` is a **meta-annotation** — it bundles three annotations that you would otherwise write by hand:

1. **`@SpringBootConfiguration`** — a specialization of `@Configuration`. It marks this class as a source of bean definitions, so `@Bean` methods anywhere in the configured packages are honored.
2. **`@EnableAutoConfiguration`** — the heart of Spring Boot. It tells Boot to look at what is on the classpath and *guess* sensible bean configurations. Because `spring-boot-starter-web` is present (see `pom.xml`), Boot auto-configures an embedded Tomcat, a `DispatcherServlet`, a Jackson `ObjectMapper`, message converters, etc. Because `spring-boot-starter-data-jpa` and `postgresql` are present, it auto-configures a `DataSource`, a Hibernate `EntityManagerFactory`, a `JpaTransactionManager`, and Spring Data repository proxies. Because `spring-boot-starter-security` is present, it sets up a security filter chain. None of this is written by us — it is inferred from dependencies.
3. **`@ComponentScan`** — starts scanning for components (`@Component`, `@Service`, `@Repository`, `@RestController`, `@Configuration`, ...) **from the package of this class downward**. `PulseApplication` lives in `com.mohan.pulse`, so every sub-package (`auth`, `user`, `chat`, `config`, `common`, ...) is scanned automatically. This is why we never register controllers or services manually — being in the right package and carrying a stereotype annotation is enough.

> Defend-it note: the *placement* of `PulseApplication` in the root package `com.mohan.pulse` is not cosmetic. Component scanning is package-relative; if this class were moved into a sub-package, half the beans would silently stop being discovered.

### `SpringApplication.run(...)`

`SpringApplication.run(PulseApplication.class, args)` does the actual bootstrapping:

1. Creates the **`ApplicationContext`** — the in-memory container that holds every bean (singletons by default) and their wiring.
2. Reads configuration property sources: `application.properties`, profile-specific files like `application-prod.properties` (activated by `SPRING_PROFILES_ACTIVE=prod`), OS environment variables, and JVM system properties, merged by precedence.
3. Runs auto-configuration and component scanning, instantiating each bean and injecting its dependencies.
4. Starts the **embedded Tomcat** server. There is no external servlet container and no `web.xml`; Tomcat is a library dependency pulled in transitively by `spring-boot-starter-web`, and Boot starts it inside the same JVM, binding to `server.port=8080` (from `application.properties`).
5. Returns the running context. From this point the app is live and accepting HTTP/WebSocket connections.

### The application context, beans, and dependency injection

A **bean** is any object whose lifecycle Spring manages. Spring instantiates beans, wires their dependencies, and (for singletons, the default scope) keeps exactly one instance in the context.

Pulse uses **constructor injection** everywhere — the recommended style. Look at `AuthController` (`src/main/java/com/mohan/pulse/auth/AuthController.java`):

```java
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }
    ...
}
```

`AuthController` declares it *needs* an `AuthService`. When Spring builds the context it sees a single constructor, finds a matching `AuthService` bean (itself a `@Service` discovered by component scan), and passes it in. No `new AuthService()` anywhere; no `@Autowired` needed (a single constructor is autowired implicitly).

Why constructor injection (and why you should say this in review):

- The field is `final` → the dependency is **immutable** and can never be null after construction.
- The object is **fully initialized** the moment it exists; there is no half-built window where a dependency is still null.
- It makes dependencies **explicit and testable** — in a unit test you just `new AuthController(mockService)` without any Spring machinery.

This is **Inversion of Control (IoC)**: the class does not look up or build its collaborators; the container supplies them. Spring is the IoC container; DI is the mechanism it uses.

---

## 2. Layered architecture

Pulse follows the classic three-layer (plus DTO) structure. Each feature is a package (e.g. `auth`, `user`, `chat`) that internally splits into these roles:

```
HTTP request
   │
   ▼
Controller   (@RestController)      — HTTP concerns only
   │  calls
   ▼
Service      (@Service)            — business logic, orchestration, @Transactional
   │  calls
   ▼
Repository   (Spring Data JPA)     — persistence, query methods
   │
   ▼
Database     (PostgreSQL via Hibernate)
```

**Controller** — the only layer that knows about HTTP. It maps URLs to methods, deserializes the request body, validates input, delegates to a service, and wraps the result in `ApiResponse`. It should contain *no* business rules. `AuthController.signup` is the model: validate, call `authService.signup(request)`, wrap in `ApiResponse.ok(...)`.

**Service** — the brain. It enforces business rules (e.g. "phone must be unique", "you can only message a contact"), coordinates multiple repositories, performs mapping to/from DTOs, and owns transaction boundaries via `@Transactional`. Services throw `ApiException` when a rule is violated.

**Repository** — the persistence boundary. In Pulse these are Spring Data JPA interfaces (e.g. `UserRepository extends JpaRepository<User, Long>`). We declare method signatures; Spring generates the implementation at runtime. The repository talks to Hibernate, which talks to PostgreSQL.

**Entity** — a class mapped to a DB table via JPA annotations (see `User` below). Entities live at the persistence layer.

**DTO** — request/response shapes (`SignupRequest`, `LoginRequest`, `AuthResponse`, ...) that decouple the API contract from the database schema. Controllers and services exchange DTOs; entities should not leak to the client.

> Defend-it note: the discipline that matters in review is "no business logic in controllers, no HTTP types in services." A controller method should read like a four-line orchestration. The entity should never be serialized straight to the client — that couples your wire format to your schema and risks leaking fields like `passwordHash` (see `User` below, where `passwordHash` is a real column).

---

## 3. The HTTP request lifecycle, end to end

Trace a real call: `POST /api/auth/signup` with a JSON body.

```
TCP → Tomcat → Servlet Filters (incl. Spring Security) → DispatcherServlet
   → HandlerMapping picks AuthController.signup
   → @RequestBody: Jackson deserializes JSON → SignupRequest
   → @Valid: Bean Validation runs the constraints on SignupRequest
   → method body: authService.signup(request)
   → returns ApiResponse<AuthResponse>
   → Jackson serializes the return value → JSON
   → DispatcherServlet writes the HTTP response
```

Step by step:

1. **Tomcat** accepts the connection and hands the request to the servlet pipeline.
2. **Filters** run first. Spring Security's filter chain authenticates the request (details in the auth doc) and CORS is applied here.
3. The **`DispatcherServlet`** (auto-configured front controller) receives the request and asks the **HandlerMapping** which method handles `POST /api/auth/signup`. The answer is `AuthController.signup`, because the class is `@RequestMapping("/api/auth")` and the method is `@PostMapping("/signup")`.
4. **`@RequestBody SignupRequest request`** — Spring uses the Jackson `MappingJackson2HttpMessageConverter` to **deserialize** the request body JSON into a `SignupRequest` object. Jackson matches JSON keys to Java fields/setters by name.
5. **`@Valid`** — before the method body runs, Spring invokes Bean Validation (Hibernate Validator, pulled in by `spring-boot-starter-validation`) on the deserialized object. Constraint annotations like `@NotBlank`, `@Size`, `@Pattern` on `SignupRequest` fields are checked. If any fail, Spring throws `MethodArgumentNotValidException` **before** your code runs — the method never sees invalid data. That exception is caught by the global handler (section 5) and turned into a 400.
6. **Path / query params** — not used by signup, but the same dispatch supports them. `@PathVariable Long id` binds a `{id}` URL segment; `@RequestParam String q` binds `?q=...`. A missing required `@RequestParam` throws `MissingServletRequestParameterException`, also handled globally.
7. **Method body** runs: `AuthResponse result = authService.signup(request);`. Business logic and persistence happen here, inside the service.
8. **Return value** — the method returns `ApiResponse<AuthResponse>`. Because the class is `@RestController`, the return value is treated as the response body (not a view name).
9. **Jackson serialization** — the converter serializes `ApiResponse<AuthResponse>` to JSON. The default status is **200 OK** (we wrap success there; non-200 statuses are produced by `ResponseEntity` in the exception handler — section 5).
10. The response bytes go back through the filter chain and out via Tomcat.

This is the same path for every endpoint; only the deserialized type, the validation constraints, and the service call differ.

---

## 4. The uniform response envelope: `ApiResponse<T>`

Every successful response shares one shape so the frontend can parse uniformly. `src/main/java/com/mohan/pulse/common/ApiResponse.java`:

```java
@Getter
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> {

    private final boolean success;
    private final String message;
    private final T data;
    private final Instant timestamp;

    public static <T> ApiResponse<T> ok(T data) {
        return new ApiResponse<>(true, null, data, Instant.now());
    }

    public static <T> ApiResponse<T> ok(String message, T data) {
        return new ApiResponse<>(true, message, data, Instant.now());
    }

    public static <T> ApiResponse<T> error(String message) {
        return new ApiResponse<>(false, message, null, Instant.now());
    }
}
```

Key points to explain in review:

- **Generic `<T>`** — `data` is typed to whatever payload an endpoint returns: `ApiResponse<AuthResponse>`, `ApiResponse<List<MessageDto>>`, etc. The compiler enforces the payload type per endpoint while the envelope stays identical. The static factory methods are themselves generic (`public static <T> ApiResponse<T> ok(...)`) so the compiler infers `T` from the argument.
- **Factory methods, not public constructors** — `ok(data)`, `ok(message, data)`, and `error(message)` are the only intended entry points. They centralize the rules: success responses always set `success = true` and may carry a message; errors set `success = false`, `data = null`. (`@AllArgsConstructor` generates the all-args constructor that these factories call.)
- **`@JsonInclude(JsonInclude.Include.NON_NULL)`** — fields that are `null` are **omitted** from the serialized JSON. So `ok(data)` (no message) produces `{"success":true,"data":{...},"timestamp":"..."}` with no `"message"` key, and `error(msg)` produces a body with no `"data"` key. This keeps payloads lean and avoids `"message": null` noise.
- **Immutability** — all fields are `final` and only `@Getter` is generated (no setters), so a response object can't be mutated after construction.
- **`timestamp`** is an `Instant` stamped at creation; Jackson serializes it to an ISO-8601 string (`2026-06-28T...Z`) via JSR-310 support that Boot configures by default.

A typical success body:

```json
{
  "success": true,
  "message": "Account created successfully",
  "data": { "token": "…", "user": { … } },
  "timestamp": "2026-06-28T10:15:30.123Z"
}
```

---

## 5. Error handling

### `ApiException` — the application's deliberate failure type

`src/main/java/com/mohan/pulse/common/ApiException.java`:

```java
public class ApiException extends RuntimeException {

    private final HttpStatus status;

    public ApiException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    public HttpStatus getStatus() {
        return status;
    }
}
```

- It extends **`RuntimeException`**, i.e. it is **unchecked** — services throw it without `throws` clauses and without try/catch boilerplate cluttering callers. An unchecked exception thrown deep in a service propagates up the call stack until the global handler catches it.
- It **carries an `HttpStatus`** alongside the message. This is the bridge between business semantics and HTTP: a service decides "this is a 404" or "this is a 401" by throwing `new ApiException(HttpStatus.NOT_FOUND, "...")`. We saw this in `SecurityUtil`, which throws `new ApiException(HttpStatus.UNAUTHORIZED, "You are not logged in.")`.

### `GlobalExceptionHandler` — one place that turns exceptions into responses

`src/main/java/com/mohan/pulse/common/GlobalExceptionHandler.java` is annotated `@RestControllerAdvice`. This makes it a **global, cross-controller exception interceptor**: any exception that escapes any controller method is offered to its `@ExceptionHandler` methods. `@RestControllerAdvice` = `@ControllerAdvice` + `@ResponseBody`, so the returned objects are serialized to JSON (consistent with `@RestController`).

Each handler returns a **`ResponseEntity<ApiResponse<Object>>`** — `ResponseEntity` lets us set both the **HTTP status code** and the **body** explicitly, which is exactly what we need because the body type (`ApiResponse`) is uniform but the status varies.

The handlers, in order:

1. **`ApiException` → its own status.** This is the main path for deliberate business errors:

   ```java
   @ExceptionHandler(ApiException.class)
   public ResponseEntity<ApiResponse<Object>> handleApiException(ApiException ex) {
       ApiResponse<Object> body = ApiResponse.error(ex.getMessage());
       return ResponseEntity.status(ex.getStatus()).body(body);
   }
   ```
   The status comes from `ex.getStatus()`, the message from `ex.getMessage()`. So a service throwing `ApiException(NOT_FOUND, "User not found")` becomes a 404 with `{"success":false,"message":"User not found",...}`.

2. **`MethodArgumentNotValidException` → 400.** Thrown by `@Valid` failures. The handler walks every `FieldError` and joins them into one message:

   ```java
   for (FieldError fieldError : ex.getBindingResult().getFieldErrors()) {
       messages.add(formatFieldError(fieldError));
   }
   String combinedErrors = String.join(", ", messages);
   ```
   `formatFieldError` produces `"field: default message"` (e.g. `"phone: must not be blank"`), so a client gets a readable, aggregated 400.

3. **`MissingServletRequestParameterException` → 400.** A required `@RequestParam` was absent; the message names the parameter: `"Required parameter 'x' is missing."`.

4. **`HttpRequestMethodNotSupportedException` → 405.** Wrong HTTP verb on a known path (e.g. `GET` on a `POST`-only endpoint): `"Method GET is not supported for this endpoint."`.

5. **`NoResourceFoundException` → 404.** Spring MVC's "no handler / static resource not found." Returns `"The requested resource was not found."`.

6. **`Exception` → 500.** The catch-all. Anything unanticipated returns a generic `"Something went wrong. Please try again."` with status 500 — deliberately vague so internal details and stack traces never leak to clients.

> Defend-it note: order/specificity matters — Spring picks the **most specific** matching handler, so `ApiException`, the validation exception, etc. are matched before the generic `Exception` fallback. The fallback is what keeps an unexpected `NullPointerException` from returning a raw 500 with a stack trace. Every error, regardless of source, comes back in the same `ApiResponse` envelope, so the frontend has exactly one error shape to handle.

---

## 6. `SecurityUtil.currentUserId()` — reading the authenticated user

`src/main/java/com/mohan/pulse/common/SecurityUtil.java`:

```java
public final class SecurityUtil {

    private SecurityUtil() { }

    public static Long currentUserId() {
        Authentication authentication =
                SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "You are not logged in.");
        }

        Object principal = authentication.getPrincipal();

        if (principal instanceof Long userId) {
            return userId;
        }

        throw new ApiException(HttpStatus.UNAUTHORIZED, "Could not identify the current user.");
    }
}
```

What to know here (full auth flow is in the auth doc):

- **`SecurityContextHolder`** is Spring Security's thread-local holder for the current request's `SecurityContext`. By default it uses thread-local storage, so within a single request thread you can read "who is calling" from anywhere without passing the user id through every method signature.
- The JWT filter (auth doc) authenticates each request and stores an `Authentication` whose **principal is the user's `Long` id**. That is the contract this method relies on: `principal instanceof Long userId`.
- If there is **no authentication** or it is not authenticated, it throws `ApiException(UNAUTHORIZED, ...)` → 401 via the global handler.
- If the principal is **not a `Long`** (unexpected, defensive), it also throws 401 — it never returns a bogus id.
- The class is `final` with a **private constructor** — it is a pure static utility and must never be instantiated. Services call `SecurityUtil.currentUserId()` to know who is acting, instead of trusting any id sent in the request body (which would be forgeable).

> Defend-it note: relying on the server-side `SecurityContext` rather than a client-supplied user id is the security-correct choice — a client cannot impersonate another user by changing a request field.

---

## 7. `ConversationUtil` — the `dm:` / `group:` id scheme

Pulse identifies a conversation by a **single string** rather than juggling pairs of ids. `src/main/java/com/mohan/pulse/common/ConversationUtil.java`:

```java
public final class ConversationUtil {

    private ConversationUtil() { }

    public static String dmConversationId(Long userIdA, Long userIdB) {
        long smaller = Math.min(userIdA, userIdB);
        long larger  = Math.max(userIdA, userIdB);
        return "dm:" + smaller + ":" + larger;
    }

    public static String groupConversationId(Long groupId) {
        return "group:" + groupId;
    }

    public static boolean isGroup(String conversationId) {
        return conversationId != null && conversationId.startsWith("group:");
    }

    public static boolean isDirect(String conversationId) {
        return conversationId != null && conversationId.startsWith("dm:");
    }

    public static Long groupIdFrom(String conversationId) {
        return Long.valueOf(conversationId.substring("group:".length()));
    }

    public static long[] dmParticipants(String conversationId) {
        String[] parts = conversationId.split(":");
        return new long[] { Long.parseLong(parts[1]), Long.parseLong(parts[2]) };
    }
}
```

The scheme:

- A **direct message** between users 7 and 3 → `"dm:3:7"`. The two ids are sorted (`min`/`max`) so the id is **canonical and order-independent**: whether user 7 opens a chat with 3 or 3 opens one with 7, both compute the *same* `"dm:3:7"`. This is what lets the system find the one shared DM thread without a join table lookup — defend this as the reason there is no ambiguity about "which conversation."
- A **group** with id 42 → `"group:42"`.
- `isGroup` / `isDirect` discriminate the two kinds by prefix.
- `groupIdFrom` / `dmParticipants` are the inverse parsers: pull the group id back out, or recover both participant ids from a DM id.
- Again `final` + private constructor → pure static utility.

Many features (chat, presence, WebSocket routing, read receipts) key off these ids, which is why this utility lives in `common` and is documented here rather than in a single feature doc.

> Defend-it caveat worth acknowledging in review: `dmParticipants` and `groupIdFrom` assume well-formed ids and will throw `NumberFormatException`/`ArrayIndexOutOfBoundsException` on malformed input. That is acceptable because conversation ids are server-generated, never taken raw from untrusted clients without validation — but it's the kind of thing a reviewer will probe.

---

## 8. Configuration

### `CorsConfig` — cross-origin access for the browser frontend

`src/main/java/com/mohan/pulse/config/CorsConfig.java` is a `@Configuration` class exposing a `CorsConfigurationSource` `@Bean`:

```java
@Configuration
public class CorsConfig {

    @Value("${app.allowed-origins}")
    private String allowedOrigins;

    private static final List<String> ALLOWED_METHODS = List.of(
            "GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"
    );

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(parseOrigins(allowedOrigins));
        config.setAllowedMethods(ALLOWED_METHODS);
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    private static List<String> parseOrigins(String csv) { ... }
}
```

CORS (Cross-Origin Resource Sharing) is the browser rule that blocks a page served from origin A (e.g. `http://localhost:5173`, the Vite dev server) from calling an API on origin B (`http://localhost:8080`) unless B explicitly opts in. This bean is that opt-in:

- **`@Value("${app.allowed-origins}")`** injects the property `app.allowed-origins` from `application.properties` (which is itself env-driven — see below). `parseOrigins` splits the comma-separated list and trims blanks, so multiple front-end origins are supported.
- **Allowed methods** are the standard verbs plus `OPTIONS` (the CORS preflight verb).
- **`setAllowedHeaders(List.of("*"))`** permits any request header (needed because the client sends `Authorization` and `Content-Type`).
- **`setAllowCredentials(true)`** allows cookies / `Authorization` headers to be sent cross-origin. Note: when credentials are allowed, the spec forbids a wildcard `*` *origin*, which is precisely why origins are an explicit list while only *headers* use `*`.
- The config is registered for **`/**`** (all paths) on a `UrlBasedCorsConfigurationSource`. Spring Security picks up this `CorsConfigurationSource` bean and applies it in the filter chain.

### `WebMvcConfig`

`src/main/java/com/mohan/pulse/config/WebMvcConfig.java`:

```java
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
}
```

It implements `WebMvcConfigurer` but currently overrides nothing — it is the designated hook point for MVC customizations (custom resource handlers, interceptors, formatters, argument resolvers). Importantly, **there is no static/`uploads` resource handler here**: Pulse does **not** serve uploaded media off the local filesystem through Spring MVC. Media is stored in **MinIO** (S3-compatible object storage — see the `minio.*` properties and the `io.minio:minio` dependency in `pom.xml`) and served via presigned URLs, which is why no `addResourceHandlers` override exists. (Media specifics are in the media doc.)

### `application.properties` (default profile)

`src/main/resources/application.properties`:

```properties
spring.application.name=pulse

spring.datasource.url=jdbc:postgresql://localhost:5432/pulse_db
spring.datasource.username=postgres
spring.datasource.password=${DB_PASSWORD}

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true

server.port=8080

app.allowed-origins=${ALLOWED_ORIGINS:http://localhost:5173,http://localhost:5174}

app.jwt.secret=this-is-my-pulse-secret-key-1234567890
app.jwt.expiration-ms=86400000

spring.servlet.multipart.max-file-size=20MB
spring.servlet.multipart.max-request-size=20MB

# MinIO
minio.endpoint=${MINIO_ENDPOINT:http://localhost:9000}
minio.access-key=minioadmin
minio.secret-key=minioadmin123
minio.bucket=pulse-media
minio.presigned-expiry-minutes=60
```

Property-by-property:

- **`spring.datasource.url` / `.username` / `.password`** — the JDBC connection to PostgreSQL. Boot auto-configures a HikariCP connection pool and a `DataSource` from these three. Notice the password uses `${DB_PASSWORD}` — see env indirection below.
- **`spring.jpa.hibernate.ddl-auto=update`** — controls how Hibernate reconciles entity classes with the DB schema at startup. `update` means "create missing tables/columns to match the entities, but don't drop anything." Convenient in dev (your `@Entity` changes appear automatically) but **not safe for production** — it can apply partial, unreviewed schema changes. The prod profile overrides this (below).
- **`spring.jpa.show-sql=true`** + **`hibernate.format_sql=true`** — log every SQL statement Hibernate emits, pretty-printed. Great for understanding/debugging the ORM in dev; noisy and off in prod.
- **`server.port=8080`** — the embedded Tomcat port.
- **`app.allowed-origins`** — consumed by `CorsConfig`. Default falls back to the two Vite dev ports.
- **`app.jwt.secret` / `app.jwt.expiration-ms`** — JWT signing key and token lifetime (86400000 ms = 24h). Used by the auth/JWT components (auth doc). The literal secret here is a dev default and **must** be overridden in prod.
- **`spring.servlet.multipart.max-file-size` / `.max-request-size=20MB`** — caps for `multipart/form-data` uploads (media). Exceeding them yields a multipart exception, ultimately a 4xx/5xx via the handler chain.
- **`minio.*`** — endpoint, credentials, bucket, and presigned-URL expiry for the object store used for media.

### `application-prod.properties` (prod profile)

`src/main/resources/application-prod.properties`, activated with `SPRING_PROFILES_ACTIVE=prod`. Profile-specific properties **override** the base file:

```properties
spring.jpa.hibernate.ddl-auto=validate
spring.jpa.show-sql=false
spring.jpa.properties.hibernate.format_sql=false

management.endpoints.web.exposure.include=health
management.endpoint.health.probes.enabled=true
```

- **`ddl-auto=validate`** — in prod Hibernate only **checks** that the existing schema matches the entities and **fails fast** if not; it never alters the database. Schema changes in prod are expected to be applied by reviewed migrations, not by Hibernate. This is the single most important prod-vs-dev difference to call out in review.
- **`show-sql=false`** / **`format_sql=false`** — silence SQL logging in prod for performance and to avoid leaking query data into logs.
- **`management.endpoints.web.exposure.include=health`** + **`health.probes.enabled=true`** — expose only the Actuator `/actuator/health` endpoint (with Kubernetes-style liveness/readiness probes). Actuator comes from `spring-boot-starter-actuator` in `pom.xml`. Only `health` is exposed — other Actuator endpoints stay closed for security.

### Environment-variable indirection: `${VAR}` and `${VAR:default}`

Several properties use placeholder syntax so secrets and environment-specific values are injected at runtime rather than committed:

- **`spring.datasource.password=${DB_PASSWORD}`** — no default. The value **must** come from an environment variable `DB_PASSWORD` (or system property). If it is absent, startup fails — which is correct for a required secret.
- **`app.allowed-origins=${ALLOWED_ORIGINS:http://localhost:5173,http://localhost:5174}`** — the part after `:` is a **default**. If `ALLOWED_ORIGINS` is set in the environment it wins; otherwise the dev defaults apply.
- **`minio.endpoint=${MINIO_ENDPOINT:http://localhost:9000}`** — same pattern: prod points it at the real object store, dev falls back to localhost.

This lets the **same jar** run in dev and prod, configured entirely by environment variables — secrets never live in the repo. (The prod file's header comment confirms this intent: "All secrets and endpoints are supplied via environment variables.")

---

## Libraries & framework mechanisms

For each: **what** it is, **why** it's here, **how** it shows up in the code.

### Spring Boot auto-configuration & embedded server

- **What.** Boot inspects the classpath and conditionally creates beans you'd otherwise configure by hand, and embeds the servlet container (Tomcat) inside the app.
- **Why.** It removes nearly all boilerplate: no `web.xml`, no manual `DataSource`, no external Tomcat install. The app is a single runnable jar.
- **How.** Triggered by `@SpringBootApplication` → `@EnableAutoConfiguration` in `PulseApplication`. The presence of `spring-boot-starter-web`, `-data-jpa`, `-security`, `-websocket`, and `-actuator` in `pom.xml` is what drives which auto-configurations activate. Tomcat starts on `server.port=8080`.

### Spring MVC annotations

- **What.** Declarative request mapping for a REST API.
- **Why.** They map HTTP onto Java methods without manual routing or request parsing.
- **How** (all visible in `AuthController` and across the codebase):
  - **`@RestController`** = `@Controller` + `@ResponseBody`. Marks the class as a web handler and makes every return value a serialized response body. On `AuthController`.
  - **`@RequestMapping("/api/auth")`** at class level sets the base path for all methods.
  - **`@GetMapping` / `@PostMapping` / `@PutMapping` / `@PatchMapping` / `@DeleteMapping`** map a verb + sub-path. `AuthController` uses `@PostMapping("/signup")` and `@PostMapping("/login")`.
  - **`@RequestBody`** binds and deserializes the JSON request body into a parameter (`@RequestBody SignupRequest request`).
  - **`@PathVariable`** binds a templated URL segment (`/users/{id}` → `@PathVariable Long id`).
  - **`@RequestParam`** binds a query-string parameter (`?q=foo` → `@RequestParam String q`).

### Spring DI / IoC

- **What.** The container creates objects and injects their dependencies.
- **Why.** Loose coupling, testability, single shared instances (singletons).
- **How.** Constructor injection throughout, e.g. `AuthController(AuthService authService)`. Beans are discovered by component scanning (`@Service`, `@RestController`, `@Repository`, `@Configuration`, `@Component`). `@Bean` methods (like `corsConfigurationSource()` in `CorsConfig`) register beans explicitly. `@Value` injects individual property values (`allowedOrigins` in `CorsConfig`).

### Jackson (JSON ↔ objects)

- **What.** The JSON serialization/deserialization library Boot wires by default.
- **Why.** It converts request bodies to Java objects and Java return values to JSON automatically.
- **How.** `@RequestBody SignupRequest` → deserialization. Returning `ApiResponse<...>` → serialization. `@JsonInclude(JsonInclude.Include.NON_NULL)` on `ApiResponse` controls output (omit nulls). `Instant timestamp` is serialized to ISO-8601 via Boot's JSR-310 (`jackson-datatype-jsr310`) configuration.

### Jakarta Bean Validation

- **What.** A declarative constraint API (`jakarta.validation`), implemented by Hibernate Validator.
- **Why.** Validate input at the boundary, before business logic, with annotations instead of manual `if` checks.
- **How.** Pulled in by `spring-boot-starter-validation`. `@Valid` on a controller parameter (`@Valid @RequestBody SignupRequest request` in `AuthController`) triggers validation of the DTO's constraint annotations (`@NotBlank`, `@Size`, `@Pattern`, etc.). Failures become `MethodArgumentNotValidException`, handled into a 400 by `GlobalExceptionHandler.handleValidation`.

### Lombok

- **What.** A compile-time annotation processor that **generates** boilerplate (constructors, getters/setters, builders) into the `.class` files.
- **Why.** Keeps entities and DTOs terse; no hand-written getters/setters cluttering the source.
- **How.** Configured in `pom.xml` as an `optional` dependency and as a `maven-compiler-plugin` annotation processor path (and **excluded** from the final boot jar, since it's compile-time only). Annotations used in this codebase:
  - **`@Getter` / `@Setter`** — generate getters/setters for all fields. `User` uses both; `ApiResponse` uses only `@Getter` (immutable).
  - **`@NoArgsConstructor`** — generates a no-argument constructor. On `User` — **required by JPA/Hibernate**, which needs a no-arg constructor to instantiate entities by reflection.
  - **`@AllArgsConstructor`** — generates a constructor with every field as a parameter. On both `User` and `ApiResponse` (the latter's factory methods call it).
  - **`@RequiredArgsConstructor`** — generates a constructor for `final`/`@NonNull` fields only; the common way to do constructor injection in services without writing the constructor (used across services; `AuthController` writes its constructor by hand, which is equivalent).
  - **`@Builder`** — generates a fluent builder (`Foo.builder().x(1).y(2).build()`), used where objects have many optional fields.

### Spring Data JPA + Hibernate (the ORM)

- **What.** JPA is the persistence API; Hibernate is the implementation; Spring Data JPA generates repository implementations from interfaces.
- **Why.** Map Java objects to relational tables and remove handwritten SQL/JDBC for common operations.
- **How.**
  - **Entities** — POJOs annotated with JPA mappings. `User` (`src/main/java/com/mohan/pulse/user/User.java`):

    ```java
    @Entity
    @Table(name = "users")
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public class User {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @Column(nullable = false, unique = true)
        private String phone;

        @Column(nullable = false)
        private String passwordHash;

        private String name;
        private String about;
        private String avatarUrl;
        private Instant lastSeen;

        @CreationTimestamp
        @Column(nullable = false, updatable = false)
        private Instant createdAt;
    }
    ```
    `@Entity` + `@Table(name = "users")` map the class to the `users` table. `@Id` + `@GeneratedValue(strategy = IDENTITY)` make `id` an auto-increment primary key (PostgreSQL `SERIAL`/identity). `@Column(nullable = false, unique = true)` on `phone` adds NOT NULL + UNIQUE constraints. `@CreationTimestamp` (a Hibernate annotation) auto-populates `createdAt` on insert, and `updatable = false` means it is never changed afterward. Note `passwordHash` is a real column — another reason never to serialize the entity directly to clients.
  - **Repositories** — interfaces extending `JpaRepository<User, Long>`. Spring generates the implementation: `save`, `findById`, `delete`, etc. come for free.
  - **Derived queries** — method names are parsed into queries: `findByPhone(String phone)` → `WHERE phone = ?`. Naming is the query.
  - **`@Query` / JPQL** — for anything beyond derived naming, a `@Query("...")` with JPQL (object-oriented query language over entities, not tables) or native SQL. Feature docs cover the specific queries.

### `@Transactional`

- **What.** Declarative transaction management. A **transaction** is an all-or-nothing unit of DB work: either all statements commit, or all roll back.
- **Why.** Multi-step operations (e.g. create a group + insert its members) must not leave the DB half-updated. It also defines the boundary within which the JPA persistence context / first-level cache lives.
- **How.** Annotate a service method (or class) with `@Transactional`. Spring wraps it in a proxy that opens a transaction before the method and commits after (or rolls back on a **`RuntimeException`** — which `ApiException` is, so throwing it rolls the transaction back automatically). Key options:
  - **`readOnly = true`** — a hint for read-only methods; lets Hibernate skip dirty-checking/flush and the driver optimize. Use it on pure queries.
  - **Rollback semantics** — by default rolls back on unchecked exceptions (`RuntimeException`/`Error`), commits otherwise.
  - **Lazy loading** — lazily-fetched associations can only be initialized **while the transaction (and thus the persistence context) is open**. Touching a lazy collection after the method returns throws `LazyInitializationException`. This is why mapping entities → DTOs happens *inside* the transactional service method, not in the controller after the transaction has closed.

### `ddl-auto`

- **What.** Hibernate's schema-management strategy at startup (`none` / `validate` / `update` / `create` / `create-drop`).
- **Why.** It decides whether Hibernate changes, checks, or ignores the DB schema relative to your entities.
- **How.** `spring.jpa.hibernate.ddl-auto=update` in dev (auto-applies additive entity changes — convenient, unreviewed) vs `validate` in `application-prod.properties` (only verifies the schema matches and fails fast — safe). This dev/prod split is intentional and is the schema-safety story to give in review.

---

## Quick mental model

1. `PulseApplication` boots the context, auto-configures Tomcat/JPA/Security, and scans `com.mohan.pulse.*`.
2. A request hits Tomcat → Security filters → `DispatcherServlet` → a `@RestController`.
3. Jackson deserializes `@RequestBody`; `@Valid` runs Bean Validation; the controller delegates to a `@Service`.
4. The service enforces rules inside a `@Transactional` boundary, uses Spring Data repositories (Hibernate → PostgreSQL), and throws `ApiException` on failure.
5. Success returns `ApiResponse.ok(...)`; any exception is funneled through `GlobalExceptionHandler` into the same `ApiResponse` envelope with the right status.
6. `SecurityUtil.currentUserId()` tells the service who is calling; `ConversationUtil` provides the `dm:`/`group:` id scheme that the messaging features build on.
