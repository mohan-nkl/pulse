# Pulse — User Profile & Online Presence (Backend Flow)

Audience: a developer who has to defend this code in review. Everything below is grounded in the
actual source. File references use paths under `src/main/java/com/mohan/pulse`.

This document covers, backend-only:

- The `User` entity and the repository lookups behind profiles and presence.
- Profile flows: read (self / other, block-aware), update, avatar upload/remove, logout/last-seen.
- The presence model: an in-memory connection-count map, online/offline transitions, and how those
  hook to real WebSocket connect/disconnect via Spring application events.
- The block-aware presence broadcast and the block-aware read endpoints.
- Concurrency: why `ConcurrentHashMap` plus `synchronized` is used, and the in-memory/reset caveat.
- The framework mechanisms in play (Spring WebSocket/STOMP events, `SimpMessagingTemplate`, the
  `/user` destination, `Principal`, `@Transactional(readOnly)`, `Instant`, Spring multipart).

---

## 1. The `User` entity and repository lookups

### 1.1 Entity — `user/User.java`

```java
@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String phone;

    @Column(nullable = false)
    private String passwordHash;

    private String name;

    private String about;

    private String avatarUrl;

    private Instant lastSeen;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private Instant createdAt;
}
```

Field-by-field, with the parts relevant to profile/presence:

- `id` — surrogate PK, DB-generated (`GenerationType.IDENTITY`). This is the value used everywhere as
  the user identity, including as the WebSocket `Principal` name (see §5).
- `phone` — `nullable = false, unique = true`. The phone doubles as the fallback display name shown
  to *other* viewers when no contact alias exists (see §2.2). Login identity is phone-based.
- `passwordHash` — never leaves the service layer; it is not in any DTO.
- `name` — the user's own registered display name. Critically, this is **only** returned to the user
  themselves (`getMyProfile`/`updateProfile`), never to other viewers (see §2.2).
- `about` — free-text status/bio, capped to 200 chars at the request DTO (`UpdateProfileRequest`).
- `avatarUrl` — stores the **object key** in MinIO (e.g. `avatars/<uuid>.png`), **not** a public
  URL. It is converted to a short-lived presigned URL on read (see §2.1 / §2.4). May be `null`.
- `lastSeen` — `Instant`; the persisted timestamp of when the user last went offline. This is the
  durable half of presence (see §4 / §6). May be `null` (user has never disconnected).
- `createdAt` — set once by Hibernate via `@CreationTimestamp`, and made immutable at the column
  level with `updatable = false`, so it survives every `userRepository.save(...)`.

`Instant` (java.time) is used for both `lastSeen` and `createdAt`: it is an unambiguous UTC instant
(no zone), which serializes cleanly to ISO-8601 in JSON and compares correctly across machines.

### 1.2 Repository — `user/UserRepository.java`

```java
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByPhone(String phone);

    boolean existsByPhone(String phone);

    List<User> findByPhoneIn(List<String> phones);
}
```

For the profile/presence flows the relevant lookups are:

- `findById(Long)` (inherited from `JpaRepository`) — the single-user fetch used by every profile
  method via the private `findById(userId)` helper, and by presence's `lastSeenOf` / `markUserLastSeen`.
- `findAllById(Iterable)` (inherited) — the **batch** fetch used by presence's `loadLastSeenByUserId`
  to resolve many users' `lastSeen` in one query.
- `save(...)` (inherited) — used by every mutation (update profile, avatar, last-seen). Because
  `User` is a managed entity within a transaction, `save` flushes the dirty fields.

The declared finders (`findByPhone`, `existsByPhone`, `findByPhoneIn`) belong to auth/contact-sync
flows; they are not on the profile/presence path but are listed for completeness.

---

## 2. Profile flows — `user/UserProfileService.java`

Service is constructor-injected (Lombok `@RequiredArgsConstructor`) with five collaborators:

```java
private final UserRepository userRepository;
private final StorageService storageService;
private final BlockService blockService;
private final PresenceService presenceService;
private final ContactRepository contactRepository;
```

The DTO returned by most flows, `user/dtos/UserProfileResponse.java`:

```java
@Getter
@AllArgsConstructor
public class UserProfileResponse {
    private Long id;
    private String name;
    private String about;
    private String avatarUrl;   // presigned URL or null
    private Instant lastSeen;
    private Instant createdAt;
}
```

A private `findById` helper centralizes the not-found behavior so every flow throws a consistent
404 instead of leaking an empty `Optional`:

```java
private User findById(Long userId) {
    Optional<User> maybeUser = userRepository.findById(userId);
    if (maybeUser.isEmpty()) {
        throw new ApiException(HttpStatus.NOT_FOUND, "User not found.");
    }
    return maybeUser.get();
}
```

### 2.1 `getMyProfile(Long userId)` — the owner's own view

```java
public UserProfileResponse getMyProfile(Long userId) {
    User user = findById(userId);
    return toResponse(user);
}
```

`toResponse` returns everything, unredacted, including the registered `name` and a freshly presigned
avatar URL:

```java
private UserProfileResponse toResponse(User user) {
    return new UserProfileResponse(
            user.getId(),
            user.getName(),                                   // own real name
            user.getAbout(),
            storageService.presignedUrl(user.getAvatarUrl()), // key -> presigned URL (null-safe)
            user.getLastSeen(),
            user.getCreatedAt());
}
```

`storageService.presignedUrl(...)` is null-safe — `StorageService.presignedUrl` returns `null` when
the key is null/blank — so a user with no avatar yields `avatarUrl == null`.

### 2.2 `getUserProfileFor(Long viewerId, Long ownerId)` — another user's view (block-aware)

This is the privacy-sensitive read. Two protections are applied here, and they are the key thing to
defend in review:

```java
public UserProfileResponse getUserProfileFor(Long viewerId, Long ownerId) {
    User owner = findById(ownerId);

    boolean hiddenByBlock = blockService.isBlockedBetween(viewerId, ownerId);

    String avatarUrl = null;
    Instant lastSeen = null;
    if (!hiddenByBlock) {
        avatarUrl = storageService.presignedUrl(owner.getAvatarUrl());
        lastSeen = owner.getLastSeen();
    }

    return new UserProfileResponse(
            owner.getId(),
            displayNameFor(viewerId, owner),   // NEVER owner.getName()
            owner.getAbout(),
            avatarUrl,                         // null if blocked
            lastSeen,                          // null if blocked
            owner.getCreatedAt());
}
```

Protection 1 — **block redaction.** `blockService.isBlockedBetween(viewerId, ownerId)` is symmetric:
it returns true if *either* side has blocked the other (the JPA query `existsBlockBetween` ORs both
directions; see `block/BlockRepository.java`). When blocked, `avatarUrl` and `lastSeen` are forced to
`null` while `id`, display name, `about`, and `createdAt` still flow. Same shape, redacted fields.

Protection 2 — **name privacy.** The `name` slot is filled by `displayNameFor`, **never** the
owner's registered `owner.getName()`:

```java
private String displayNameFor(Long viewerId, User owner) {
    return contactRepository.findByOwner_IdAndContact_Id(viewerId, owner.getId())
            .map(Contact::getAlias)
            .filter(alias -> alias != null && !alias.isBlank())
            .orElse(owner.getPhone());
}
```

So another viewer sees **the alias they saved for this person, or — if they have no saved alias —
the person's phone number.** They never see the name the owner registered with. This is the
WhatsApp-style model: your displayed name is whatever *the viewer* put in their address book, not a
self-declared name. The `.filter(alias -> alias != null && !alias.isBlank())` guards against a blank
alias falling through as an empty string instead of the phone fallback.

### 2.3 `updateProfile(Long userId, UpdateProfileRequest request)`

```java
public UserProfileResponse updateProfile(Long userId, UpdateProfileRequest request) {
    User user = findById(userId);

    if (request.getName() != null) {
        user.setName(request.getName().trim());
    }
    if (request.getAbout() != null) {
        user.setAbout(request.getAbout().trim());
    }

    User savedUser = userRepository.save(user);
    return toResponse(savedUser);
}
```

Semantics: **partial / patch-style.** A `null` field is left untouched (the caller did not send it);
a present field is `trim()`med and applied. Length validation happens upstream at the DTO via Bean
Validation (`user/dtos/UpdateProfileRequest.java`):

```java
@Size(min = 1, max = 100, message = "Name must be between 1 and 100 characters")
private String name;

@Size(max = 200, message = "About must not exceed 200 characters")
private String about;
```

The controller triggers this with `@Valid` (see §3), so a too-long name is rejected before the
service runs.

### 2.4 `uploadAvatar(Long userId, MultipartFile file)` — validation + MinIO

```java
public String uploadAvatar(Long userId, MultipartFile file) {
    boolean fileMissing = (file == null || file.isEmpty());
    if (fileMissing) {
        throw new ApiException(HttpStatus.BAD_REQUEST, "File must not be empty.");
    }

    boolean tooLarge = file.getSize() > MAX_SIZE;          // MAX_SIZE = 5 * 1024 * 1024
    if (tooLarge) {
        throw new ApiException(HttpStatus.BAD_REQUEST, "Avatar must not exceed 5 MB.");
    }

    boolean unsupportedType = !ALLOWED_TYPES.contains(file.getContentType());
    if (unsupportedType) {                                  // jpeg / png / webp only
        throw new ApiException(HttpStatus.BAD_REQUEST, "Avatar must be JPEG, PNG, or WebP.");
    }

    User user = findById(userId);
    String avatarKey = storageService.upload("avatars", file);
    user.setAvatarUrl(avatarKey);
    userRepository.save(user);

    return storageService.presignedUrl(avatarKey);
}
```

Constants:

```java
private static final List<String> ALLOWED_TYPES = List.of("image/jpeg", "image/png", "image/webp");
private static final long MAX_SIZE = 5 * 1024 * 1024;   // 5 MB
```

Validation order is deliberate — cheapest/most-fundamental checks first (presence, then size, then
content type) so we never read a huge or wrong-typed stream unnecessarily. `MultipartFile` is Spring's
multipart abstraction (`file.isEmpty()`, `file.getSize()`, `file.getContentType()`,
`file.getInputStream()`); the request is `multipart/form-data` and Spring's multipart resolver
populates this from the `file` request part.

Storage is delegated to `storage/StorageService.java`, which talks to MinIO (S3-compatible):

- `upload("avatars", file)` builds an opaque key `avatars/<uuid><ext>` and `putObject`s the stream;
  it returns the **key**, which is what is persisted in `user.avatarUrl`.
- `presignedUrl(key)` issues a time-limited GET URL (`minio.presigned-expiry-minutes`). Only the key
  is durable; URLs are minted on demand and expire. That is why every read path re-derives the URL
  rather than storing one.

Note the method returns a `String` (the presigned URL), not the full profile DTO — see the
controller mapping in §3.

### 2.5 `removeAvatar(Long userId)`

```java
public UserProfileResponse removeAvatar(Long userId) {
    User user = findById(userId);
    user.setAvatarUrl(null);

    User savedUser = userRepository.save(user);
    return toResponse(savedUser);   // avatarUrl will now be null (presignedUrl(null) -> null)
}
```

Clears the key only; the MinIO object itself is not deleted by this method (orphaned object is left
in the bucket). Returns the full refreshed profile.

### 2.6 `recordLastSeen(Long userId)` — the logout path

```java
public void recordLastSeen(Long userId) {
    User user = findById(userId);
    user.setLastSeen(Instant.now());
    userRepository.save(user);

    presenceService.forceOffline(userId);
}
```

This is the explicit-logout counterpart to a socket disconnect. It does two things, in order:

1. **Persists** `lastSeen = now` to the DB (the durable half).
2. Calls `presenceService.forceOffline(userId)`, which drops the user's in-memory connection count
   to zero and broadcasts an offline `PresenceUpdate` (the live half — see §4.5).

The reason both halves exist: logout is a clean shutdown signal that should immediately mark the user
offline for everyone watching, *and* record a fresh last-seen, without waiting for STOMP sessions to
time out.

---

## 3. Profile endpoints — `user/UserProfileController.java`

Base path `@RequestMapping("/api/v1")`. The current user id comes from `SecurityUtil.currentUserId()`
(resolved from the authenticated principal of the HTTP request). Responses are wrapped in
`ApiResponse<T>`.

| Method & Path | Controller method | Body / param | Returns | Service call |
|---|---|---|---|---|
| `GET /api/v1/profile` | `getMyProfile` | — | `ApiResponse<UserProfileResponse>` | `getMyProfile(currentUserId)` |
| `PUT /api/v1/profile` | `updateProfile` | `@Valid @RequestBody UpdateProfileRequest` | `ApiResponse<UserProfileResponse>` ("Profile updated.") | `updateProfile(currentUserId, request)` |
| `POST /api/v1/profile/avatar` | `uploadAvatar` | `@RequestParam("file") MultipartFile` | `ApiResponse<String>` ("Avatar updated.") — presigned URL | `uploadAvatar(currentUserId, file)` |
| `DELETE /api/v1/profile/avatar` | `removeAvatar` | — | `ApiResponse<UserProfileResponse>` ("Photo removed.") | `removeAvatar(currentUserId)` |
| `GET /api/v1/users/{userId}/profile` | `getUserProfile` | path `userId` | `ApiResponse<UserProfileResponse>` (block-aware) | `getUserProfileFor(viewerId, userId)` |
| `POST /api/v1/auth/logout` | `logout` | — | `ApiResponse<Void>` ("Logged out.") | `recordLastSeen(currentUserId)` |

Notes:

- The other-user read takes the **viewer** from the session and the **owner** from the path, then
  delegates to the block-aware `getUserProfileFor` (§2.2):

  ```java
  @GetMapping("/users/{userId}/profile")
  public ResponseEntity<ApiResponse<UserProfileResponse>> getUserProfile(@PathVariable Long userId) {
      Long viewerId = SecurityUtil.currentUserId();
      return ResponseEntity.ok(ApiResponse.ok(
              userProfileService.getUserProfileFor(viewerId, userId)));
  }
  ```

- `logout` lives in this controller (not an auth controller) because logout's server-side effect is
  precisely "record last-seen + go offline":

  ```java
  @PostMapping("/auth/logout")
  public ResponseEntity<ApiResponse<Void>> logout() {
      Long userId = SecurityUtil.currentUserId();
      userProfileService.recordLastSeen(userId);
      return ResponseEntity.ok(ApiResponse.ok("Logged out.", null));
  }
  ```

  JWT logout is otherwise stateless on the client; this endpoint exists for the presence side effect.

---

## 4. Presence model — `user/PresenceService.java`

### 4.1 The shared state

```java
private final Map<Long, Integer> connections = new ConcurrentHashMap<>();
```

`connections` maps **userId -> number of live WebSocket sessions** for that user. The map's key set
is also "the set of users currently online" (a user is in the map iff they have >= 1 live session).

Why a *count* rather than a boolean: one user can be connected from multiple devices/tabs at once.
We must only fire "came online" on the **first** session and "went offline" on the **last**. A plain
boolean cannot tell "second tab opened" from "first tab opened".

This map is the single source of truth for *live* online state. It is **in memory only** — there is
no DB column for "online". Consequences:

- Online state is computed live and is process-local.
- On application restart the map is empty, so everyone is considered offline until their clients
  reconnect. (Their `lastSeen` survives because that is persisted; see §6.)

### 4.2 `userConnected` — increment, broadcast on first

```java
public synchronized void userConnected(Long userId) {
    int currentConnectionCount = connections.getOrDefault(userId, 0);
    int newConnectionCount = currentConnectionCount + 1;
    connections.put(userId, newConnectionCount);

    boolean cameOnline = (currentConnectionCount == 0);
    if (cameOnline) {
        broadcast(new PresenceUpdate(userId, true, null));
    }
}
```

Reads the prior count (0 if absent), increments, writes back. Only when the *prior* count was 0 do we
broadcast an online event — i.e. exactly on the first session. The `lastSeen` field of an "online"
`PresenceUpdate` is `null` (online means "now", no last-seen needed).

### 4.3 `userDisconnected` — decrement, persist + broadcast on last

```java
@Transactional
public synchronized void userDisconnected(Long userId) {
    Integer currentConnectionCount = connections.get(userId);

    boolean notTracked = (currentConnectionCount == null);
    if (notTracked) {
        return;                                   // unknown / already gone — no-op
    }

    boolean stillHasOtherConnections = (currentConnectionCount > 1);
    if (stillHasOtherConnections) {
        connections.put(userId, currentConnectionCount - 1);
        return;                                   // other tabs/devices remain — stay online
    }

    connections.remove(userId);                   // last session closing

    Instant now = Instant.now();
    markUserLastSeen(userId, now);                // persist last-seen
    broadcast(new PresenceUpdate(userId, false, now));   // tell everyone, with the timestamp
}
```

Three branches:

1. Not in the map -> no-op (defensive; e.g. a disconnect after a forceOffline).
2. Count > 1 -> decrement and return; the user still has other live sessions, so they remain online
   and **no** broadcast and **no** DB write happens.
3. Count == 1 (this is the last session) -> remove from map, persist `lastSeen = now`, broadcast an
   offline update carrying that timestamp.

`markUserLastSeen` persists inside the method's transaction:

```java
private void markUserLastSeen(Long userId, Instant when) {
    Optional<User> maybeUser = userRepository.findById(userId);
    if (maybeUser.isPresent()) {
        User user = maybeUser.get();
        user.setLastSeen(when);
        userRepository.save(user);
    }
}
```

This is the only presence method annotated `@Transactional` (read-write), because it is the only one
that **writes** to the DB. (See §LIB on the `@EventListener`/`@Transactional`/`synchronized` ordering.)

### 4.4 `isOnline`

```java
public boolean isOnline(Long userId) {
    return connections.containsKey(userId);
}
```

Pure map membership — present iff at least one session. Used by every read path.

### 4.5 `forceOffline` — used by logout

```java
public synchronized void forceOffline(Long userId) {
    Integer previousCount = connections.remove(userId);

    boolean wasOnline = (previousCount != null);
    if (wasOnline) {
        broadcast(new PresenceUpdate(userId, false, Instant.now()));
    }
}
```

Unconditionally removes the user from the map regardless of session count (drops all devices at
once), and broadcasts offline only if they were actually online. Note it does **not** itself write
`lastSeen` — its caller `recordLastSeen` (§2.6) persists `lastSeen` first, then calls this. So the
logout path = persist last-seen, then force-offline + broadcast.

---

## 5. WebSocket session events — wiring presence to real sockets

### 5.1 How a `Principal` (and thus a userId) is established

The chain that puts a userId on each WebSocket session, before any of the events below fire:

1. STOMP endpoint registration — `config/WebSocketConfig.java`:

   ```java
   registry
       .addEndpoint(WEBSOCKET_ENDPOINT)              // "/ws"
       .addInterceptors(authInterceptor)             // WebSocketAuthInterceptor
       .setHandshakeHandler(new WebSocketHandshakeHandler())
       .setAllowedOrigins(allowedOriginsArray)
       .withSockJS();
   ```

2. `auth/WebSocketAuthInterceptor.beforeHandshake` reads the JWT from the `?token=` query param,
   validates it, extracts the userId, and stashes it in the handshake attributes:

   ```java
   Long userId = jwtUtil.extractUserId(token);
   attributes.put("userId", userId);
   return true;       // returning false aborts the handshake (401-equivalent)
   ```

3. `auth/WebSocketHandshakeHandler.determineUser` turns that attribute into the session `Principal`,
   whose **name is the userId as a string**:

   ```java
   Long userId = (Long) attributes.get("userId");
   if (userId == null) return null;
   String userIdAsName = userId.toString();
   return new Principal() {
       @Override public String getName() { return userIdAsName; }
   };
   ```

So for the rest of presence, `principal.getName()` is the userId string. This is also why the
`/user`-targeted broadcast addresses users by `userId.toString()` (see §6).

### 5.2 The two `@EventListener` hooks

Spring publishes application events around the STOMP session lifecycle. Presence listens to two:

```java
@EventListener
public void onConnected(SessionConnectedEvent event) {
    Long userId = userIdOf(event.getUser());
    if (userId != null) {
        userConnected(userId);
    }
}

@EventListener
public void onDisconnected(SessionDisconnectEvent event) {
    Long userId = userIdOf(event.getUser());
    if (userId != null) {
        userDisconnected(userId);
    }
}
```

- `SessionConnectedEvent` fires after a client has completed the STOMP `CONNECT` frame (a real,
  established session) — not merely the raw transport handshake. This is the right moment to count a
  user as online.
- `SessionDisconnectEvent` fires when a STOMP session ends — explicit `DISCONNECT`, transport close,
  or broker-detected drop. This is the right moment to decrement.

`event.getUser()` returns the session `Principal` we built in §5.1.

### 5.3 `userIdOf` — Principal -> userId, defensively

```java
private Long userIdOf(Principal principal) {
    if (principal == null) {
        return null;
    }
    try {
        return Long.valueOf(principal.getName());
    } catch (NumberFormatException e) {
        return null;
    }
}
```

Null-safe (anonymous/unauthenticated sessions have a null principal) and parse-safe (any non-numeric
name yields `null` instead of throwing). Both listeners guard on `userId != null` before mutating the
map, so a malformed or anonymous session never corrupts presence state.

The net effect: **socket connect -> count++ (broadcast online on first); socket disconnect ->
count-- (persist last-seen + broadcast offline on last).** Presence is therefore driven directly by
real transport lifecycle, not by client-sent "I'm online" messages.

---

## 6. Presence broadcast & read endpoints (block-aware)

### 6.1 The DTO — `user/dtos/PresenceUpdate.java`

```java
@Getter
@AllArgsConstructor
public class PresenceUpdate {
    private Long userId;
    private boolean online;
    private Instant lastSeen;   // null when online (or when redacted by block)
}
```

Convention: `online == true` => `lastSeen == null` (no need for a timestamp while online);
`online == false` => `lastSeen` is the persisted last-seen instant (or `null` if redacted/unknown).

### 6.2 `broadcast` — per-recipient, block-aware fan-out

```java
private void broadcast(PresenceUpdate update) {
    Set<Long> hiddenFrom = collectHiddenUserIds(update.getUserId());

    for (Long onlineUserId : connections.keySet()) {
        if (hiddenFrom.contains(onlineUserId)) {
            continue;
        }
        messagingTemplate.convertAndSendToUser(onlineUserId.toString(), PRESENCE_TOPIC, update);
    }
}
```

Key design points to defend:

- **It iterates `connections.keySet()`** — i.e. it only pushes presence to users who are *currently
  online* (have a live session). No point sending to offline users; they will fetch on reconnect.
- **It is block-aware.** `collectHiddenUserIds(update.getUserId())` is the set of users who must not
  see this subject's presence — anyone who blocked the subject *or* whom the subject blocked:

  ```java
  private Set<Long> collectHiddenUserIds(Long viewerId) {
      Set<Long> hiddenUserIds = new HashSet<>();
      hiddenUserIds.addAll(blockService.blockersOf(viewerId));   // who blocked me
      hiddenUserIds.addAll(blockService.blockedIdsOf(viewerId)); // whom I blocked
      return hiddenUserIds;
  }
  ```

  Any recipient in that set is skipped (`continue`), so a blocked relationship never receives the
  subject's online/offline events.
- **It is a targeted send, not a global topic publish.** Instead of `convertAndSend("/topic/presence",
  update)` (which any subscriber would receive), it loops and calls
  `convertAndSendToUser(userId, "/topic/presence", update)` once per allowed recipient. This is what
  makes per-recipient block filtering possible — a single shared topic message could not be redacted
  per subscriber. See §LIB for `convertAndSend` vs `convertAndSendToUser` and the `/user` prefix.

`PRESENCE_TOPIC` is `"/topic/presence"`; combined with the user destination prefix this resolves to
each user's private `/user/topic/presence` queue.

### 6.3 Read endpoints — `user/PresenceController.java`

Base path `@RequestMapping("/api/presence")`:

```java
@GetMapping("/{userId}")
public ApiResponse<PresenceUpdate> getPresence(@PathVariable Long userId) {
    Long viewerId = SecurityUtil.currentUserId();
    return ApiResponse.ok(presenceService.getPresenceFor(viewerId, userId));
}

@PostMapping
public ApiResponse<List<PresenceUpdate>> getPresenceFor(@RequestBody List<Long> userIds) {
    Long viewerId = SecurityUtil.currentUserId();
    return ApiResponse.ok(presenceService.getPresenceForViewer(viewerId, userIds));
}
```

| Method & Path | Use | Service call |
|---|---|---|
| `GET /api/presence/{userId}` | single-user presence (block-aware) | `getPresenceFor(viewerId, userId)` |
| `POST /api/presence` (body: `[id, id, ...]`) | batch presence (block-aware) | `getPresenceForViewer(viewerId, userIds)` |

The batch endpoint exists so a client opening a conversation list can resolve many users' presence in
one round trip instead of N GETs.

### 6.4 Single-user read — `getPresence` / `getPresenceFor`

```java
@Transactional(readOnly = true)
public PresenceUpdate getPresence(Long userId) {
    if (isOnline(userId)) {
        return new PresenceUpdate(userId, true, null);      // live: from the map
    }
    Instant lastSeen = lastSeenOf(userId);                  // offline: from the DB
    return new PresenceUpdate(userId, false, lastSeen);
}

@Transactional(readOnly = true)
public PresenceUpdate getPresenceFor(Long viewerId, Long userId) {
    boolean hiddenByBlock = blockService.isBlockedBetween(viewerId, userId);
    if (hiddenByBlock) {
        return new PresenceUpdate(userId, false, null);     // redacted: offline, no last-seen
    }
    return getPresence(userId);
}
```

`getPresenceFor` is the block gate around `getPresence`. If the viewer and target are blocked in
either direction, the viewer always sees `offline, lastSeen=null` — never a real status or timestamp.
Otherwise the answer is computed live: **online from the in-memory map, last-seen from the DB.**

`lastSeenOf` is the DB read for the offline case:

```java
private Instant lastSeenOf(Long userId) {
    Optional<User> maybeUser = userRepository.findById(userId);
    if (maybeUser.isEmpty()) {
        return null;
    }
    return maybeUser.get().getLastSeen();
}
```

### 6.5 Batch read — `getPresenceForViewer`

```java
@Transactional(readOnly = true)
public List<PresenceUpdate> getPresenceForViewer(Long viewerId, List<Long> userIds) {
    Set<Long> hiddenUserIds = collectHiddenUserIds(viewerId);          // 1 block lookup
    Map<Long, Instant> lastSeenByUserId = loadLastSeenByUserId(userIds); // 1 batch DB read

    List<PresenceUpdate> result = new ArrayList<>();
    for (Long userId : distinct(userIds)) {
        boolean hiddenByBlock = hiddenUserIds.contains(userId);

        if (hiddenByBlock) {
            result.add(new PresenceUpdate(userId, false, null));
        } else if (isOnline(userId)) {
            result.add(new PresenceUpdate(userId, true, null));
        } else {
            Instant lastSeen = lastSeenByUserId.get(userId);
            result.add(new PresenceUpdate(userId, false, lastSeen));
        }
    }
    return result;
}
```

Efficiency notes worth defending:

- Block info is resolved **once per request** via `collectHiddenUserIds(viewerId)` into a `Set`, then
  membership-checked per id (O(1) each) — no per-user block query.
- Last-seen is loaded in **one batch query** via `findAllById`:

  ```java
  private Map<Long, Instant> loadLastSeenByUserId(List<Long> userIds) {
      Map<Long, Instant> lastSeenByUserId = new HashMap<>();
      List<User> users = userRepository.findAllById(userIds);
      for (User user : users) {
          lastSeenByUserId.put(user.getId(), user.getLastSeen());
      }
      return lastSeenByUserId;
  }
  ```

  This avoids an N+1 of per-user `findById`. (Note: the map is populated for all requested ids, even
  online ones, but is only *read* in the offline branch.)
- `distinct(userIds)` de-duplicates the input list while preserving first-seen order, so a duplicate
  id in the request body produces one entry, not two.
- Same precedence as the single read: **block first, then live-online, then DB last-seen.**

### 6.6 Why live-in-memory presence + persisted last-seen

This split is the central architectural decision:

- **Online/offline is volatile and high-churn.** It changes on every tab open/close and must reflect
  *this instant*. Persisting it would mean a DB write per connect/disconnect and a stale row after any
  crash (you'd show a dead session as "online" until cleanup). Keeping it in `ConcurrentHashMap` means
  it is always exactly the set of users with live sessions on this process, and it self-heals on
  restart (empty map = everyone offline until they reconnect).
- **Last-seen must survive** the moment of going offline, restarts, and the user being away. It is
  therefore written to `User.lastSeen` exactly at the offline transition (`markUserLastSeen` in
  `userDisconnected`, and `setLastSeen` in `recordLastSeen` on logout), and read back from the DB for
  offline users.

So a presence read is: "is the user in the live map? -> online (now). Otherwise -> offline, and here
is their durable last-seen from the DB." Two stores, two lifetimes, one combined answer.

---

## 7. Concurrency — `ConcurrentHashMap` + `synchronized`, and the in-memory caveat

### 7.1 The hazard

WebSocket connect/disconnect events are delivered on the broker/messaging threads, and HTTP-driven
`forceOffline` runs on request threads. Multiple of these can hit `connections` **at the same time**
for the same or different users — e.g. a user's second tab connects while their first tab is
disconnecting, or logout races a disconnect.

### 7.2 Two layers of protection

1. **`ConcurrentHashMap`** for the field itself:

   ```java
   private final Map<Long, Integer> connections = new ConcurrentHashMap<>();
   ```

   It is safe for concurrent reads/writes without external locking. Crucially, `getPresence` /
   `getPresenceForViewer` / `isOnline` / `broadcast` read the map **without** holding the lock used by
   the mutators (they are not `synchronized`), and `ConcurrentHashMap` guarantees those reads are
   safe and see a consistent map (no `ConcurrentModificationException` iterating `keySet()` in
   `broadcast`).

2. **`synchronized` on the three mutators** — `userConnected`, `userDisconnected`, `forceOffline`:

   ```java
   public synchronized void userConnected(Long userId) { ... }

   @Transactional
   public synchronized void userDisconnected(Long userId) { ... }

   public synchronized void forceOffline(Long userId) { ... }
   ```

   Why a method-level lock is needed *on top of* `ConcurrentHashMap`: each mutator does a
   **read-modify-write** plus a **conditional side effect** (broadcast / DB write). For example
   `userConnected` reads the count, computes `cameOnline = (currentConnectionCount == 0)`, writes the
   new count, and *then* may broadcast. `ConcurrentHashMap` makes each individual `get`/`put` atomic,
   but it does **not** make the whole get-then-decide-then-put-then-broadcast sequence atomic. Without
   `synchronized`, two concurrent first-connects could both observe count 0 and both broadcast
   "online" (a duplicate event), or a connect interleaving with a disconnect could miscount and emit
   the wrong transition. `synchronized` serializes the mutators (they all lock on the same
   `PresenceService` instance — a singleton bean), so the increment/decrement/transition decision is
   one atomic step. Reads stay lock-free for throughput.

This is also why the increment isn't written as `connections.merge(...)`: the method must atomically
decide whether this was the *first* connection (to broadcast) and the *last* disconnection (to persist
+ broadcast), which spans more than the map op — so the lock guards the whole decision, and the plain
get/put reads naturally under it.

### 7.3 In-memory => resets on restart (and is single-process)

`connections` lives in the JVM heap. It is **not** persisted and **not** shared across instances.
Implications to call out in review:

- On restart, the map starts empty: every user is treated as offline until their client reconnects
  and a fresh `SessionConnectedEvent` rebuilds the entry. No stale "online" rows can survive a crash.
- This is correct only for a **single process / single instance.** With more than one app instance
  behind a load balancer, each instance has its own `connections` map and `SimpleBroker`, so presence
  would be partitioned per instance. Scaling out would require either sticky sessions plus a shared
  presence store (e.g. Redis) or an external STOMP broker — a known boundary of the current design,
  reinforced by the in-memory `enableSimpleBroker("/topic", "/queue")` in `WebSocketConfig`.
- `lastSeen` is unaffected by any of this because it is in the DB.

---

## LIB — Framework & library mechanisms (what / why / how)

### Spring WebSocket/STOMP application events

- **What:** Spring publishes `SessionConnectedEvent` and `SessionDisconnectEvent` (and others) as
  standard `ApplicationEvent`s around the STOMP session lifecycle.
- **Why:** they let presence react to *transport-level* connect/disconnect without the client having
  to send explicit presence messages — the source of truth is the real socket.
- **How:** `@EventListener` on `onConnected`/`onDisconnected` in `PresenceService`. `event.getUser()`
  returns the session `Principal`, which here is our userId-named principal from
  `WebSocketHandshakeHandler.determineUser`. Enabled by `@EnableWebSocketMessageBroker` in
  `config/WebSocketConfig.java`. `SessionConnectedEvent` is post-STOMP-CONNECT (an established
  session), making it the correct "online" trigger.

### `SimpMessagingTemplate`: `convertAndSend` vs `convertAndSendToUser`, and `/user`

- **`convertAndSend(destination, payload)`** — serializes the payload (JSON) and publishes to a
  **shared** destination; every subscriber to that destination receives the *same* message.
- **`convertAndSendToUser(user, destination, payload)`** — sends to a **user-specific** destination.
  Spring rewrites it under the user-destination prefix and the recipient's session, so only that one
  user's subscription receives it.
- **Why presence uses `convertAndSendToUser`:** presence must be **redacted per recipient** (block
  filtering). A single shared `/topic/presence` message could not be hidden from some subscribers but
  not others. So `broadcast` loops the allowed online recipients and sends each a private copy to
  `/topic/presence`, which under the user prefix lands at that user's `/user/topic/presence`.
- **`/user` prefix:** configured by `registry.setUserDestinationPrefix("/user")` in `WebSocketConfig`.
  Because the principal name is the userId, `convertAndSendToUser(userId.toString(), "/topic/presence",
  update)` targets that specific user. The `SimpMessagingTemplate` is injected into `PresenceService`.

### `Principal`

- **What:** `java.security.Principal` — the identity attached to each WebSocket session.
- **How:** created in `WebSocketHandshakeHandler.determineUser`, with `getName()` returning the userId
  string (derived from the JWT in `WebSocketAuthInterceptor`). Read back via `event.getUser()` in the
  event listeners and parsed by `userIdOf`. It is the bridge between "a socket" and "a user id".

### `ConcurrentHashMap` + the `synchronized` keyword

- **What:** `java.util.concurrent.ConcurrentHashMap` is a thread-safe map (atomic per-entry ops,
  lock-free reads); `synchronized` on an instance method takes the monitor of `this` (the singleton
  `PresenceService`).
- **Why both:** the map guarantees each `get`/`put` is safe; `synchronized` guarantees the multi-step
  read-modify-write-plus-side-effect in the mutators runs atomically so transition events fire exactly
  once. See §7.2.
- **How:** field `connections` is a `ConcurrentHashMap`; `userConnected`/`userDisconnected`/
  `forceOffline` are `synchronized`; read methods are not, so they read concurrently without blocking
  the mutators.

### `@Transactional` / `@Transactional(readOnly = true)`

- **What:** Spring transaction management around service methods.
- **How here:** `userDisconnected` is `@Transactional` (read-write) because it persists `lastSeen` via
  `markUserLastSeen`. The read paths `getPresence`, `getPresenceFor`, `getPresenceForViewer` are
  `@Transactional(readOnly = true)` — a hint that lets the persistence layer skip dirty-checking /
  flush and signal a read-only transaction to the DB, appropriate since they only read. (In
  `BlockService`, the block queries are likewise `@Transactional(readOnly = true)`.)
- **Caveat to note:** the `synchronized` lock is on the method while `@Transactional`'s proxy wraps
  the call; the lock is held for the duration of the DB write in `userDisconnected`, which is
  acceptable given presence mutations are short and serialized intentionally.

### `Instant`

- **What:** `java.time.Instant`, a UTC timestamp with no time zone.
- **Why/How:** used for `User.lastSeen`, `User.createdAt`, and `PresenceUpdate.lastSeen`. Captured
  with `Instant.now()` at offline/logout transitions; serialized to ISO-8601 in JSON; zone-free so it
  compares and transports unambiguously.

### Spring multipart (avatar upload)

- **What:** `org.springframework.web.multipart.MultipartFile`, Spring's abstraction over an uploaded
  `multipart/form-data` part.
- **How:** controller binds `@RequestParam("file") MultipartFile file`; the service validates
  `file.isEmpty()`, `file.getSize()` (<= 5 MB), and `file.getContentType()` (jpeg/png/webp), then
  `StorageService.upload` streams `file.getInputStream()` to MinIO via `PutObjectArgs` and returns the
  object key. The presigned read URL is generated separately and is short-lived.

---

## Appendix — end-to-end traces

**A. User opens a second tab, then closes the first**

1. Tab 2 handshake -> JWT validated -> `userId` in attributes -> `Principal(name=userId)`.
2. STOMP CONNECT completes -> `SessionConnectedEvent` -> `onConnected` -> `userConnected(userId)`:
   prior count was 1, becomes 2, `cameOnline == false` -> **no broadcast** (already online).
3. Tab 1 closes -> `SessionDisconnectEvent` -> `userDisconnected(userId)`: count was 2, `>1`, so
   decremented to 1 -> **no DB write, no broadcast**. User stays online with one session.

**B. User closes their last tab**

1. `SessionDisconnectEvent` -> `userDisconnected(userId)`: count == 1 -> `connections.remove(userId)`
   -> `markUserLastSeen(userId, now)` persists `lastSeen` -> `broadcast(offline, now)` to every
   currently-online, non-blocked user via `convertAndSendToUser(.../topic/presence)`.

**C. A blocked observer queries presence**

1. `GET /api/presence/{target}` -> `getPresenceFor(viewer, target)` ->
   `blockService.isBlockedBetween` true -> returns `PresenceUpdate(target, online=false,
   lastSeen=null)` regardless of the target's real state. The same viewer is also excluded from the
   target's live broadcasts by `collectHiddenUserIds` in `broadcast`.

**D. Viewing another user's profile while blocked**

1. `GET /api/v1/users/{owner}/profile` -> `getUserProfileFor(viewer, owner)`: `hiddenByBlock` true ->
   `avatarUrl` and `lastSeen` forced `null`; name slot = `displayNameFor` (the viewer's alias, else
   the owner's phone) — never the owner's registered `name`.
