# Pulse Backend — Review Prep Docs

Backend-flow documentation for every feature, grounded in the actual code. Each doc explains
the data model, repositories, controllers, service flows, and — where a non-trivial library or
framework mechanism is involved — WHAT it is, WHY it's used, and HOW it's used here.

## Recommended reading order

Read these in order; later docs assume the earlier ones.

1. **[00-foundations.md](00-foundations.md)** — START HERE. How the app boots, the
   Controller→Service→Repository layering, the HTTP request lifecycle, `ApiResponse`/error
   handling, `SecurityUtil`, `ConversationUtil`, and the core libraries (Spring Boot, Spring MVC,
   DI, Jackson, Bean Validation, Lombok, Spring Data JPA/Hibernate, `@Transactional`).
2. **[auth.md](auth.md)** — Signup/login, BCrypt, JWT (JJWT library) internals, the per-request
   `JwtAuthFilter`, `SecurityConfig` (Spring Security filter chain), the 401 entry point, and
   WebSocket handshake auth. The most library-heavy area.
3. **[message-feature.md](message-feature.md)** — The realtime hub. WebSocket/STOMP deep-dive,
   sending DMs/group messages, delivery & read ticks, history + the block-visibility rule,
   edit/delete/clear, typing. Read this before the smaller realtime features.
4. **[presence-and-profile.md](presence-and-profile.md)** — Online/last-seen (in-memory +
   WebSocket session events + `ConcurrentHashMap`/`synchronized`) and user profiles.
5. **[notification.md](notification.md)** — Live unread/toast pushes vs. the durable unread truth.
6. **[media-storage.md](media-storage.md)** — MinIO object storage, presigned URLs, multipart uploads.
7. **[group.md](group.md)** — Groups, members, roles, admin rules.
8. **[status.md](status.md)** — Stories: 24h expiry, views, replies, durable block suppression.
9. **[reaction.md](reaction.md)** — Message reactions.
10. **[contact-feature.md](contact-feature.md)** — Address book, aliases, phone-book sync.
11. **[block-feature.md](block-feature.md)** — Blocking + the cross-feature enforcement matrix
    (how every other feature consults blocks). Good to read last since it ties features together.

## "I don't get this library" — quick index

| Library / mechanism | Where it's explained |
|---|---|
| Spring Boot, DI, Spring MVC, Jackson, Bean Validation, Lombok | 00-foundations |
| Spring Data JPA / Hibernate (ORM), `@Transactional`, JPQL `@Query` | 00-foundations (concepts) + every feature doc (usage) |
| JJWT (JSON Web Tokens) | auth |
| Spring Security (filter chain, `SecurityContextHolder`, BCrypt) | auth |
| WebSocket + STOMP, `SimpMessagingTemplate`, `/user` destinations | message-feature (full), presence-and-profile + notification (usage) |
| WebSocket session events (`@EventListener`), `ConcurrentHashMap` | presence-and-profile |
| MinIO object storage, presigned URLs, multipart | media-storage |

## Note
These docs describe the **current** backend code (including the recent WhatsApp-parity fixes:
durable block visibility for messages/statuses, symmetric group blocks, contact alias/number
display, per-user block-aware presence). They are local notes (git-ignored), not shipped.