# Pulse — In-App Notification Subsystem (Backend)

This document describes the backend Notification subsystem end to end. It is meant
to be read by a developer who needs to explain and defend this code in a review.
Everything below is grounded in the actual source; key files:

- `src/main/java/com/mohan/pulse/notification/NotificationService.java`
- `src/main/java/com/mohan/pulse/notification/dtos/NotificationDto.java`
- Callers:
  - `src/main/java/com/mohan/pulse/message/ChatService.java`
  - `src/main/java/com/mohan/pulse/message/ChatController.java`
  - `src/main/java/com/mohan/pulse/reaction/ReactionService.java`
  - `src/main/java/com/mohan/pulse/message/ConversationController.java`
  - `src/main/java/com/mohan/pulse/message/ConversationService.java`
  - `src/main/java/com/mohan/pulse/message/MessageRecipientStatusRepository.java`

---

## 1. What this subsystem does — and the two layers of "unread"

The Notification subsystem produces **live toast/badge notifications** pushed to a
specific user over WebSocket the moment something happens to them (a new DM, a new
group message, or a reaction on their message). Alongside the toast it ships a small
**in-memory unread counter** so the frontend can immediately render badge numbers
without a round-trip to the database.

It is critical to understand that there are **two distinct layers of "unread"**, and
they are not the same thing:

### Layer A — Live, in-memory, ephemeral (this subsystem)

`NotificationService` keeps a per-user, per-conversation counter in a plain in-memory
`Map`:

```java
private final Map<Long, Map<String, Integer>> unreadByUser = new HashMap<>();
```

Every time a notification is pushed, this counter is incremented and the **new
per-conversation count** and the **total across all conversations** are stuffed into
the outgoing `NotificationDto`. This layer exists purely to make the live badge update
instant. It has no persistence — see §3 and §6.

### Layer B — Durable, database-backed truth (the real source)

The authoritative unread count lives in the `message_recipient_status` table, queried
through `MessageRecipientStatusRepository.countUnreadPerConversation`:

```java
@Query("""
    SELECT mrs.message.conversationId, COUNT(mrs)
    FROM MessageRecipientStatus mrs
    WHERE mrs.recipient.id = :userId
      AND mrs.status <> com.mohan.pulse.message.MessageStatus.READ
    GROUP BY mrs.message.conversationId
    """)
List<Object[]> countUnreadPerConversation(@Param("userId") Long userId);
```

This is surfaced via the REST endpoint `GET /unread-counts`
(`ConversationController.getUnreadCounts`), which delegates to
`ConversationService.getUnreadCounts`:

```java
@GetMapping("/unread-counts")
public ApiResponse<Map<String, Integer>> getUnreadCounts() {
    Long currentUserId = SecurityUtil.currentUserId();
    return ApiResponse.ok(conversationService.getUnreadCounts(currentUserId));
}
```

```java
public Map<String, Integer> getUnreadCounts(Long userId) {
    List<Object[]> rows = recipientStatusRepository.countUnreadPerConversation(userId);

    Map<String, Integer> unreadByConversation = new HashMap<>();
    for (Object[] row : rows) {
        String conversationId = (String) row[0];
        int count = ((Long) row[1]).intValue();
        unreadByConversation.put(conversationId, count);
    }
    return unreadByConversation;
}
```

**How they relate in practice:** the frontend should treat `/unread-counts` as the
source of truth — typically called on app load / reconnect to seed the badge state.
The live counters in `NotificationDto` then keep the badges fresh in real time while
the client stays connected. Because Layer A is rebuilt from zero on every server
restart (the `HashMap` is re-created), the durable Layer B is what guarantees the
counts survive restarts and reconnects. The two layers can drift (e.g. across a
restart, or across multiple server instances); the recipient-status rows are the
reconciliation point.

---

## 2. `NotificationDto` shape and how the frontend uses it

`NotificationDto` (`notification/dtos/NotificationDto.java`) is a flat, immutable
payload built with Lombok `@Getter` + `@AllArgsConstructor`:

```java
@Getter
@AllArgsConstructor
public class NotificationDto {
    private String type;
    private String conversationId;
    private String senderName;
    private String preview;
    private int conversationUnread;
    private int totalUnread;
}
```

Field meanings:

| Field | Meaning |
|---|---|
| `type` | `"MESSAGE"` (DM or group) or `"REACTION"`. Lets the client branch its rendering. |
| `conversationId` | The conversation the event belongs to — used to route the badge to the right chat row and to decide whether the user is currently viewing it. |
| `senderName` | **The toast title.** For a DM it is the contact name or phone; for a group it is the group name; for a reaction it is the reactor's name (see §4). |
| `preview` | **The toast body.** Truncated message text, `"📎 Media"`, `"Sender: message"` (group), or `"Reacted 👍 to your message"` (reaction). |
| `conversationUnread` | New unread count for this conversation (in-memory layer). `0` for reactions. |
| `totalUnread` | New unread total across all conversations (in-memory layer). `0` for reactions. |

**Frontend contract (important for the review):** the client renders `senderName` as
the **toast/notification title** and `preview` as the **toast/notification body**.
This is why the server packs the human-readable label (group name, contact name,
reactor name) into `senderName` rather than a raw user id — the field name is slightly
misleading for the group case (it carries the group name), but the title/body contract
is what matters to the UI.

---

## 3. The in-memory state and `synchronized`

The whole live-counter layer is one field:

```java
private final Map<Long, Map<String, Integer>> unreadByUser = new HashMap<>();
```

- Outer key: `userId` (recipient).
- Inner key: `conversationId`.
- Inner value: unread count for that user/conversation since the last `clearUnread`.

Two private helpers manage it. `unreadFor` lazily creates the inner map on first use:

```java
private Map<String, Integer> unreadFor(Long userId) {
    Map<String, Integer> userUnread = unreadByUser.get(userId);
    if (userUnread == null) {
        userUnread = new HashMap<>();
        unreadByUser.put(userId, userUnread);
    }
    return userUnread;
}
```

`totalUnreadFor` sums the inner map to produce `totalUnread`:

```java
private int totalUnreadFor(Map<String, Integer> userUnread) {
    int total = 0;
    for (int count : userUnread.values()) {
        total += count;
    }
    return total;
}
```

### Why `synchronized`

`NotificationService` is a Spring singleton (`@Service`), so the single `unreadByUser`
`HashMap` is shared across **all request and WebSocket worker threads**. Plain
`HashMap` is not thread-safe — concurrent mutation can corrupt internal structure
(lost updates on the counters, or in the worst historical case an infinite loop during
resize). The mutating, count-producing methods are therefore guarded with the
`synchronized` keyword on the instance:

```java
public synchronized void sendNotification(...) { ... }
public synchronized void sendGroupNotification(...) { ... }
public synchronized void clearUnread(...) { ... }
```

Because they are instance-level `synchronized`, they all contend on the same monitor
(`this`), which serializes every read-modify-write on the map and on
`pushMessageNotification` (called from inside the synchronized methods). This is a
coarse lock but correct, and notification volume is low enough that the contention is
not a concern.

Note that **`sendReactionNotification` is deliberately NOT `synchronized`** — it never
touches `unreadByUser` (it sends `0/0` counts), so it has no shared mutable state to
guard:

```java
public void sendReactionNotification(Long recipientId, ...) {
    ...
    NotificationDto notification = new NotificationDto(
            "REACTION", conversationId, reactorName, preview, 0, 0);
    messagingTemplate.convertAndSendToUser(
            recipientId.toString(), NOTIFICATION_QUEUE, notification);
}
```

### Resets on restart

`unreadByUser` is a field initialized at construction. On every application restart it
starts empty. Therefore the live counters are **lost on restart** and must be
re-seeded from the durable `/unread-counts` endpoint (§1, §6).

---

## 4. The flows, with real code

### Shared core — `pushMessageNotification`

Both message flows funnel through one private method that increments the in-memory
counter, computes the total, builds the DTO, and pushes it:

```java
private void pushMessageNotification(Long recipientId,
                                     String conversationId,
                                     String title,
                                     String preview) {
    Map<String, Integer> userUnread = unreadFor(recipientId);

    int currentCount = userUnread.getOrDefault(conversationId, 0);
    int newCount = currentCount + 1;
    userUnread.put(conversationId, newCount);

    int totalUnread = totalUnreadFor(userUnread);

    NotificationDto notification = new NotificationDto(
            "MESSAGE",
            conversationId,
            title,
            preview,
            newCount,
            totalUnread);

    messagingTemplate.convertAndSendToUser(
            recipientId.toString(), NOTIFICATION_QUEUE, notification);
}
```

The two public callers differ only in how they compute `title` and `preview`.

### DM — `sendNotification`

```java
public synchronized void sendNotification(Long recipientId,
                                          String conversationId,
                                          String senderName,
                                          String messageContent) {
    pushMessageNotification(recipientId, conversationId, senderName, buildPreview(messageContent));
}
```

Title is the sender's display label, body is the truncated message preview. The label
is resolved by the caller (`ChatService.notificationNameFor`, §5) to the contact name
if the recipient has saved the sender, otherwise the sender's phone number.

### Group — `sendGroupNotification`

```java
public synchronized void sendGroupNotification(Long recipientId,
                                               String conversationId,
                                               String groupName,
                                               String senderName,
                                               String messageContent) {
    String preview = senderName + ": " + buildPreview(messageContent);
    pushMessageNotification(recipientId, conversationId, groupName, preview);
}
```

Title is the **group name**; body is prefixed with the sender label,
`"Sender: message"`, so the recipient can tell who spoke in the group from the toast
body alone.

### Reaction — `sendReactionNotification`

```java
public void sendReactionNotification(Long recipientId,
                                     String conversationId,
                                     String reactorName,
                                     String emoji) {
    String emojiText;
    if (emoji == null) {
        emojiText = "";
    } else {
        emojiText = emoji;
    }
    String preview = "Reacted " + emojiText + " to your message";

    NotificationDto notification = new NotificationDto(
            "REACTION", conversationId, reactorName, preview, 0, 0);

    messagingTemplate.convertAndSendToUser(
            recipientId.toString(), NOTIFICATION_QUEUE, notification);
}
```

Reactions are `type="REACTION"`, title is the reactor's name, body is
`"Reacted <emoji> to your message"`. They **do not** participate in the unread counter
(both counts are `0`) — a reaction is not an unread message. A `null` emoji degrades to
an empty string rather than printing `"null"`.

### Read receipt — `clearUnread`

```java
public synchronized void clearUnread(Long userId, String conversationId) {
    Map<String, Integer> userUnread = unreadByUser.get(userId);
    if (userUnread != null) {
        userUnread.remove(conversationId);
    }
}
```

When the user reads a conversation, its entry is removed from the in-memory map. Note
this **does not push a follow-up notification** — it only resets the server-side live
counter so the next message's `totalUnread`/`conversationUnread` are correct. It is
null-safe: if the user has no map yet, it is a no-op.

### Preview building — `buildPreview`

```java
private String buildPreview(String messageContent) {
    boolean hasContent = (messageContent != null && !messageContent.isBlank());

    String text;
    if (hasContent) {
        text = messageContent;
    } else {
        text = "📎 Media";
    }

    boolean tooLong = text.length() > MAX_PREVIEW_LENGTH;
    if (tooLong) {
        return text.substring(0, MAX_PREVIEW_LENGTH) + "...";
    }
    return text;
}
```

- Blank/`null` content (e.g. an image or file message with no caption) becomes
  `"📎 Media"`.
- Anything longer than `MAX_PREVIEW_LENGTH` (`50`) is truncated to 50 chars + `"..."`.

---

## 5. Wiring into message send and read

### On message send (`ChatService`)

`ChatService` injects the service:

```java
private final NotificationService notificationService;
```

**DM send** (`sendMessage`): after persisting the message and creating recipient
statuses, and only when the two users are **not blocked**, it delivers the chat message
over WebSocket and fires the notification:

```java
if (!blocked) {
    sendTo(receiver.getId(), response);

    String notificationName = notificationNameFor(receiver.getId(), sender);
    notificationService.sendNotification(
            receiver.getId(), conversationId, notificationName, request.getContent());
}
```

The title label is resolved here:

```java
private String notificationNameFor(Long recipientId, User sender) {
    boolean savedAsContact =
            contactRepository.findByOwner_IdAndContact_Id(recipientId, sender.getId()).isPresent();
    if (savedAsContact) {
        return sender.getName();
    }
    return sender.getPhone();
}
```

So a recipient who has saved the sender sees the sender's name; otherwise they see the
raw phone number (WhatsApp-style behavior).

**Group send** (`sendGroupMessage`): the message is fanned out to each deliverable
recipient (members minus sender minus blocked), and each gets a per-recipient
notification. The title label is again resolved per-recipient via `notificationNameFor`
so each member sees the sender under their own contact name:

```java
String groupName = members.get(0).getGroup().getName();
for (Long recipientId : recipientIds) {
    sendTo(recipientId, response);

    String senderLabel = notificationNameFor(recipientId, sender);
    notificationService.sendGroupNotification(
            recipientId, conversationId, groupName, senderLabel, request.getContent());
}
```

### On reaction (`ReactionService`)

`ReactionService.notifyAuthorIfNeeded` notifies the original message author, skipping
the case where someone reacts to their own message:

```java
private void notifyAuthorIfNeeded(Message message, Long reactorId, String emoji) {
    Long authorId = message.getSender().getId();

    boolean reactingToOwnMessage = authorId.equals(reactorId);
    if (reactingToOwnMessage) {
        return;
    }

    String reactorName = reactorNameOf(reactorId);
    notificationService.sendReactionNotification(
            authorId, message.getConversationId(), reactorName, emoji);
}
```

### On read (`ChatController`)

The STOMP handler `/chat.read` marks messages read in the **durable** layer
(`messageStatusService.markRead`, which updates `message_recipient_status`) and then
clears the **in-memory** counter — keeping both layers in sync on read:

```java
@MessageMapping("/chat.read")
public void markRead(ConversationAckRequest request, Principal principal) {
    Long recipientId = Long.valueOf(principal.getName());
    messageStatusService.markRead(recipientId, request.getConversationId());
    notificationService.clearUnread(recipientId, request.getConversationId());
}
```

---

## 6. Framework mechanisms — what / why / how

### `SimpMessagingTemplate.convertAndSendToUser` and the `/user` destination

```java
private static final String NOTIFICATION_QUEUE = "/queue/notifications";
...
messagingTemplate.convertAndSendToUser(
        recipientId.toString(), NOTIFICATION_QUEUE, notification);
```

- **What:** `convertAndSendToUser(user, destination, payload)` is Spring Messaging's
  way to push a message to **one specific user's** subscription. It serializes
  `NotificationDto` to JSON (via the configured message converter) and routes it to the
  user-scoped destination `/user/{user}/queue/notifications`.
- **Why:** notifications are inherently targeted (this user got a DM), so we use the
  user destination rather than a broadcast topic. The `user` argument here is the
  numeric user id as a string (`recipientId.toString()`), which matches the
  `Principal.getName()` used elsewhere (e.g. `Long.valueOf(principal.getName())` in
  `ChatController`) — that is how Spring correlates the destination to the connected
  session.
- **How (client side):** the frontend subscribes to `/user/queue/notifications`; Spring
  resolves the `/user` prefix to the current session and delivers only that user's
  notifications.

For the full STOMP/WebSocket configuration — broker setup, the `/user` prefix
registration, how the `Principal` is established on the WebSocket session, and the
other destinations (`/user/queue/...` for chat messages) — see the **message
subsystem documentation** (`docs/message.md`). This document intentionally keeps the
transport explanation brief and points there for the authoritative wiring.

### The `synchronized` keyword on the shared map

Covered in §3. In short: `NotificationService` is a singleton, `unreadByUser` is shared
mutable `HashMap` state, and `HashMap` is not thread-safe, so the read-modify-write
counter operations are serialized with instance `synchronized` to prevent lost updates
and structural corruption.

### Why an in-memory cache alongside the DB

- **What:** `unreadByUser` duplicates information that ultimately also lives in
  `message_recipient_status`.
- **Why:** the live counter lets the server attach a fresh, correct badge number to the
  outgoing toast **without a database query on the hot send path**. Each push would
  otherwise need a `countUnreadPerConversation` round-trip per recipient (and group
  fan-out multiplies that), so the in-memory counter keeps real-time notifications
  cheap.
- **How they stay consistent:** increments happen on send (`pushMessageNotification`),
  decrements/clears happen on read (`clearUnread`), and the durable
  `/unread-counts` endpoint is the seed/reconciliation source the client reads on load
  and reconnect.

---

## 7. Honest limitations (state these in the review)

1. **In-memory, single-instance only.** `unreadByUser` lives in one JVM's heap. If
   Pulse is scaled to more than one backend instance, each instance has its own
   counters, and a user's live counts will be inconsistent depending on which instance
   handled the send vs. the read. The current design assumes a single instance. A
   multi-instance deployment would need a shared store (e.g. Redis) or to drop the
   in-memory layer and recompute from the DB.

2. **Lost on restart.** The map is re-created empty on startup, so all live counts
   reset to zero until the client re-seeds from `/unread-counts`. No data is actually
   lost because the durable truth is in `message_recipient_status`; only the ephemeral
   accelerator is reset.

3. **`senderName` field overloading.** The DTO field `senderName` carries a group name
   for group notifications and a reactor name for reactions. It is correct for the
   title/body UI contract but is not literally "the sender's name" in all cases — worth
   a comment if the field is reused elsewhere.

4. **The durable source of truth is the recipient-status rows.** Any reconciliation,
   audit, or correctness question about unread counts must be answered from
   `MessageRecipientStatusRepository.countUnreadPerConversation` (status `<> READ`), not
   from the in-memory map. The in-memory map is a best-effort live accelerator only.