# Media Storage & Upload — Backend Flow (Pulse)

This document explains, end to end, how Pulse handles **media uploads and object storage** on the
backend. Pulse never stores raw bytes (images, videos, avatars) in PostgreSQL or on the application
server's local disk. Instead it streams them into **MinIO**, an S3-compatible object store, and the
database only ever holds a short **storage key** (e.g. `media/4f3c...e9.png`). When a client needs to
actually *see* a file, the backend mints a short-lived **presigned URL** so the browser fetches the
bytes **directly from MinIO**, never through the Spring app.

If you are defending this code in review and MinIO / presigned URLs feel fuzzy, read sections
[7](#7-library-deep-dive-minio-java-sdk) and [8](#8-library-deep-dive-presigned-urls) first — they
explain the *why* behind every SDK call.

Audience: backend developers. Every claim below is grounded in the actual source; file/class/method
references are given throughout.

---

## 0. The cast of files

| File | Role |
|------|------|
| `src/main/java/com/mohan/pulse/storage/MinioConfig.java` | Builds the singleton `MinioClient` bean from config. |
| `src/main/java/com/mohan/pulse/storage/StorageService.java` | The only class that talks to MinIO. `upload(...)` and `presignedUrl(...)`. |
| `src/main/java/com/mohan/pulse/media/MediaController.java` | `POST /api/v1/media/upload` — the generic upload endpoint. |
| `src/main/java/com/mohan/pulse/media/MediaService.java` | Validation (empty / size) then delegates to `StorageService`. |
| `src/main/resources/application.properties` | `minio.*` and `spring.servlet.multipart.*` settings. |
| `pom.xml` | Declares the `io.minio:minio` dependency. |
| `user/UserProfileService.java`, `status/StatusService.java`, `message/ChatService.java` | Callers — show how keys are stored on write and turned back into URLs on read. |

---

## 1. The `MinioClient` bean — `MinioConfig`

`MinioClient` is the SDK's main entry point: a thread-safe HTTP client that knows the MinIO/S3
endpoint and the credentials. We want **exactly one** instance for the whole app, so it is created as
a Spring `@Bean` and injected wherever needed.

`src/main/java/com/mohan/pulse/storage/MinioConfig.java`:

```java
@Configuration
public class MinioConfig {

    @Value("${minio.endpoint}")
    private String endpoint;

    @Value("${minio.access-key}")
    private String accessKey;

    @Value("${minio.secret-key}")
    private String secretKey;

    @Bean
    public MinioClient minioClient() {
        return MinioClient.builder()
                .endpoint(endpoint)
                .credentials(accessKey, secretKey)
                .build();
    }
}
```

What is happening, mechanism by mechanism:

- **`@Configuration`** marks this class as a source of bean definitions. Spring scans it at startup.
- **`@Bean`** on `minioClient()` tells Spring: "call this method once, register the returned object in
  the application context as a singleton named `minioClient`." Anyone that declares a `MinioClient`
  dependency (here, `StorageService`) gets *this* instance injected. This is why we don't `new
  MinioClient(...)` inside `StorageService` — connection setup is centralized and reused.
- **`@Value("${minio.endpoint}")`** etc. inject the property values from `application.properties` (or
  overriding environment variables / `application.yml`). The fields are populated **before** the
  `@Bean` method runs.
- **`MinioClient.builder()`** is the SDK's fluent builder:
  - `.endpoint(endpoint)` — the base URL of the MinIO server (`http://localhost:9000` by default; see
    below).
  - `.credentials(accessKey, secretKey)` — the S3-style access key / secret key pair MinIO uses to
    sign and authorize requests.
  - `.build()` — produces the immutable, thread-safe client.

### Where the values come from — `application.properties`

```properties
# MinIO
minio.endpoint=${MINIO_ENDPOINT:http://localhost:9000}
minio.access-key=minioadmin
minio.secret-key=minioadmin123
minio.bucket=pulse-media
minio.presigned-expiry-minutes=60
```

- `minio.endpoint` uses Spring's `${VAR:default}` syntax — it reads the `MINIO_ENDPOINT` environment
  variable if present (deployments / Docker), otherwise falls back to `http://localhost:9000` for local
  dev where MinIO runs on its default port 9000.
- `minio.access-key` / `minio.secret-key` are the credentials. (These are the MinIO defaults committed
  for local dev — a review note: in production these should come from env/secrets, not be hard-coded.)
- `minio.bucket=pulse-media` — the single bucket all objects live in. Note this name lives in config,
  but **`MinioConfig` does not know about the bucket** — the bucket is only used by `StorageService`
  (see §2/§3), because a bucket is a per-operation argument, not part of client construction.
- `minio.presigned-expiry-minutes=60` — how long a generated download URL stays valid (consumed in §3).

The bucket and expiry are injected into `StorageService`, not `MinioConfig`, because the client is
generic; the bucket/expiry are storage-policy concerns:

`src/main/java/com/mohan/pulse/storage/StorageService.java`:

```java
@Value("${minio.bucket}")
private String bucket;

@Value("${minio.presigned-expiry-minutes}")
private int expiryMinutes;
```

---

## 2. Writing bytes — `StorageService.upload(folder, MultipartFile)`

`StorageService` is the single chokepoint for all object-storage access. Two public methods:
`upload(...)` (write) and `presignedUrl(...)` (read). It receives the `MinioClient` bean via
constructor injection (`@RequiredArgsConstructor` + `private final MinioClient minioClient;`).

```java
public String upload(String folder, MultipartFile file) {
    if (file == null || file.isEmpty()) {
        throw new ApiException(HttpStatus.BAD_REQUEST, "File must not be empty.");
    }

    String objectKey = buildObjectKey(folder, file.getOriginalFilename());
    saveToMinio(objectKey, file);
    return objectKey;
}
```

Key points:

- **It returns the storage KEY, not a URL.** `objectKey` is a string like `avatars/9b2...c1.png`. This
  is the single most important contract in the whole module: callers persist *this string* in their
  entity columns (`User.avatarUrl`, `Status.mediaUrl`, `Message.mediaUrl`). The DB never holds a URL,
  because a URL would expire (see presigned URLs, §3/§8); a stable key does not.
- The `folder` argument is just a logical prefix (`"media"`, `"avatars"`, `"status"`) — see callers in
  §5. MinIO has no real directories; the slash in the key is convention only.

### How the object key is generated — `buildObjectKey`

```java
private String buildObjectKey(String folder, String originalFilename) {
    String uniqueName = UUID.randomUUID().toString();
    String fileExtension = extension(originalFilename);
    return folder + "/" + uniqueName + fileExtension;
}
```

- The base name is a random **UUID**, so two uploads never collide and a client cannot guess another
  user's keys by enumeration. The original filename is **discarded** for the name (it's never trusted
  as a path), which sidesteps path-traversal / overwrite attacks.
- The original extension is preserved purely for cosmetics / content sniffing, via `extension`:

```java
private String extension(String filename) {
    if (filename == null || !filename.contains(".")) {
        return "";
    }
    int lastDotIndex = filename.lastIndexOf('.');
    return filename.substring(lastDotIndex);
}
```

So `cat.PNG` becomes something like `media/3f0e...a7.PNG`; a filename with no dot yields a key with no
extension.

### Streaming into MinIO — `saveToMinio`

```java
private void saveToMinio(String objectKey, MultipartFile file) {
    try (InputStream fileStream = file.getInputStream()) {
        long letMinioChoosePartSize = -1;

        PutObjectArgs putRequest = PutObjectArgs.builder()
                .bucket(bucket)
                .object(objectKey)
                .stream(fileStream, file.getSize(), letMinioChoosePartSize)
                .contentType(file.getContentType())
                .build();

        minioClient.putObject(putRequest);
    } catch (Exception e) {
        throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to upload file.");
    }
}
```

Mechanism by mechanism:

- **`try (InputStream fileStream = file.getInputStream())`** — a try-with-resources block. The bytes
  are *streamed* from the uploaded file into MinIO rather than loaded fully into a `byte[]`. The stream
  is auto-closed when the block exits (success or exception), so no leaked file handles / temp files.
- **`PutObjectArgs.builder()`** — the SDK's request object for an upload:
  - `.bucket(bucket)` — target bucket (`pulse-media`).
  - `.object(objectKey)` — the key generated above; this is the object's identity within the bucket.
  - `.stream(fileStream, file.getSize(), partSize)` — the three-argument stream form:
    1. the input stream,
    2. the **known object size** (`file.getSize()`), so MinIO knows exactly how many bytes to read,
    3. the **part size** for multipart upload. Passing **`-1`** (named `letMinioChoosePartSize` for
       clarity) tells the SDK to pick an appropriate part size automatically. This is valid precisely
       *because* the total size is known.
  - `.contentType(file.getContentType())` — stores the MIME type (e.g. `image/png`) as object
    metadata. This is what lets the browser render the object correctly later when it fetches via the
    presigned URL.
- **`minioClient.putObject(putRequest)`** — performs the actual HTTP `PUT` to MinIO and writes the
  object.

**Bucket existence:** there is **no** `bucketExists(...)` / `makeBucket(...)` call here. The code
assumes the `pulse-media` bucket already exists (created out-of-band: MinIO console, init script, or
IaC). If the bucket is missing, `putObject` throws and is caught below. (A reviewer might ask "what if
the bucket isn't there?" — the honest answer is: it's a deployment precondition, not auto-created.)

**Error handling:** any SDK exception (network, auth, missing bucket, etc.) is caught and rethrown as
an `ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to upload file.")`, so callers/clients get a
clean 500 with a generic message instead of a leaked stack trace.

---

## 3. Reading bytes — `StorageService.presignedUrl(key)`

```java
public String presignedUrl(String key) {
    if (key == null || key.isBlank()) {
        return null;
    }
    return generatePresignedUrl(key);
}
```

- **Null/blank handling is deliberate and load-bearing.** Many entities legitimately have no media —
  a user with no avatar (`User.avatarUrl == null`), a text-only status, a text message. Callers pass
  that nullable column straight in, e.g. `storageService.presignedUrl(user.getAvatarUrl())`. Returning
  `null` (instead of throwing) means callers don't need null-guards everywhere; a missing avatar simply
  produces a `null` `avatarUrl` in the response DTO.

```java
private String generatePresignedUrl(String key) {
    try {
        GetPresignedObjectUrlArgs urlRequest = GetPresignedObjectUrlArgs.builder()
                .method(Method.GET)
                .bucket(bucket)
                .object(key)
                .expiry(expiryMinutes, TimeUnit.MINUTES)
                .build();

        return minioClient.getPresignedObjectUrl(urlRequest);
    } catch (Exception e) {
        throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to generate file URL.");
    }
}
```

Mechanism by mechanism:

- **`GetPresignedObjectUrlArgs.builder()`**:
  - `.method(Method.GET)` — the URL grants a **GET** (download). The signature is bound to the HTTP
    method, so this URL cannot be used to upload or delete.
  - `.bucket(bucket)` / `.object(key)` — which object the URL points at.
  - `.expiry(expiryMinutes, TimeUnit.MINUTES)` — the URL is valid for `minio.presigned-expiry-minutes`
    (60) minutes. After that the embedded signature is rejected by MinIO.
- **`minioClient.getPresignedObjectUrl(urlRequest)`** computes the URL **locally** (it signs a query
  string using the secret key) — it does **not** call the server and does **not** transfer any bytes.
  It returns a string like
  `http://localhost:9000/pulse-media/avatars/9b2...c1.png?X-Amz-Algorithm=...&X-Amz-Expires=3600&X-Amz-Signature=...`.
- The browser then hits that URL directly against MinIO. **Bytes never pass through the Spring app on
  read.** The app only ever ships small strings.
- Any failure becomes `ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to generate file URL.")`.

See §8 for the full conceptual treatment of presigned URLs.

---

## 4. The generic upload endpoint — `MediaController` + `MediaService`

This is the endpoint the frontend calls to upload a chat **message attachment** before sending the
message itself.

`src/main/java/com/mohan/pulse/media/MediaController.java`:

```java
@RestController
@RequestMapping("/api/v1/media")
@RequiredArgsConstructor
public class MediaController {

    private final MediaService mediaService;

    @PostMapping("/upload")
    public ResponseEntity<ApiResponse<String>> upload(@RequestParam("file") MultipartFile file) {

        String url = mediaService.upload(file);
        return ResponseEntity.ok(ApiResponse.ok("File uploaded", url));
    }
}
```

- **`@PostMapping("/upload")`** → full route `POST /api/v1/media/upload`.
- **`@RequestParam("file") MultipartFile file`** — Spring binds the `multipart/form-data` part named
  `file` to a `MultipartFile`. The client must send a form field literally named `file` (matching the
  string in `@RequestParam("file")`). See §6 for the multipart machinery.
- The "url" local variable name is slightly misleading — `mediaService.upload(file)` returns the
  storage **key**, and that key is what's wrapped in `ApiResponse.ok("File uploaded", <key>)`. So the
  response body's `data` field is the key string (e.g. `media/3f0e...a7.png`), which the frontend will
  later put into the message's `mediaUrl` field.

`src/main/java/com/mohan/pulse/media/MediaService.java`:

```java
@Service
@RequiredArgsConstructor
public class MediaService {

    private static final long MAX_SIZE = 20L * 1024 * 1024;

    private final StorageService storageService;

    public String upload(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "File must not be empty.");
        }
        if (file.getSize() > MAX_SIZE) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "File must not exceed 20 MB.");
        }
        return storageService.upload("media", file);
    }
}
```

- **Validation:** rejects empty files and anything over **20 MB** (`20L * 1024 * 1024`) with a `400`.
  Note `MediaService` validates *size* but **not** content type — the generic media endpoint accepts any
  type. (Contrast with avatar/status uploads in §5 which whitelist MIME types.)
- It calls `storageService.upload("media", file)` — so message attachments land under the `media/`
  prefix in the `pulse-media` bucket and the method returns the resulting key.

---

## 5. Callers — how keys are stored on write and re-signed on read

`StorageService` is reused by three feature services. The pattern is always the same:
**on write, store the key; on read, convert the key to a presigned URL.**

### a) Avatars — `user/UserProfileService.java`

Upload (note the stricter validation: type **and** 5 MB limit):

```java
private static final List<String> ALLOWED_TYPES = List.of("image/jpeg", "image/png", "image/webp");
private static final long MAX_SIZE = 5 * 1024 * 1024;
...
public String uploadAvatar(Long userId, MultipartFile file) {
    ...
    User user = findById(userId);
    String avatarKey = storageService.upload("avatars", file);   // -> "avatars/<uuid>.png"
    user.setAvatarUrl(avatarKey);                                 // store the KEY in the DB
    userRepository.save(user);

    return storageService.presignedUrl(avatarKey);               // return a URL to the caller now
}
```

Read — every place that returns a profile re-signs the stored key on the fly:

```java
// getUserProfileFor(...)
avatarUrl = storageService.presignedUrl(owner.getAvatarUrl());

// toResponse(...)
storageService.presignedUrl(user.getAvatarUrl())
```

Because `presignedUrl(null)` returns `null`, a user with no avatar simply gets a `null` `avatarUrl`.

### b) Status media — `status/StatusService.java`

Upload (whitelists images **and** videos, 20 MB cap), returns the key:

```java
public String uploadStatusMedia(Long userId, MultipartFile file) {
    ...
    return storageService.upload("status", file);   // -> "status/<uuid>.mp4"
}
```

`createStatus(...)` then stores that key string verbatim into `Status.mediaUrl`
(`status.setMediaUrl(mediaUrl)` where `mediaUrl = request.getMediaUrl().trim()`). On read, `toResponse`
re-signs **two** keys — the author's avatar and the status media:

```java
String authorAvatarUrl = storageService.presignedUrl(status.getAuthor().getAvatarUrl());
String mediaUrl = storageService.presignedUrl(status.getMediaUrl());
```

### c) Chat message media — `message/ChatService.java`

A media message is sent by storing the **key** the client got from `/api/v1/media/upload` into
`Message.mediaUrl`:

```java
message.setMediaUrl(request.getMediaUrl());   // the key string from the upload step
```

On read / broadcast, `toResponse` converts it to a presigned URL just before sending over WebSocket:

```java
String mediaUrl = storageService.presignedUrl(saved.getMediaUrl());
...
.mediaUrl(mediaUrl)
```

`buildStatusPreview(...)` does the same for a status being replied to. Note `validateContent(...)`
enforces that non-`TEXT` messages must carry a `mediaUrl` (the key), but it is the
already-uploaded key — `ChatService` itself never touches MinIO for writes; it only re-signs on read.

---

## 6. Multipart handling — `MultipartFile` and the multipart properties

HTTP file uploads use `Content-Type: multipart/form-data`. Spring MVC parses that request body and
hands you a `MultipartFile` for each file part.

In `application.properties`:

```properties
spring.servlet.multipart.max-file-size=20MB
spring.servlet.multipart.max-request-size=20MB
```

- **`spring.servlet.multipart.max-file-size=20MB`** — the maximum size of any **single** file part.
- **`spring.servlet.multipart.max-request-size=20MB`** — the maximum size of the **entire** multipart
  request (all parts + form fields + boundaries combined).
- These are enforced by Spring **before** your controller method runs. If a client sends a 30 MB file,
  the framework rejects it with a `MaxUploadSizeExceededException` — the request never reaches
  `MediaController.upload` or `MediaService`. This is the *first* line of defense.
- The in-code checks (`MediaService.MAX_SIZE = 20 MB`, `UserProfileService.MAX_SIZE = 5 MB`,
  `StatusService.MAX_MEDIA_SIZE = 20 MB`) are the *second* line — they enforce per-feature business
  limits and return a clean `400 ApiException` with a human message. Note the avatar limit (5 MB) is
  **stricter** than the Spring multipart limit (20 MB), so for avatars the application check is what
  actually rejects 5–20 MB files.

**`MultipartFile`** is Spring's abstraction over an uploaded file. The methods this codebase relies on:

- `file.isEmpty()` — true if no file was sent or it had zero bytes (used in every uploader's guard).
- `file.getSize()` — byte count; used for the size checks and passed to MinIO's `.stream(...)`.
- `file.getContentType()` — the declared MIME type; used for type whitelisting and stored as object
  metadata in `putObject`.
- `file.getOriginalFilename()` — the client's filename; used **only** to extract an extension in
  `buildObjectKey` (never as a path).
- `file.getInputStream()` — the byte stream piped into MinIO.

**`@RequestParam("file")`** is the binding glue: it tells Spring to take the multipart part named
`file` and inject it as the `MultipartFile` argument.

---

## 7. Library deep dive — MinIO Java SDK

**What is object storage / S3-compatible storage?**
Object storage keeps each file ("object") as an opaque blob identified by a **key** inside a flat
namespace called a **bucket**, alongside metadata (content type, size). It is accessed over HTTP, not a
filesystem. **S3** is Amazon's object store; its HTTP API became a de-facto standard, and many products
speak it. **MinIO** is an open-source, self-hostable, **S3-compatible** object store — same API shape
as S3, but you can run it locally (here, `http://localhost:9000`) or in your own infra. The
`io.minio:minio` Java SDK is the client for it.

**Dependency** — `pom.xml`:

```xml
<dependency>
    <groupId>io.minio</groupId>
    <artifactId>minio</artifactId>
    <version>8.5.17</version>
</dependency>
```

(Note this is the only third-party storage dep; everything else is Spring Boot 4.1.0 starters / JPA /
PostgreSQL / JJWT.)

**Why object storage instead of the database or local disk?**

- **vs. database (Postgres BLOBs):** storing large binaries in the DB bloats rows, balloons backups,
  thrashes the buffer cache, and forces every byte to flow through the app and DB connection. Pulse
  keeps the DB lean — it stores only the short key string in `avatar_url` / `media_url` columns.
- **vs. local disk:** local disk doesn't survive container restarts/redeploys, doesn't scale across
  multiple app instances (instance A can't serve instance B's file), and makes the app a bandwidth
  bottleneck. Object storage is shared, durable, and can serve clients directly.
- **Offloading bandwidth:** with presigned URLs (next section), the app hands the client a URL and the
  bytes flow **client ↔ MinIO directly**. The Spring app is freed from proxying potentially large
  media on every message render.

**The SDK calls actually used in this codebase:**

- **`MinioClient.builder()...build()`** (`MinioConfig`) — construct the singleton client (endpoint +
  credentials).
- **`minioClient.putObject(PutObjectArgs)`** (`StorageService.saveToMinio`) — upload an object by
  streaming bytes, with known size and content type.
- **`minioClient.getPresignedObjectUrl(GetPresignedObjectUrlArgs)`** (`StorageService.generatePresignedUrl`)
  — generate a signed, time-limited download URL (computed locally, no network call).

**Not used (worth knowing for review):** `bucketExists(...)` / `makeBucket(...)` are part of the SDK
but Pulse does **not** call them — the `pulse-media` bucket is a deployment precondition, not
auto-provisioned.

---

## 8. Library deep dive — presigned URLs

**What is a presigned URL?**
The `pulse-media` bucket is **private** — objects are not publicly readable. A presigned URL is a
normal HTTPS URL to a specific object with extra query parameters that encode:

- which object and bucket,
- which HTTP method is allowed (here `GET`),
- an expiry timestamp,
- a cryptographic **signature** computed with the MinIO secret key.

Anyone holding the URL can fetch that one object until it expires; MinIO verifies the signature on each
request. Crucially, **the secret key is never exposed** — only a signature derived from it travels in
the URL.

**Why use it here?**

1. **Private bucket, no public exposure.** The bucket stays locked down; access is granted per-object,
   per-request, not by making the whole bucket public.
2. **Time-limited access.** With `expiry(expiryMinutes, TimeUnit.MINUTES)` = 60 minutes, a leaked URL
   stops working after an hour. Because URLs are minted **fresh on every read** (see the `toResponse` /
   profile-read call sites in §5), the client always gets a current one.
3. **No proxying bytes through the app.** The app returns a small URL string; the browser downloads the
   media straight from MinIO. The Spring app's CPU/memory/bandwidth are not spent shoveling media.
4. **Stable keys, ephemeral URLs.** The DB stores the permanent key; the URL is regenerated each time.
   This is exactly why `StorageService.upload(...)` returns the **key** (not a URL) and why callers
   store the key — a URL would be invalid an hour later.

**How it's generated** (`StorageService.generatePresignedUrl`): `getPresignedObjectUrl` with
`Method.GET`, the bucket, the key, and the expiry. The signing is done locally by the SDK; the result
is a self-contained URL. The `null`/blank guard in `presignedUrl(...)` means "no key → no URL → null",
so absent media degrades gracefully throughout the API.

---

## 9. End-to-end media message lifecycle

Putting it all together for a chat image (avatars and statuses follow the identical shape, differing
only in folder prefix and validation rules):

1. **Client uploads the file.**
   `POST /api/v1/media/upload` with `multipart/form-data`, part name `file`.
   → `MediaController.upload(@RequestParam("file") MultipartFile)`.
   Spring's multipart layer enforces `spring.servlet.multipart.*` limits *before* the method runs.

2. **Server validates and stores bytes in MinIO.**
   `MediaService.upload` checks empty / ≤ 20 MB, then `StorageService.upload("media", file)`:
   - `buildObjectKey` → `media/<uuid>.<ext>`,
   - `saveToMinio` streams the bytes via `putObject` into bucket `pulse-media` with the file's content
     type.

3. **Server returns the KEY.**
   Response body `data` = `media/<uuid>.png`. No bytes, no URL — just the key.
   (`ApiResponse.ok("File uploaded", key)`.)

4. **Client sends the message carrying that key.**
   The message-send request sets `mediaUrl = <the key>` (and a non-`TEXT` `messageType`).
   `ChatService.sendDirectMessage` / `sendGroupMessage` → `validateContent` ensures media messages have
   a `mediaUrl`, then `message.setMediaUrl(request.getMediaUrl())` persists the **key** in the
   `messages` table.

5. **Server stores only the key in Postgres.** `Message.mediaUrl` column = `media/<uuid>.png`.

6. **On read/broadcast, server converts key → presigned URL.**
   `ChatService.toResponse` does `storageService.presignedUrl(saved.getMediaUrl())`, producing a signed,
   60-minute GET URL, and puts it on `ChatMessageResponse.mediaUrl`. The message is delivered over
   WebSocket (`messagingTemplate.convertAndSendToUser`).

7. **Client renders by fetching the URL directly from MinIO.**
   `<img src="<presigned URL>">` hits MinIO directly. The Spring app never touches the bytes on the read
   path. When that URL eventually expires, the next time the message is loaded a fresh presigned URL is
   minted in `toResponse`.

The same write-key / read-presign pattern is reused by avatars (`User.avatarUrl`, folder `avatars/`)
and statuses (`Status.mediaUrl`, folder `status/`) — see §5.

---

## 10. Quick reference — contracts a reviewer should remember

- `StorageService.upload(folder, file)` **returns the storage key**, not a URL. Persist the key.
- `StorageService.presignedUrl(key)` **returns a fresh, 60-min, GET-only URL**, or `null` if the key is
  null/blank. Call it on the read path, every time.
- The DB columns `avatar_url` / `media_url` hold **keys**, despite the `…Url` naming.
- Bucket = `pulse-media`; it must exist beforehand (no auto-create).
- Two size gates: Spring multipart (`20MB` file & request) first, then per-feature checks
  (media 20 MB, status 20 MB, avatar 5 MB) with type whitelists for avatar/status (none for generic
  `/media/upload`).
