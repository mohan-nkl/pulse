# Pulse Backend — File Map (what each file is and does)

For every backend file: a short explanation of **what the class is, where it sits in the
flow, and how it behaves**, followed by its **fields** and **methods**. This is the "what",
deep enough to orient you; read the per-feature docs for the full "how".

**Layer reminder:** Controller (handles a request) → Service (business rules) →
Repository (DB access, an interface Spring implements) → Entity (a DB-table-mapped class).
DTOs (`dtos/`) are plain data carriers in/out over the wire. Config classes wire up
framework/library behavior.

---

## Root

### `PulseApplication.java`
The single entry point. `main()` calls `SpringApplication.run(...)`, which boots Spring
Boot: it starts the embedded Tomcat web server, scans `com.mohan.pulse` for annotated
classes, and creates one instance (a "bean") of every controller/service/repository,
wiring them together via constructor injection. Nothing else runs until this starts.
- **Fields:** none.
- **Methods:** `main(String[] args)` — boots the app (class annotated `@SpringBootApplication`).

---

## common/ — shared plumbing used by every feature

### `ApiResponse.java`
The single JSON envelope every endpoint returns, so the frontend always sees the same
shape: `{ success, message, data, timestamp }`. It's generic (`<T>`) so `data` can be any
payload type. `@JsonInclude(NON_NULL)` drops null fields from the JSON. You never `new` it
directly — you call its static factory methods.
- **Fields:** `success` (boolean), `message` (optional text), `data` (the generic payload `T`), `timestamp` (`Instant`, set at creation).
- **Methods:** `ok(data)` — success with payload only; `ok(message, data)` — success with both; `error(message)` — failure, no data. (Lombok `@Getter`/`@AllArgsConstructor`.)

### `ApiException.java`
The app's custom error type. Services throw it to signal a business error (e.g. "not
found", "forbidden") along with the exact HTTP status to return. It extends
`RuntimeException` (unchecked) so it can be thrown anywhere without `throws` declarations,
and it bubbles up to the global handler.
- **Fields:** `status` (`HttpStatus` to send back).
- **Methods:** constructor `ApiException(HttpStatus, message)`; `getStatus()`.

### `GlobalExceptionHandler.java`
One centralized place (`@RestControllerAdvice`) that catches exceptions thrown by any
controller/service and converts them into a clean `ApiResponse` error with the right HTTP
status — so controllers/services never write try/catch for these. It maps each exception
type to a status.
- **Fields:** none.
- **Methods:** `handleApiException` (uses the exception's own status); `handleValidation` (bean-validation failures → 400, joins field errors); `handleMissingParam` (→400); `handleMethodNotSupported` (→405); `handleNotFound` (→404); `handleUnexpected` (catch-all → 500, generic message); `formatFieldError` (helper).

### `SecurityUtil.java`
A static helper that answers "who is the logged-in user?" for REST requests. It reads the
`Authentication` that the JWT filter placed in Spring Security's `SecurityContextHolder`
and returns the user id. Controllers/services call `currentUserId()` instead of trusting
anything in the request body.
- **Fields:** none (utility class, private constructor).
- **Methods:** `currentUserId()` — returns the authenticated user's id, or throws `ApiException(UNAUTHORIZED)` if there's no valid authentication / the principal isn't a `Long`.

### `ConversationUtil.java`
A tiny static helper that defines and parses the conversation-id scheme used everywhere:
direct chats are `dm:<smallerId>:<largerId>` (sorted so the id is the same regardless of
who sends), group chats are `group:<groupId>`. Centralizing the format means only this file
knows it.
- **Fields:** none (utility class).
- **Methods:** `dmConversationId(a,b)` / `groupConversationId(id)` (build); `isDirect(id)` / `isGroup(id)` (check prefix); `groupIdFrom(id)` / `dmParticipants(id)` (parse back out).

---

## config/ — framework & library setup

### `SecurityConfig.java`
The Spring Security setup. It makes the API stateless (no server sessions — auth is by JWT
on each request), disables CSRF (not needed for a token API), declares which URLs are
public vs require login, plugs in the custom JWT filter and the 401 entry point, hooks up
CORS, and defines the password-encoder bean used for hashing.
- **Fields:** `PUBLIC_ENDPOINTS` (whitelist: `/api/auth/**`, `/ws/**`, media/avatar paths, `/actuator/health`).
- **Methods (@Bean):** `securityFilterChain(...)` — the core rules (stateless, CORS on, CSRF off, permit public + authenticate the rest, register `JwtAuthFilter` before the username/password filter, set the entry point); `passwordEncoder()` — `BCryptPasswordEncoder`; `authenticationManager(...)` — exposes Spring's auth manager.

### `CorsConfig.java`
Defines which browser origins (the frontend dev URLs) are allowed to call the API, which
methods, and that credentials are allowed. Without this, the browser blocks the React app's
cross-origin requests.
- **Fields:** `allowedOrigins` (from `${app.allowed-origins}`), `ALLOWED_METHODS`.
- **Methods (@Bean):** `corsConfigurationSource()` — builds the CORS rules for `/**`; `parseOrigins(csv)` — splits the comma-separated origins.

### `WebMvcConfig.java`
A Spring MVC configuration hook (`WebMvcConfigurer`). Currently a placeholder with no
overrides — it exists as the place to add MVC tweaks (e.g. static resource handlers) if
needed.
- **Fields:** none. **Methods:** none (empty).

### `WebSocketConfig.java`
Sets up the entire realtime layer (`@EnableWebSocketMessageBroker`). It registers the
single `/ws` connect endpoint (with SockJS fallback and the auth interceptor/handshake
handler), turns on an in-memory STOMP message broker, and defines the destination prefixes
that the whole messaging system uses.
- **Fields:** `WEBSOCKET_ENDPOINT` (`/ws`), `allowedOrigins`, `authInterceptor`.
- **Methods:** `registerStompEndpoints(...)` — registers `/ws` + interceptor + handshake handler + allowed origins + SockJS; `configureMessageBroker(...)` — enables the simple broker on `/topic` and `/queue` (with 10s heartbeats), sets the app prefix `/app` (client→server) and the user prefix `/user` (per-user delivery).

---

## resources/

### `application.properties`
Default (local/dev) configuration. Holds the datasource (PostgreSQL), JPA/Hibernate
behavior (`ddl-auto=update` auto-creates/updates tables; `show-sql=true`), JWT secret +
expiry, MinIO connection + bucket, multipart upload size limits, and allowed CORS origins.
Sensitive values use `${ENV}` placeholders.

### `application-prod.properties`
Production overrides (active with the `prod` profile): `ddl-auto=validate` (never auto-change
the schema), SQL logging off, and Actuator restricted to the health endpoint. Secrets come
from environment variables.

---

## auth/ — signup, login, JWT, security filters

### `AuthController.java`
The REST front door for authentication. Two thin endpoints that validate the incoming body
and delegate to `AuthService`, wrapping the result in `ApiResponse`.
- **Fields:** `authService`.
- **Methods:** `signup(@Valid SignupRequest)` — `POST /api/auth/signup`; `login(@Valid LoginRequest)` — `POST /api/auth/login`. Both return an `AuthResponse` (token + user info).

### `AuthService.java`
The business logic for registration and login. Signup rejects a duplicate phone, hashes the
password, saves the user, and returns a token. Login looks up by phone, verifies the
password against the stored hash, updates `lastSeen`, and returns a token. It never stores
or compares raw passwords.
- **Fields:** `userRepository`, `passwordEncoder` (BCrypt), `jwtUtil`, `storageService` (to presign the avatar URL in the response).
- **Methods:** `signup(request)` (409 on duplicate phone, hash, save); `login(request)` (401 on unknown phone / wrong password); private `findUserByPhoneOrThrow`; private `buildAuthResponse` (mints the JWT + assembles the response).

### `JwtUtil.java`
The JWT toolkit, built on the JJWT library. It knows the secret signing key and token
lifetime, and does three things: create a signed token from a user id, verify a token, and
read the user id back out. It has no knowledge of HTTP — it's pure token mechanics.
- **Fields:** `signingKey` (HMAC `SecretKey` from `app.jwt.secret`), `expirationMillis` (from `app.jwt.expiration-ms`).
- **Methods:** `generateToken(userId)` (subject=userId, issuedAt/expiration, signs); `extractUserId(token)` (verify + read subject); `isValid(token)` (true if it verifies and isn't expired); private `parseClaims` (verify signature, return payload).

### `JwtAuthFilter.java`
A filter that runs once on **every** request before the controller. It reads the
`Authorization: Bearer <token>` header, validates the token, and — if valid — marks the
request as belonging to that user by putting an `Authentication` in the security context. It
never rejects anyone itself; it only sets identity (authorization/blocking is decided by
`SecurityConfig`).
- **Fields:** `AUTH_HEADER`, `BEARER_PREFIX`, `jwtUtil`.
- **Methods:** `doFilterInternal(...)` (extract → validate → authenticate → continue the chain); private `authenticate(...)` (builds a `UsernamePasswordAuthenticationToken` with the user id as principal); private `extractToken(...)` (strips the `Bearer ` prefix).

### `JwtAuthenticationEntryPoint.java`
What runs when a request hits a protected endpoint without valid auth. Instead of a default
HTML error, it returns a clean JSON `401` body so the frontend can handle it uniformly.
- **Fields:** none.
- **Methods:** `commence(...)` — writes `401` with `{success:false, message:"Authentication required...", timestamp}`.

### `WebSocketAuthInterceptor.java`
Authenticates the WebSocket **handshake** (the one-time connect), because a browser can't
set an `Authorization` header on a socket. It reads the JWT from the `?token=` query
parameter and validates it before allowing the socket to open; on success it stashes the
user id for the handshake handler.
- **Fields:** `TOKEN_PARAM`, `jwtUtil`.
- **Methods:** `beforeHandshake(...)` (reject if token missing/invalid, else store `userId`); `afterHandshake(...)` (no-op); private `extractToken(query)`.

### `WebSocketHandshakeHandler.java`
Completes the socket auth by attaching the authenticated user to the socket as its
`Principal` (whose name is the user id). From then on, every STOMP message on that socket
carries this identity — which is how `ChatController` knows the sender without trusting the
payload.
- **Fields:** none.
- **Methods:** `determineUser(...)` — returns a `Principal` whose `getName()` is the user id (or null if missing).

### `dtos/SignupRequest.java`
The incoming signup body. Validation annotations enforce the rules before any service code
runs.
- **Fields:** `phone` (`@NotBlank`), `password` (`@NotBlank`, `@Size(min 6)`), `name` (`@NotBlank`).
- **Methods:** only Lombok getters/setters.

### `dtos/LoginRequest.java`
The incoming login body — the credentials the controller receives and hands to `AuthService`.
- **Fields:** `phone` (`@NotBlank`), `password` (`@NotBlank`).
- **Methods:** only Lombok getters/setters.

### `dtos/AuthResponse.java`
The outgoing reply for signup/login: the JWT plus a few safe, public user fields. Deliberately
omits the password hash and other internal fields.
- **Fields:** `token`, `userId`, `phone`, `name`, `avatarUrl` (all final).
- **Methods:** only Lombok getters.

---

## user/ — profile and presence (online / last seen)

### `User.java`
The entity for the `users` table — one row per account. It's referenced by almost every
other feature (as sender, owner, member, etc.).
- **Fields:** `id` (PK), `phone` (unique, not null), `passwordHash` (not null), `name`, `about`, `avatarUrl` (a storage key, not a URL), `lastSeen` (Instant), `createdAt` (`@CreationTimestamp`).
- **Methods:** only Lombok accessors.

### `UserRepository.java`
DB access for users. Inherits the standard CRUD from `JpaRepository` and adds a few lookups
used by auth and contact-sync.
- **Fields:** n/a (interface).
- **Methods:** `findByPhone`, `existsByPhone`, `findByPhoneIn` (bulk lookup for phone-book sync). Plus inherited `findById`/`findAllById`/`save`/`getReferenceById`.

### `UserProfileController.java`
REST endpoints (base `/api/v1`) for your own profile, viewing someone else's profile, avatar
management, and logout. Each resolves the caller via `SecurityUtil.currentUserId()`.
- **Fields:** `userProfileService`.
- **Methods:** `getMyProfile()` `GET /profile`; `updateProfile(...)` `PUT /profile`; `uploadAvatar(file)` `POST /profile/avatar`; `removeAvatar()` `DELETE /profile/avatar`; `getUserProfile(userId)` `GET /users/{userId}/profile`; `logout()` `POST /auth/logout`.

### `UserProfileService.java`
The profile business logic. Notably, when you view **someone else's** profile it's
block-aware (hides avatar + last-seen if a block exists) and shows them as **your alias for
them, or their phone number — never their registered Pulse name**. It also handles avatar
upload validation and records last-seen on logout.
- **Fields:** `userRepository`, `storageService`, `blockService`, `presenceService`, `contactRepository`; constants `ALLOWED_TYPES`, `MAX_SIZE` (5 MB).
- **Methods:** `getMyProfile`; `getUserProfileFor(viewer, owner)` (+ private `displayNameFor` = alias-or-phone); `updateProfile`; `recordLastSeen` (sets lastSeen + forces offline); `uploadAvatar` (validate type/size, store, return presigned URL); `removeAvatar`; private `findById`, `toResponse`.

### `PresenceController.java`
REST endpoints (base `/api/presence`) to fetch online/last-seen for one user or a batch,
from the current viewer's perspective (so block-hiding applies).
- **Fields:** `presenceService`.
- **Methods:** `getPresence(userId)` `GET /{userId}`; `getPresenceFor(userIds)` `POST` (batch).

### `PresenceService.java`
Tracks who's online **in memory** by counting open WebSocket connections per user (a user
can have several devices/tabs). It reacts to socket connect/disconnect events, flips a user
online on the first connection and offline on the last (persisting `lastSeen` then), and
broadcasts presence changes to other online users — skipping anyone in a block relationship.
"Online" is live/in-memory (reset on restart); "last seen" is durable in the DB.
- **Fields:** `connections` (`ConcurrentHashMap<userId, count>`), `userRepository`, `messagingTemplate`, `blockService`; constant `PRESENCE_TOPIC`.
- **Methods:** `onConnected`/`onDisconnected` (`@EventListener` for socket session events) → `userConnected`/`userDisconnected` (synchronized, update the count + broadcast); `forceOffline`; `isOnline`; `getPresence` / `getPresenceFor` / `getPresenceForViewer` (block-aware single + batch reads); private helpers `collectHiddenUserIds`, `loadLastSeenByUserId`, `markUserLastSeen`, `broadcast` (per-user, block-filtered), `userIdOf`.

### `dtos/UpdateProfileRequest.java`
Incoming body to change your name/about.
- **Fields:** `name` (`@Size 1–100`), `about` (`@Size ≤200`). **Methods:** Lombok getters/setters.

### `dtos/UserProfileResponse.java`
Outgoing profile data shown on the profile screen.
- **Fields:** `id`, `name`, `about`, `avatarUrl`, `lastSeen`, `createdAt`. **Methods:** Lombok getters.

### `dtos/PresenceUpdate.java`
Outgoing presence value — used both as the answer to a presence query and as the live
broadcast payload.
- **Fields:** `userId`, `online` (boolean), `lastSeen`. **Methods:** Lombok getters.

---

## contact/ — address book

### `Contact.java`
The `contacts` table entity: a **one-directional** "owner saved this contact" link with an
optional alias. (Owner 7 saving user 3 is one row; it does not add 7 to 3's list.)
- **Fields:** `id`, `owner` (`@ManyToOne` User), `contact` (`@ManyToOne` User), `alias`, `addedAt`; unique constraint `(owner_id, contact_id)`.
- **Methods:** Lombok accessors.

### `ContactController.java`
REST endpoints (base `/api/v1/contacts`) for the address book. Each resolves the caller and
returns `ApiResponse`; `addContact`/`addContactByUserId` return `201 Created`.
- **Fields:** `contactService`.
- **Methods:** `listContacts()`; `searchContacts(q)`; `addContact(body)` (by phone); `addContactByUserId(userId, optional alias body)` (save someone by id, e.g. from a chat); `syncPhones(body)` (phone-book match); `updateAlias(id, body)`; `removeContact(id)`.

### `ContactService.java`
The contact business logic. Builds responses (with alias, phone, presigned avatar),
**excludes blocked contacts** from the list/search (so a blocked person only shows on the
Blocked page), enforces ownership and "no self / no duplicate" rules, and powers phone-book
sync.
- **Fields:** `contactRepository`, `userRepository`, `storageService`, `blockService`.
- **Methods:** `listContacts` / `searchContacts` (both skip blocked via private `isBlocked`); `addContact` (by phone); `addContactByUserId` (by id + optional alias); `updateAlias`; `removeContact`; `syncPhones`; private helpers `matchesQuery`, `buildExistingContactMap`, `toResponse` (hides avatar/lastSeen if blocked), `findUserOrThrow`, `findUserByPhoneOrThrow`, `findOwnedContactOrThrow` (ownership guard), `ensureNotSelf`, `ensureNotAlreadyContact`, `cleanAlias`.

### `ContactRepository.java`
DB access for contacts. The `_Id`/`_IdAnd...` naming navigates into the related entity (e.g.
`Owner_Id` → the owner's id), and the ownership-scoped lookup prevents touching someone
else's contact row.
- **Fields:** n/a (interface).
- **Methods:** `findByOwner_Id`; `findByOwner_IdAndContact_Id`; `findByIdAndOwner_Id` (ownership-scoped).

### `dtos/AddContactRequest.java`
Incoming body to add a contact by phone (with optional alias).
- **Fields:** `phone` (`@NotBlank`), `alias` (optional). **Methods:** Lombok getters/setters.

### `dtos/ContactResponse.java`
Outgoing contact data. Note both `name` (registered) and `phone` are returned, but clients
display **alias or phone**, never the registered name.
- **Fields:** `id` (contact-row id), `contactId` (the person's user id), `name`, `phone`, `alias`, `avatarUrl`, `lastSeen`, `addedAt`. **Methods:** Lombok getters (`@Builder`).

### `dtos/UpdateAliasRequest.java`
Incoming body carrying just an alias — used both for rename and for "save by id with an alias."
- **Fields:** `alias`. **Methods:** Lombok getters/setters.

### `dtos/SyncRequest.java`
Incoming body for phone-book sync: a list of numbers from the user's phone.
- **Fields:** `phones` (`List<String>`, `@NotEmpty`). **Methods:** Lombok getters/setters.

### `dtos/SyncedUserResponse.java`
Outgoing sync result for one matched number — tells the client whether that person is on
Pulse and already saved.
- **Fields:** `userId`, `name`, `avatarUrl`, `alreadyContact` (boolean), `contactRecordId`. **Methods:** Lombok getters (`@Builder`).

---

## block/ — blocking users

### `Block.java`
The `blocks` table entity: a one-directional `blocker → blocked` row. (A pair can have up to
two rows, one per direction.)
- **Fields:** `id`, `blocker` (`@ManyToOne` User), `blocked` (`@ManyToOne` User), `createdAt`; unique constraint `(blocker_id, blocked_id)`.
- **Methods:** Lombok accessors.

### `BlockController.java`
REST endpoints (base `/api/v1/blocks`) to block/unblock, list, and check status.
- **Fields:** `blockService`.
- **Methods:** `block(userId)` `POST /{userId}`; `unblock(userId)` `DELETE /{userId}`; `listBlocked()` `GET`; `status(userId)` `GET /{userId}/status` → `{blocked: bool}`.

### `BlockService.java`
The block logic plus the **queries other features ask**. The two directions matter:
`hasBlocked(A,B)` is one-way (did A block B?), while `isBlockedBetween(A,B)` is either-way —
most features use the latter to hide interactions symmetrically. The blocked list shows the
alias you gave (or the number), never the registered name (it now injects `ContactRepository`
for that).
- **Fields:** `blockRepository`, `userRepository`, `contactRepository`, `storageService`.
- **Methods:** `block` (idempotent, no self-block); `unblock` (idempotent); `hasBlocked` (one-way); `isBlockedBetween` (either-way); `blockedIdsOf` / `blockersOf` (id lists for filtering); `listBlocked`; private `toBlockedUserResponse`, `savedAlias`, `findUserOrThrow`.

### `BlockRepository.java`
DB access for blocks. Includes hand-written JPQL: the either-direction existence check, and
two id-only selects (lighter than loading whole rows) used to filter other data.
- **Fields:** n/a (interface).
- **Methods:** `findByBlocker_IdAndBlocked_Id`; `existsByBlocker_IdAndBlocked_Id`; `findByBlocker_Id`; `@Query findBlockedIdsByBlocker`; `@Query findBlockerIdsByBlocked`; `@Query existsBlockBetween` (OR across both directions).

### `dtos/BlockedUserResponse.java`
Outgoing entry for the Blocked screen. `name` here is the alias-or-null (client falls back to
the phone).
- **Fields:** `userId`, `name`, `phone`, `avatarUrl`, `blockedAt`. **Methods:** Lombok getters.

---

## message/ — chat (the biggest feature: REST + realtime)

### Entities & enums

### `Message.java`
The `messages` table entity — one row per message, direct or group. It can reference another
message (`replyTo`, a self-relation) or a status (`replyToStatusId`), and carries `edited`
/`deleted` flags. The `(conversation_id, created_at)` index makes "latest messages in this
chat" fast.
- **Fields:** `id`, `conversationId`, `conversationType` (enum), `sender` (`@ManyToOne` User), `type` (enum), `content` (text), `mediaUrl`, `replyTo` (`@ManyToOne` Message), `replyToStatusId`, `edited`, `deleted`, `createdAt`, `updatedAt`; index `idx_convo_time`.
- **Methods:** Lombok accessors.

### `MessageRecipientStatus.java`
One row per **(message, recipient)** holding that recipient's SENT/DELIVERED/READ state and
timestamps. This is the source of truth for the ticks — the message's overall status is
computed by aggregating these rows, and the existence of a row also gates message visibility
after a block.
- **Fields:** `id`, `message` (`@ManyToOne`), `recipient` (`@ManyToOne` User), `status` (enum), `deliveredAt`, `readAt`, `updatedAt`; unique `(message_id, user_id)`; indexes on `message_id` and `(user_id, status)`.
- **Methods:** Lombok accessors.

### `DeletedMessage.java`
Records a "delete for me" — message Y is hidden from user X's view only; everyone else still
sees it.
- **Fields:** `id`, `message` (`@ManyToOne`), `user` (`@ManyToOne`), `deletedAt`; unique `(message_id, user_id)`.
- **Methods:** Lombok accessors.

### `ClearedConversation.java`
Records "user X cleared this conversation at time T" — history loads then hide everything up
to T for that user only.
- **Fields:** `id`, `user` (`@ManyToOne`), `conversationId`, `clearedAt`; unique `(user_id, conversation_id)`.
- **Methods:** Lombok accessors.

### `MessageType.java` — enum: `TEXT`, `IMAGE`, `AUDIO`, `VIDEO`, `FILE`.
### `MessageStatus.java` — enum: `SENT`, `DELIVERED`, `READ`.
### `ConversationType.java` — enum: `DIRECT`, `GROUP`.
(All stored as text via `@Enumerated(EnumType.STRING)`.)

### Repositories

### `MessageRepository.java`
DB access for messages: paged history (newest-first, with a cursor for "load older"), and
aggregate queries for conversation lists.
- **Methods:** `findByConversationIdOrderByCreatedAtDesc(..., pageable)`; `findByConversationIdAndIdLessThanOrderByCreatedAtDesc(..., beforeId, pageable)` (pagination cursor); `@Query findDirectConversationIdsBySender`; `@Query findLastMessageTimes` (last message time per conversation).

### `MessageRecipientStatusRepository.java`
DB access for the per-recipient status rows: fetching/aggregating them, counting unread, and
the "which of these messages have a row for me" check used by block-aware history.
- **Methods:** `findByMessage_Id`; `findByMessage_IdIn`; `findByRecipient_IdAndStatus`; `findByRecipient_IdAndMessage_ConversationIdAndStatus`; `...AndStatusNot`; `@Query countUnreadPerConversation`; `@Query findDirectConversationIdsForRecipient`; `@Query findDeliveredMessageIds` (returns message ids the user has a row for — a row-existence gate, despite the name).

### `DeletedMessageRepository.java`
DB access for "delete for me" rows.
- **Methods:** `existsByMessage_IdAndUser_Id`; `findByUser_IdAndMessage_IdIn`.

### `ClearedConversationRepository.java`
DB access for "cleared conversation" markers.
- **Methods:** `findByUser_IdAndConversationId`; `findByUser_Id`.

### Services

### `ChatService.java`
The core send logic for both direct and group messages. It validates, saves the `Message`,
creates per-recipient status rows, pushes the message live over WebSocket, and triggers
notifications. Block handling is built in: a blocked DM is saved (so the sender sees their
own message) but not delivered/notified; group sends compute a recipient set that **excludes
anyone blocked either way**, and that same set drives delivery, status rows, and
notifications (symmetric group block).
- **Fields:** constant `USER_QUEUE = /queue/messages`; deps `userRepository`, `messageRepository`, `groupMemberRepository`, `contactRepository`, `messagingTemplate`, `messageStatusService`, `statusRepository`, `notificationService`, `storageService`, `blockService`.
- **Methods:** `sendDirectMessage(senderId, request)`; `sendGroupMessage(senderId, request)`; private `deliverableRecipientIds` (exclude sender + blocked), `validateContent`, `resolveReplyTo` (validate the reply target is in the same conversation), `parseMessageType`, `toResponse` (build the outgoing DTO + presigned media + reply summary), `findUser`, `buildStatusPreview`, `sendTo` (per-user push), `notificationNameFor` (saved name or number).

### `ConversationService.java`
Reads chat history and the conversation-list data. It paginates, then filters each message:
out if cleared, out if "deleted for me", and the **block-visibility rule** — a received DM
shows only if you have a recipient-status row; a group message hides only if you have no row
*and* you were already a member when it was sent (so during-block messages never reappear,
but pre-join history stays). It also builds partners (blocked excluded), unread counts,
summaries, and hidden conversations.
- **Fields:** deps `messageRepository`, `groupMemberRepository`, `messageStatusService`, `statusRepository`, `reactionService`, `recipientStatusRepository`, `deletedMessageRepository`, `storageService`, `userRepository`, `clearedConversationRepository`, `blockService`.
- **Methods:** `getDirectConversation` / `getGroupConversation` (paged, membership-checked); `getUnreadCounts`; `getPartners` (drops blocked); `getConversationSummaries`; `clearDirectConversation` / `clearGroupConversation`; `getHiddenConversations`; private `fetchPage`, `toResponses`, `clearedForMe`, `joinTimeFor`, `hiddenByBlock`, `wasMemberWhenSent`, `buildMessageResponse`, `buildStatusPreview`, `hiddenMessageIdsFor`, `repliedStatusesFor`.

### `MessageActionService.java`
Handles edit / delete-for-me / delete-for-everyone, with the rules and time windows, and
broadcasts the resulting events so other clients update in place.
- **Fields:** constants `DELETE_FOR_EVERYONE_WINDOW` (1h), `EDIT_WINDOW` (30m), the two queues; deps `messageRepository`, `deletedMessageRepository`, `groupMemberRepository`, `userRepository`, `messagingTemplate`.
- **Methods:** `deleteForMe` (records a hidden row, idempotent); `deleteForEveryone` (sender-only, ≤1h, wipes content, broadcasts a deleted event); `editMessage` (sender-only, TEXT, ≤30m, non-blank, broadcasts an edited event); private `broadcastDeleted`/`broadcastEdited`, `recipientsOf` (DM participants or group members), `ensureMember`, `isOlderThan`, `findMessageOrThrow`.

### `MessageStatusService.java`
Owns the SENT→DELIVERED→READ lifecycle. It creates rows at send time (DELIVERED immediately
if the recipient is online), advances them when the recipient's app acks delivered/read,
aggregates the per-recipient rows into one status, and pushes updates back to the sender so
their ticks turn live.
- **Fields:** constant `USER_STATUS_QUEUE = /queue/status`; deps `statusRepository` (recipient-status repo), `messageRepository`, `userRepository`, `messagingTemplate`, `storageService`, `presenceService`.
- **Methods:** `createRecipientStatuses` (DELIVERED if online else SENT); `currentStatus`; `markDelivered`; `markRead`; `getMessageInfo` (sender-only per-recipient breakdown); `statusForMessages` (bulk aggregate for history); private `notifySenders`, `aggregate` (READ if all read, DELIVERED if all delivered, else SENT), counting/grouping helpers.

### `TypingService.java`
Relays "typing…" indicators in real time. Nothing is persisted. It works out the right
recipients (the other DM participant, or all group members), skips blocked pairs, and pushes
a `TypingEvent`.
- **Fields:** constant `USER_TYPING_QUEUE = /queue/typing`; deps `groupMemberRepository`, `messagingTemplate`, `blockService`.
- **Methods:** `handleTyping(senderId, conversationId, typing)`; private `relayDirect`, `relayGroup`, `send`.

### Controllers

### `ChatController.java`
The **WebSocket** controller (`@MessageMapping`) — the live actions clients send to `/app/...`.
The sender id comes from the socket's authenticated `Principal`, not the payload.
- **Fields:** `chatService`, `messageStatusService`, `typingService`, `notificationService`.
- **Methods:** `/chat.send` (send DM); `/group.send` (send group); `/chat.delivered` (delivered ack); `/chat.read` (read ack + clear unread); `/chat.typing` (typing).

### `ConversationController.java`
REST reads (base `/api/conversations`): history (direct/group, paginated with `before`/`limit`),
unread counts, partners, summaries, hidden conversations, and "clear conversation".
- **Fields:** `conversationService`.
- **Methods:** `GET /{otherUserId}`; `GET /group/{groupId}`; `GET /unread-counts`; `GET /partners`; `GET /summaries`; `GET /hidden`; `DELETE /{otherUserId}`; `DELETE /group/{groupId}`.

### `MessageActionController.java`
REST actions on a single message (base `/api/messages`).
- **Fields:** `messageActionService`.
- **Methods:** `DELETE /{id}/for-me`; `DELETE /{id}/for-everyone`; `PUT /{id}` (edit).

### `MessageStatusController.java`
REST endpoint for a sender to see who received/read their message (base `/api/messages`).
- **Fields:** `messageStatusService`.
- **Methods:** `GET /{messageId}/status` → `MessageInfoResponse`.

### DTOs (message/dtos/)
Incoming requests, outgoing responses, and realtime events. Most are pure Lombok carriers.

- **`SendMessageRequest`** (in) — a DM to send: `receiverId`, `content`, `messageType` (default TEXT), `mediaUrl`, `replyToId`, `replyToStatusId`.
- **`SendGroupMessageRequest`** (in) — a group message: `groupId`, `content`, `messageType`, `mediaUrl`, `replyToId`.
- **`ConversationAckRequest`** (in) — `conversationId` being acked delivered/read.
- **`TypingRequest`** (in) — `conversationId`, `typing` (boolean).
- **`EditMessageRequest`** (in) — `content` (the new text).
- **`ChatMessageResponse`** (out, live) — the full message pushed after a send: id, conversationId, senderId, content, createdAt, status, type, mediaUrl, the reply-preview fields, `statusPreview`, `edited`, `deleted` (`@Builder`).
- **`MessageResponse`** (out, history) — like above but with `deliveredCount`/`readCount`/`totalRecipients` and `reactions` for the history list (`@Builder`).
- **`PagedMessages`** (out) — `messages` (list) + `hasMore` (boolean).
- **`MessageStatusUpdate`** (event) — tick update pushed to the sender: messageId, conversationId, status, counts.
- **`MessageInfoResponse`** (out) — message-info screen: totals + `recipients` (list of `RecipientStatusEntry`).
- **`RecipientStatusEntry`** (out) — one recipient row: userId, name, avatarUrl, status, deliveredAt, readAt.
- **`MessageDeletedEvent`** / **`MessageEditedEvent`** (events) — broadcast on delete/edit (ids + new content for edit).
- **`TypingEvent`** (event) — conversationId, userId, typing.
- **`ConversationPartner`** (out) — a DM partner: userId, name, phone, avatarUrl, lastSeen.
- **`ReplySummary`** (out / value object) — a compact preview of the replied-to message. Has real logic: static `from(Message)` builds it (returns an empty `NONE` if null; blanks the preview for deleted/media-without-caption; truncates to 80 chars) and private `trim(...)`.

---

## reaction/ — emoji reactions on messages

### `Reaction.java`
The `reactions` table entity — one emoji reaction by a user on a message. The unique
constraint enforces one reaction per user per message (re-reacting replaces).
- **Fields:** `id`, `message` (`@ManyToOne`), `user` (`@ManyToOne`), `emoji`, `createdAt`; unique `(message_id, user_id)`.
- **Methods:** Lombok accessors.

### `ReactionController.java`
REST endpoints (base `/api/messages`) to add/replace or remove your reaction on a message.
- **Fields:** `reactionService`.
- **Methods:** `POST /{messageId}/reactions` (react); `DELETE /{messageId}/reactions` (unreact).

### `ReactionService.java`
The reaction logic. It checks you're allowed to react (DM participant or group member),
upserts/removes the reaction, broadcasts the updated reaction set to the right people (DM
participants or group members), and notifies the message author (but not for self-reactions).
It also bulk-loads reactions for a page of messages (used by history) to avoid N+1 queries.
- **Fields:** deps `reactionRepository`, `messageRepository`, `userRepository`, `groupMemberRepository`, `messagingTemplate`, `notificationService`; constant `USER_REACTIONS_QUEUE = /queue/reactions`.
- **Methods:** `react(userId, messageId, emoji)`; `unreact(userId, messageId)`; `reactionsForMessages(ids)` (batch → map); private `findOrCreateReaction`, `notifyAuthorIfNeeded`, `reactorNameOf`, `currentReactions`, `toEntry`, `broadcast`, `send`, `ensureMember`, `findMessageOrThrow`.

### `ReactionRepository.java`
DB access for reactions.
- **Methods:** `findByMessage_Id`; `findByMessage_IdIn` (batch); `findByMessage_IdAndUser_Id` (a user's reaction on a message).

### `dtos/ReactionRequest.java` (in) — `emoji`.
### `dtos/ReactionUpdate.java` (event) — `messageId`, `conversationId`, `reactions` (full current set), pushed on `/queue/reactions`.
### `dtos/ReactionEntry.java` (out) — one reaction line: `userId`, `userName`, `emoji`.

---

## group/ — group chats

### `Group.java`
The `groups` table entity.
- **Fields:** `id`, `name` (not null), `avatarUrl`, `createdBy` (`@ManyToOne` User), `createdAt`.
- **Methods:** Lombok accessors.

### `GroupMember.java`
The `group_members` join entity — who is in which group, with their role and join time. The
unique constraint prevents duplicate membership; `joinedAt` is used by the block-visibility
rule for history.
- **Fields:** `id`, `group` (`@ManyToOne`), `user` (`@ManyToOne`), `role` (enum), `joinedAt`; unique `(group_id, user_id)`.
- **Methods:** Lombok accessors.

### `GroupRole.java` — enum: `ADMIN`, `MEMBER`.

### `GroupRepository.java`
DB access for groups (just the inherited CRUD; no custom queries).

### `GroupMemberRepository.java`
DB access for membership.
- **Methods:** `findByGroupId`; `findByUserId`; `findByGroupIdAndUserId`; `existsByGroupIdAndUserId`.

### `GroupController.java`
REST endpoints (base `/api/groups`) for the whole group lifecycle. Each resolves the actor
and returns `ApiResponse`.
- **Fields:** `groupService`.
- **Methods:** create; list my groups; get members; add members; remove member; make admin; dismiss admin; leave; update name; upload/remove avatar (multipart).

### `GroupService.java`
The group business logic, including the permission model (member vs admin checks) and the
self-maintaining rules: the creator becomes admin; adding members notifies them over
WebSocket; leaving auto-deletes an empty group and auto-promotes the earliest member if no
admin remains; admins can't remove/demote themselves.
- **Fields:** deps `groupRepository`, `groupMemberRepository`, `userRepository`, `storageService`, `messagingTemplate`; constants `GROUP_ADDED_QUEUE`, allowed avatar types, max avatar size (5 MB).
- **Methods:** `createGroup`; `listMyGroups`; `getMembers`; `addMembers`; `removeMember`; `leaveGroup`; `makeAdmin`/`demoteAdmin`; `updateGroup`; `updateGroupAvatar`/`removeGroupAvatar`; private helpers `requireMembership`, `requireAdmin`, `addMembership`, `notifyAddedToGroup`, `promoteEarliestMemberToAdmin`, `anyAdmin`, `countMembers`, `validateAvatar`, `toMemberResponse`, `toGroupResponse`.

### DTOs (group/dtos/)
- **`CreateGroupRequest`** (in) — `name` (`@NotBlank`), `memberIds` (optional).
- **`AddMembersRequest`** (in) — `memberIds` (`@NotEmpty`).
- **`UpdateGroupRequest`** (in) — `name` (`@NotBlank`).
- **`GroupResponse`** (out) — `id`, `name`, `avatarUrl`, `myRole`, `memberCount`, `createdAt`.
- **`GroupMemberResponse`** (out) — `userId`, `name`, `avatarUrl`, `role`.

---

## status/ — statuses / stories (24h, like WhatsApp status)

### `Status.java`
The `statuses` table entity — an ephemeral post that expires after 24h (filtered by
`expiresAt`, not hard-deleted). The index speeds up "active statuses by author."
- **Fields:** `id`, `author` (`@ManyToOne`), `content` (≤700), `mediaUrl`, `createdAt`, `expiresAt`; index `(author_id, expires_at)`.
- **Methods:** Lombok accessors.

### `StatusView.java`
One row per (status, viewer) — who has seen a status (unique so each view counts once).
- **Fields:** `id`, `status` (`@ManyToOne`), `viewer` (`@ManyToOne`), `viewedAt`; unique `(status_id, viewer_id)`.
- **Methods:** Lombok accessors.

### `HiddenStatus.java`
A durable per-viewer suppression: when a status is posted while a block exists, a row is
recorded so the status stays hidden from that viewer **even after the block is removed** (so
during-block statuses never reappear).
- **Fields:** `id`, `status` (`@ManyToOne`), `viewer` (`@ManyToOne`), `hiddenAt`; unique `(status_id, viewer_id)`.
- **Methods:** Lombok accessors.

### `StatusRepository.java`
- **Methods:** `@Query findActiveByAuthorIds` (non-expired, by authors); `findByAuthorIdAndExpiresAtAfterOrderByCreatedAtAsc`; `@Query findByIdAndAuthorId` (ownership-scoped).

### `StatusViewRepository.java`
- **Methods:** `countByStatusId`; `deleteByStatusId`; `existsByStatusIdAndViewerId`; `findByStatusIdOrderByViewedAtDesc`.

### `HiddenStatusRepository.java`
- **Methods:** `findByViewer_IdAndStatus_IdIn`; `deleteByStatus_Id`.

### `StatusController.java`
REST endpoints (base `/api/v1/statuses`) for posting, viewing, replying to, and deleting
statuses.
- **Fields:** `statusService`.
- **Methods:** `POST /upload` (media); `POST /` (create, 201); `GET /mine`; `GET /` (contacts' statuses); `POST /{id}/view`; `GET /{id}/viewers`; `POST /{id}/reply`; `DELETE /{id}`.

### `StatusService.java`
The status logic. Creating a status sets a 24h expiry and records hidden rows for anyone
currently in a block with the author. Listing contacts' statuses excludes blocked authors
and filters out durably-hidden ones. Viewing records a view and pushes a live event to the
author. Replying delegates to `ChatService` to send a DM tagged with the status. Deleting
cleans up the view and hidden rows first (FK safety).
- **Fields:** deps `statusRepository`, `statusViewRepository`, `hiddenStatusRepository`, `userRepository`, `contactRepository`, `chatService`, `storageService`, `blockService`, `messagingTemplate`; constants `STATUS_VIEWS_QUEUE`, allowed media types, max size (20 MB).
- **Methods:** `uploadStatusMedia`; `createStatus` (+ private `hideFromBlockedViewers`); `getMyStatuses`; `getContactStatuses` (+ private `removeHiddenForViewer`); `viewStatus` (dedupe + notify author); `getStatusViewers` (author-only); `replyToStatus` (→ DM); `deleteStatus` (cascade cleanup); private helpers `contactUserIdsOf`, `blockedOrBlockingIds`, `toResponse(s)`, `toViewerResponse`, `findStatusOrThrow`, `findUserOrThrow`.

### DTOs (status/dtos/)
- **`CreateStatusRequest`** (in) — `content` (≤700) and/or `mediaUrl`.
- **`StatusReplyRequest`** (in) — `content` (`@NotBlank`, ≤1000).
- **`StatusResponse`** (out) — author info, content, media, times, `viewCount` (author-only), `viewedByMe`.
- **`StatusViewerResponse`** (out) — a viewer: id, name, avatar, viewedAt.
- **`StatusViewEvent`** (event) — `statusId`, pushed to the author when someone views.
- **`StatusPreviewDto`** (out) — small preview (author name, content, media) used when a chat message is a reply to a status.

---

## media/ & storage/ — file uploads and object storage

### `MediaController.java`
The generic upload endpoint the client calls **before** sending a media message; it returns
the stored object key, which the client then includes in the message/status/avatar.
- **Fields:** `mediaService`.
- **Methods:** `upload(MultipartFile)` `POST /api/v1/media/upload` → the key.

### `MediaService.java`
Validates the upload (non-empty, ≤20 MB) then hands the bytes to `StorageService`.
- **Fields:** constant `MAX_SIZE` (20 MB); `storageService`.
- **Methods:** `upload(file)` (validate → `storageService.upload("media", file)` → key).

### `StorageService.java`
Wraps the MinIO (S3-compatible) object store. `upload` saves a file under a generated key
(`folder/UUID.ext`) and returns that **key** (not a URL). `presignedUrl` turns a key into a
temporary, time-limited direct-download URL — so the app never proxies file bytes and the
bucket can stay private.
- **Fields:** `minioClient`, `bucket` (`@Value`), `expiryMinutes` (`@Value`).
- **Methods:** `upload(folder, file)`; `presignedUrl(key)` (null for blank); private `buildObjectKey`, `saveToMinio` (streams via `PutObjectArgs`), `generatePresignedUrl` (`GetPresignedObjectUrlArgs`), `extension`.

### `MinioConfig.java`
Builds the `MinioClient` bean from the configured endpoint + credentials, so `StorageService`
can be injected with a ready client.
- **Fields:** `endpoint`, `accessKey`, `secretKey` (all `@Value`).
- **Methods (@Bean):** `minioClient()`.

---

## notification/ — in-app unread + toast pushes

### `NotificationService.java`
Pushes live notification events over WebSocket (new message, reaction) and keeps a fast,
**in-memory** unread counter per user. This is the live layer; the durable unread truth lives
in the message-recipient-status rows (the `/unread-counts` endpoint). It's `synchronized`
because several threads can touch the shared map; it resets on restart.
- **Fields:** constants `NOTIFICATION_QUEUE = /queue/notifications`, `MAX_PREVIEW_LENGTH` (50); `unreadByUser` (`Map<userId, Map<conversationId, count>>`); `messagingTemplate`.
- **Methods:** `sendNotification` (DM: title = sender name/number); `sendGroupNotification` (title = group name, body = "Sender: message"); private `pushMessageNotification` (shared core: bump unread, build DTO, push); `sendReactionNotification`; `clearUnread` (on read); private `unreadFor`, `totalUnreadFor`, `buildPreview` (media → "📎 Media", truncate to 50).

### `dtos/NotificationDto.java`
The outgoing notification payload. The client uses `senderName` as the toast title and
`preview` as the body.
- **Fields:** `type` (MESSAGE/REACTION), `conversationId`, `senderName`, `preview`, `conversationUnread`, `totalUnread`. **Methods:** Lombok getters.

---

### How to use this map
Find a file here to learn its **job and shape**, then open the matching feature doc
(`auth.md`, `message-feature.md`, etc.) for the full step-by-step **how**.