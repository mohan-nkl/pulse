# Message Reactions — Backend Flow

This document describes the **Reaction** feature of Pulse end to end on the backend: the
data model, repository, REST endpoints, service flows (add/toggle/remove), authorization,
real-time WebSocket fan-out, notifications, and how reactions are batched into conversation
history. Everything below is grounded in the actual source under
`src/main/java/com/mohan/pulse/reaction/` plus the collaborating classes it touches.

The mental model: a reaction is **one emoji per user per message**. There is no separate
"add" vs "update" API — re-`react`ing with a different emoji overwrites the user's existing
reaction (an upsert/toggle-style write), and `unreact` removes it. Every write recomputes
the full reaction list for that message and pushes a `ReactionUpdate` over STOMP to every
participant of the conversation.

---

## 1. Data model — `Reaction` entity

`reaction/Reaction.java`:

```java
@Entity
@Table(name = "reactions",
        uniqueConstraints = @UniqueConstraint(
                columnNames = {"message_id", "user_id"}
        ))
public class Reaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "message_id", nullable = false)
    private Message message;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private String emoji;

    @CreationTimestamp
    @Column(updatable = false)
    private Instant createdAt;
}
```

**Fields and relations**

| Field | Mapping | Notes |
|-------|---------|-------|
| `id` | `@Id @GeneratedValue(IDENTITY)` | DB auto-increment surrogate key. |
| `message` | `@ManyToOne(LAZY)` → `Message` via `message_id` (`nullable = false`) | The reacted-to message. Lazy: the FK is loaded, the full `Message` row only on access. |
| `user` | `@ManyToOne(LAZY)` → `User` via `user_id` (`nullable = false`) | Who reacted. |
| `emoji` | `String`, `nullable = false` | The emoji itself is stored as text — there is no enum/whitelist; any non-blank string is accepted (validation is in the service, see §4). |
| `createdAt` | `@CreationTimestamp`, `updatable = false` | Set once by Hibernate on insert. |

**The key constraint — one reaction per user per message.** The table-level
`@UniqueConstraint(columnNames = {"message_id", "user_id"})` is the single most important
fact about this model. It guarantees a user can hold **at most one** reaction on a given
message. This is *why* the feature behaves as a toggle/overwrite rather than an append:
the service never inserts a second row for the same `(message, user)` pair — it finds the
existing row and mutates its `emoji` (§4). The constraint is the safety net if two
concurrent requests race: the DB rejects a duplicate insert.

> **No updated-at column.** Unlike `Message` (which has both `@CreationTimestamp` and
> `@UpdateTimestamp`), `Reaction` only tracks `createdAt`. When a user changes their emoji,
> `createdAt` is preserved (the row is reused) and there is no timestamp recording the
> change. This is intentional given the simple display model (§5), which doesn't order
> reactions by recency.

### Library / framework mechanisms here (WHAT / WHY / HOW)

- **JPA/Hibernate entity mapping** (`jakarta.persistence.*`). *What:* declarative
  object-relational mapping. *Why:* lets the service work with `Reaction` objects instead
  of SQL. *How:* `@Entity` + `@Table` register the class; `@ManyToOne`/`@JoinColumn`
  describe the FK columns.
- **`FetchType.LAZY` on both associations.** *What:* defer loading the related `Message`
  / `User` until dereferenced. *Why:* avoid pulling whole graphs when you only need the
  reaction row. *How:* Hibernate generates a proxy; the actual SELECT fires on first
  access (e.g. `reaction.getUser().getName()` in `toEntry`, §5). All such access happens
  inside `@Transactional` methods, so the session is open and there is no
  `LazyInitializationException`.
- **`@UniqueConstraint`.** *What:* a composite unique index. *Why:* enforce the
  one-reaction-per-user invariant at the database, not just in app code. *How:* Hibernate
  emits the constraint in DDL; violations surface as a constraint exception.
- **`@CreationTimestamp` (Hibernate).** *What:* auto-populate on insert. *Why:* avoids
  hand-setting timestamps. *How:* Hibernate sets the value during the persist lifecycle;
  `updatable = false` keeps it immutable.

---

## 2. Repository — `ReactionRepository`

`reaction/ReactionRepository.java`:

```java
@Repository
public interface ReactionRepository extends JpaRepository<Reaction, Long> {

    List<Reaction> findByMessage_Id(Long messageId);

    List<Reaction> findByMessage_IdIn(List<Long> messageIds);

    Optional<Reaction> findByMessage_IdAndUser_Id(Long messageId, Long userId);
}
```

All three are **Spring Data JPA derived queries** — no `@Query` is needed; the method
names are parsed into queries. The `Message_Id` traversal walks the `message` association
to its `id` (Spring's `_` path separator), so these become `WHERE message_id = ?` against
the FK column without loading `Message`.

| Method | Generated query | Used by |
|--------|-----------------|---------|
| `findByMessage_Id(Long)` | reactions for one message | `currentReactions(messageId)` — building the broadcast payload after every write (§4). |
| `findByMessage_IdIn(List<Long>)` | `... WHERE message_id IN (?, ?, ...)` | `reactionsForMessages(...)` — the batch fetch for conversation history (§5). |
| `findByMessage_IdAndUser_Id(Long, Long)` | the single `(message, user)` row, `Optional` | `findOrCreateReaction` and `unreact` — the upsert/delete lookups (§4). |

Plus everything inherited from `JpaRepository<Reaction, Long>` (`save`, `delete`,
`getReferenceById`, etc.), which the service uses.

**Why the `IN` query matters (N+1 avoidance).** `reactionsForMessages` is called once per
page of conversation history (§5). Without `findByMessage_IdIn`, the caller would issue one
query per message to fetch its reactions — the classic **N+1 problem**. The batch
`IN`-clause query collapses that to a single round trip for the whole page; grouping by
message then happens in memory (§5).

---

## 3. REST endpoints — `ReactionController`

`reaction/ReactionController.java`, base path `@RequestMapping("/api/messages")`:

```java
@PostMapping("/{messageId}/reactions")
public ApiResponse<Void> react(@PathVariable Long messageId,
                               @RequestBody ReactionRequest request) {
    Long currentUserId = SecurityUtil.currentUserId();
    reactionService.react(currentUserId, messageId, request.getEmoji());
    return ApiResponse.ok(null);
}

@DeleteMapping("/{messageId}/reactions")
public ApiResponse<Void> unreact(@PathVariable Long messageId) {
    Long currentUserId = SecurityUtil.currentUserId();
    reactionService.unreact(currentUserId, messageId);
    return ApiResponse.ok(null);
}
```

| Verb & path | Body | Action | Returns |
|-------------|------|--------|---------|
| `POST /api/messages/{messageId}/reactions` | `ReactionRequest { emoji }` | Add **or change** the caller's reaction on the message (upsert). | `ApiResponse.ok(null)` |
| `DELETE /api/messages/{messageId}/reactions` | — | Remove the caller's reaction on the message. | `ApiResponse.ok(null)` |

**Endpoint design notes for the review:**

- There is **no GET endpoint** for reactions. They are never fetched standalone over REST —
  they are delivered two ways only: (a) embedded in `MessageResponse` when conversation
  history is loaded (§5), and (b) pushed live via WebSocket after each write (§4). This is
  deliberate: the client already renders the message list, so reactions piggyback on it.
- **One POST covers both "add" and "update".** Re-POSTing a different emoji overwrites;
  there is no separate PATCH. The toggle-to-same-emoji-to-remove behavior, if any, lives in
  the **frontend** (the client decides whether a repeat tap should call `DELETE`); the
  backend `react` always sets, never clears.
- **Caller identity comes from the security context, not the request.** `messageId` is a
  path variable; the acting user is `SecurityUtil.currentUserId()` — the client cannot
  react "as" someone else.

### `SecurityUtil.currentUserId()`

`common/SecurityUtil.java` reads the authenticated principal from Spring Security:

```java
Authentication authentication =
        SecurityContextHolder.getContext().getAuthentication();
if (authentication == null || !authentication.isAuthenticated()) {
    throw new ApiException(HttpStatus.UNAUTHORIZED, "You are not logged in.");
}
Object principal = authentication.getPrincipal();
if (principal instanceof Long userId) {
    return userId;
}
throw new ApiException(HttpStatus.UNAUTHORIZED, "Could not identify the current user.");
```

So an unauthenticated request to either endpoint fails with **401** before the service runs.
The principal is the numeric user id (established by the auth filter elsewhere).

### DTOs

- `dtos/ReactionRequest.java` — inbound: `{ String emoji }`. Mutable POJO
  (`@Getter @Setter @NoArgsConstructor`) for Jackson deserialization. No bean validation
  annotations; the blank check is in the service.
- `dtos/ReactionEntry.java` — outbound display unit: `{ Long userId, String userName,
  String emoji }`. Immutable (`@Getter @AllArgsConstructor`). One per reacting user.
- `dtos/ReactionUpdate.java` — the WebSocket push payload: `{ Long messageId, String
  conversationId, List<ReactionEntry> reactions }`. Carries the **full, current** reaction
  set for the message (not a delta).

---

## 4. Service flows — `ReactionService`

`reaction/ReactionService.java`. Constructor-injected collaborators
(`@RequiredArgsConstructor`):

```java
private static final String USER_REACTIONS_QUEUE = "/queue/reactions";

private final ReactionRepository reactionRepository;
private final MessageRepository messageRepository;
private final UserRepository userRepository;
private final GroupMemberRepository groupMemberRepository;
private final SimpMessagingTemplate messagingTemplate;
private final NotificationService notificationService;
```

### 4a. Adding / changing a reaction — `react(...)`

```java
@Transactional
public void react(Long userId, Long messageId, String emoji) {
    boolean emojiMissing = (emoji == null || emoji.isBlank());
    if (emojiMissing) {
        throw new ApiException(HttpStatus.BAD_REQUEST, "Emoji is required.");
    }

    Message message = findMessageOrThrow(messageId);
    ensureMember(userId, message.getConversationId());

    Reaction reaction = findOrCreateReaction(message, userId);
    reaction.setEmoji(emoji);
    reactionRepository.save(reaction);

    broadcast(message);
    notifyAuthorIfNeeded(message, userId, emoji);
}
```

Step by step:

1. **Validate the emoji.** `emoji == null || emoji.isBlank()` → **400 Bad Request**
   (`"Emoji is required."`). This is the only content validation; any non-blank string is
   accepted as an emoji.
2. **Load the message or 404.** `findMessageOrThrow` does `messageRepository.findById`
   and throws `ApiException(NOT_FOUND, "Message not found.")` if absent.
3. **Authorize.** `ensureMember(userId, message.getConversationId())` — see §4d. Throws
   **403** if the caller is not a participant/member of the conversation.
4. **Upsert the reaction.** `findOrCreateReaction`:

   ```java
   private Reaction findOrCreateReaction(Message message, Long userId) {
       Optional<Reaction> existingReaction =
               reactionRepository.findByMessage_IdAndUser_Id(message.getId(), userId);
       if (existingReaction.isPresent()) {
           return existingReaction.get();   // reuse → emoji change
       }
       Reaction reaction = new Reaction();
       reaction.setMessage(message);
       reaction.setUser(userRepository.getReferenceById(userId));  // proxy, no extra SELECT
       return reaction;
   }
   ```

   - If the user already reacted, the **existing managed entity** is returned; setting its
     emoji and `save` issues an UPDATE — this is the "change my reaction" path and the
     reason the unique constraint is never violated.
   - If new, a fresh `Reaction` is built. The user is attached via
     `userRepository.getReferenceById(userId)`, which returns a **lazy proxy** carrying only
     the id — no `SELECT users` is needed just to set the FK on insert.

5. **Persist.** `reaction.setEmoji(emoji); reactionRepository.save(reaction);` — INSERT for
   a new reaction, UPDATE for an existing one.
6. **Broadcast live** (§4c): `broadcast(message)` recomputes the message's full reaction
   list and pushes it to every conversation participant over WebSocket.
7. **Notify the author** (§4e): `notifyAuthorIfNeeded(...)` sends a `REACTION` notification
   to the message's sender, unless they reacted to their own message.

### 4b. Removing a reaction — `unreact(...)`

```java
@Transactional
public void unreact(Long userId, Long messageId) {
    Message message = findMessageOrThrow(messageId);
    ensureMember(userId, message.getConversationId());

    Optional<Reaction> existingReaction =
            reactionRepository.findByMessage_IdAndUser_Id(messageId, userId);
    if (existingReaction.isPresent()) {
        reactionRepository.delete(existingReaction.get());
    }

    broadcast(message);
}
```

1. Load the message or **404**.
2. **Authorize** with the same `ensureMember` check (§4d) — you must still belong to the
   conversation to remove a reaction.
3. **Idempotent delete.** Look up the caller's `(message, user)` reaction; delete it if
   present. If there is none, nothing happens — calling `DELETE` twice is harmless.
4. **Broadcast** the now-updated (possibly empty) reaction list to all participants.

Note `unreact` does **not** send a notification — there is no "X removed their reaction"
message; only the live `ReactionUpdate` reflects the removal.

### 4c. Real-time broadcast — `broadcast(...)` and `send(...)`

```java
private void broadcast(Message message) {
    String conversationId = message.getConversationId();
    ReactionUpdate update = new ReactionUpdate(
            message.getId(), conversationId, currentReactions(message.getId()));

    if (ConversationUtil.isDirect(conversationId)) {
        long[] participants = ConversationUtil.dmParticipants(conversationId);
        send(participants[0], update);
        send(participants[1], update);
    } else if (ConversationUtil.isGroup(conversationId)) {
        Long groupId = ConversationUtil.groupIdFrom(conversationId);
        for (GroupMember member : groupMemberRepository.findByGroupId(groupId)) {
            send(member.getUser().getId(), update);
        }
    }
}

private void send(Long recipientId, ReactionUpdate update) {
    messagingTemplate.convertAndSendToUser(
            recipientId.toString(), USER_REACTIONS_QUEUE, update);
}
```

- The payload is a **full snapshot**, not a delta: `currentReactions(message.getId())`
  re-reads every reaction on the message via `findByMessage_Id` and maps each to a
  `ReactionEntry`. Clients replace their local reaction list for that message wholesale —
  simple and self-healing (no risk of drifting deltas).
- **Recipient set depends on conversation kind** (resolved by `ConversationUtil`, see
  below):
  - **Direct ("dm:") conversation:** exactly the two participants decoded from the id
    (`participants[0]`, `participants[1]`). Both get the update — including the reactor
    themselves, so the actor's own UI confirms via the same channel.
  - **Group ("group:") conversation:** every current `GroupMember` of the group
    (`groupMemberRepository.findByGroupId(groupId)`), again including the reactor.
  - If the id matches neither prefix, nothing is sent.
- **Transport:** `SimpMessagingTemplate.convertAndSendToUser(userId, "/queue/reactions",
  update)`. This is the per-user STOMP destination — Spring routes it to the named user's
  private queue. The user-id string is the same principal id used everywhere else.
  Mechanics of the STOMP/WebSocket setup (broker config, user destination prefix, the
  client subscription convention) are shared infrastructure documented in the **message**
  doc; reactions reuse it exactly the way other real-time updates do — only the
  destination constant (`/queue/reactions`) and payload type (`ReactionUpdate`) differ.

> **Ordering note for the review:** `broadcast` runs *inside* the `@Transactional` method,
> before commit. `currentReactions` reads through the same transaction, so it reflects the
> just-saved change. The actual STOMP send is performed by `SimpMessagingTemplate`
> immediately; it is not bound to transaction commit.

### 4d. Authorization — `ensureMember(...)`

```java
private void ensureMember(Long userId, String conversationId) {
    if (ConversationUtil.isDirect(conversationId)) {
        long[] participants = ConversationUtil.dmParticipants(conversationId);
        boolean isParticipant = (userId == participants[0] || userId == participants[1]);
        if (!isParticipant) {
            throw new ApiException(HttpStatus.FORBIDDEN,
                    "You are not part of this conversation.");
        }
    } else if (ConversationUtil.isGroup(conversationId)) {
        Long groupId = ConversationUtil.groupIdFrom(conversationId);
        boolean isMember = groupMemberRepository.existsByGroupIdAndUserId(groupId, userId);
        if (!isMember) {
            throw new ApiException(HttpStatus.FORBIDDEN,
                    "You are not a member of this group.");
        }
    }
}
```

Who can react:

- **DM:** only the two users encoded in the `dm:` conversation id. The participant check is
  pure string parsing — no DB hit — because the id *is* the membership.
- **Group:** any current member, verified with
  `groupMemberRepository.existsByGroupIdAndUserId(groupId, userId)` (an efficient
  `EXISTS` query rather than loading rows).
- Non-members get **403 Forbidden** with a kind-specific message.

> ⚠️ One implementation caveat worth flagging in review: the DM check uses `==` on boxed
> `long[]` vs `Long userId` — `userId == participants[0]`. Here `participants` is a
> primitive `long[]`, so `userId` (a `Long`) is **auto-unboxed** to `long` and the
> comparison is a value comparison — correct. (If `participants` were `Long[]`, this would
> be reference-identity and a latent bug. It is not, so the code is sound, but it relies on
> the array being primitive.)

### 4e. Author notification — `notifyAuthorIfNeeded(...)`

```java
private void notifyAuthorIfNeeded(Message message, Long reactorId, String emoji) {
    Long authorId = message.getSender().getId();

    boolean reactingToOwnMessage = authorId.equals(reactorId);
    if (reactingToOwnMessage) {
        return;
    }

    String reactorName = reactorNameOf(reactorId);
    notificationService.sendReactionNotification(
            authorId, message.getConversationId(), reactorName, emoji);
}

private String reactorNameOf(Long reactorId) {
    Optional<User> maybeReactor = userRepository.findById(reactorId);
    if (maybeReactor.isEmpty()) {
        return "Someone";
    }
    return maybeReactor.get().getName();
}
```

- **Trigger:** only on `react` (add/change), **not** on `unreact`.
- **Self-reaction is suppressed:** if the reactor *is* the message author, no notification.
- **Recipient:** exactly the **message author** (`message.getSender().getId()`) — a single
  user, regardless of DM vs group. (Contrast with `broadcast`, which goes to *all*
  participants.)
- **Reactor name** is resolved via `userRepository.findById`, falling back to `"Someone"`
  if the user can't be found (defensive — shouldn't normally happen since the reactor was
  just authorized).

The notification itself is built and sent in `NotificationService.sendReactionNotification`
(`notification/NotificationService.java`):

```java
public void sendReactionNotification(Long recipientId, String conversationId,
                                     String reactorName, String emoji) {
    String emojiText = (emoji == null) ? "" : emoji;
    String preview = "Reacted " + emojiText + " to your message";

    NotificationDto notification = new NotificationDto(
            "REACTION", conversationId, reactorName, preview, 0, 0);

    messagingTemplate.convertAndSendToUser(
            recipientId.toString(), NOTIFICATION_QUEUE, notification);   // "/queue/notifications"
}
```

- Builds a `NotificationDto` of type `"REACTION"` with `senderName = reactorName` and
  `preview = "Reacted <emoji> to your message"`.
- The unread counters (`conversationUnread`, `totalUnread`) are hardcoded to `0` — a
  reaction does not increment unread counts; it is a soft, informational ping.
- Delivered on a **separate** STOMP destination: `/queue/notifications` (distinct from the
  `/queue/reactions` channel used for the live reaction state). So the author receives two
  pushes from one `react` call: a `ReactionUpdate` (their message list updates) and a
  `NotificationDto` (a toast/badge).

---

## 5. Aggregation for display — `reactionsForMessages` → `ReactionEntry`

This is how reactions reach the client during normal history loads, consumed by
`message/ConversationService.java`.

```java
@Transactional(readOnly = true)
public Map<Long, List<ReactionEntry>> reactionsForMessages(List<Long> messageIds) {
    if (messageIds.isEmpty()) {
        return Map.of();
    }

    List<Reaction> reactions = reactionRepository.findByMessage_IdIn(messageIds);

    Map<Long, List<ReactionEntry>> entriesByMessageId = new HashMap<>();
    for (Reaction reaction : reactions) {
        Long messageId = reaction.getMessage().getId();
        ReactionEntry entry = toEntry(reaction);

        List<ReactionEntry> entriesForMessage = entriesByMessageId.get(messageId);
        if (entriesForMessage == null) {
            entriesForMessage = new ArrayList<>();
            entriesByMessageId.put(messageId, entriesForMessage);
        }
        entriesForMessage.add(entry);
    }
    return entriesByMessageId;
}

private ReactionEntry toEntry(Reaction reaction) {
    User user = reaction.getUser();
    return new ReactionEntry(user.getId(), user.getName(), reaction.getEmoji());
}
```

- **Single batched query** (`findByMessage_IdIn`) for the whole page, then **in-memory
  grouping** into `Map<messageId, List<ReactionEntry>>`. Empty input short-circuits to
  `Map.of()` (avoids issuing an empty `IN ()`).
- `toEntry` flattens each reaction into the display shape `{ userId, userName, emoji }`.
  Note: each entry carries the reactor's name (read via the lazy `user` proxy, safe under
  the open transaction), so the UI can show *who* reacted with what — there is **no
  server-side grouping/counting by emoji**. Each user's single reaction is one entry;
  aggregation by emoji (e.g. "👍 ×3") is left to the client.

### How conversation history consumes it

In `ConversationService.buildMessageResponses(...)` (around lines 240–270):

```java
List<Long> messageIds = collectIds(messages);
...
Map<Long, List<ReactionEntry>> reactionsByMessageId =
        reactionService.reactionsForMessages(messageIds);
...
for (Message message : messages) {
    ...
    List<ReactionEntry> reactions =
            reactionsByMessageId.getOrDefault(message.getId(), List.of());
    responses.add(buildMessageResponse(message, status, reactions, repliedStatusById));
}
```

and in `buildMessageResponse`:

```java
return MessageResponse.builder()
        ...
        .reactions(reactions)
        ...
        .build();
```

So:

- Reactions are fetched **once per page**, alongside statuses
  (`messageStatusService.statusForMessages`) and reply previews — all batched the same way
  to avoid N+1.
- Each message's reactions are attached via `getOrDefault(id, List.of())`, so a message
  with no reactions gets an empty list (never null).
- The final `MessageResponse` carries `private List<ReactionEntry> reactions;`
  (`message/dtos/MessageResponse.java`), so the client receives reactions **inline with the
  message** on history load — no extra request.

### `currentReactions` vs `reactionsForMessages`

Both produce `List<ReactionEntry>` via the same `toEntry`, but serve different paths:

| Method | Query | Returns | Used by |
|--------|-------|---------|---------|
| `currentReactions(messageId)` | `findByMessage_Id` (one message) | `List<ReactionEntry>` | `broadcast` — the live `ReactionUpdate` payload (§4c). |
| `reactionsForMessages(ids)` | `findByMessage_IdIn` (batch) | `Map<Long, List<ReactionEntry>>` | conversation history load (§5). |

The live path needs only one message's reactions; the history path needs many, so it uses
the batch query and groups the result.

---

## 6. Framework mechanisms — consolidated WHAT / WHY / HOW

- **`@Transactional` on writes (`react`, `unreact`).** *What:* run the whole method in one
  DB transaction. *Why:* the load → authorize → upsert/delete → read-for-broadcast steps
  must see a consistent state, and lazy associations (`message.getSender()`,
  `reaction.getUser()`) must resolve within an open Hibernate session. *How:* Spring's
  transaction proxy opens a transaction on entry and commits on normal return / rolls back
  on a thrown `ApiException`.
- **`@Transactional(readOnly = true)` on reads (`reactionsForMessages`).** *What:* a
  read-only transaction. *Why:* keeps the session open for lazy `getUser().getName()` while
  signalling no writes (lets Hibernate skip dirty-checking/flush — a small optimization).
- **Spring Data JPA derived queries + batch `IN`.** *What:* method-name-derived SQL. *Why:*
  no boilerplate, and `findByMessage_IdIn` collapses per-message reaction lookups into one
  round trip — the **N+1 defense** for history loads. *How:* Spring parses method names at
  startup and synthesizes the implementation.
- **`getReferenceById` for the FK.** *What:* a lazy entity proxy holding only the id. *Why:*
  setting `reaction.user` on insert needs only the FK value, not a loaded `User` row — saves
  a SELECT. *How:* Hibernate returns a proxy; no query until a non-id field is touched.
- **`SimpMessagingTemplate.convertAndSendToUser(user, dest, payload)`.** *What:* send a
  STOMP message to one user's private destination. *Why:* push reaction state and
  notifications in real time without polling. *How:* Spring serializes the payload (JSON)
  and routes it to the user-specific queue; the client subscribes to `/user/queue/reactions`
  (and `/user/queue/notifications`). Broker/endpoint configuration is shared and described
  in the **message** doc.
- **`ConversationUtil` for recipient resolution** (`common/ConversationUtil.java`). *What:*
  pure helpers that interpret a `conversationId` string. *Why:* the conversation id itself
  encodes identity — `dm:<a>:<b>` (sorted) or `group:<id>` — so membership and recipient
  sets can be derived without extra schema. *How:* `isDirect`/`isGroup` test the prefix;
  `dmParticipants` splits `dm:a:b` into `[a, b]`; `groupIdFrom` parses the numeric group id.
  Used by both `ensureMember` (who may react) and `broadcast` (who receives the update).

---

## 7. End-to-end summary

**Add/change** (`POST /api/messages/{id}/reactions`):
auth (401) → validate emoji (400) → load message (404) → `ensureMember` (403) → upsert the
single `(message, user)` reaction → save → broadcast full snapshot to all participants over
`/queue/reactions` → notify the author over `/queue/notifications` (unless self-reaction).

**Remove** (`DELETE /api/messages/{id}/reactions`):
auth (401) → load message (404) → `ensureMember` (403) → idempotent delete of caller's
reaction → broadcast updated snapshot. No notification.

**Display:** reactions are never fetched standalone — they ride inline on `MessageResponse`
during history loads (batched via `findByMessage_IdIn` to avoid N+1) and are pushed live as
full `ReactionUpdate` snapshots after every write. The unique constraint
`(message_id, user_id)` is the invariant that makes the whole "one emoji per user, overwrite
on change" model correct and race-safe.
