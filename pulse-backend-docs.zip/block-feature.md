# The Block Feature — End to End

This documents blocking in Pulse against the **current** code: blocking / unblocking a
user, listing who you blocked, checking block status, and — the important part — the two
query directions (`hasBlocked` vs `isBlockedBetween`) plus the id-list helpers
(`blockedIdsOf` / `blockersOf`) that the rest of the app uses to hide things.

The `blocks` table is tiny. The depth is in how **other** features ask it questions and
how a single one-directional row produces two-directional effects.

---

## 1. The big idea

A "block" is a **one-directional** record: *"I (`blocker`) have blocked this other user
(`blocked`)."* Blocking user 3 does not make 3 block you — it's a single row, in one
direction. Unblocking deletes only your own row.

But the *effects* of a block are usually **two-directional**. If a block exists between two
people (in either direction), most features hide the interaction both ways: the blocked
person can't message you, see your presence/last-seen, see your avatar, or see your status;
and you symmetrically stop seeing their live stuff in most places.

So: **data is one-way, enforcement is mostly "is there a block in *either* direction?"**
That asymmetry is the entire reason there are two boolean query methods plus two id-list
helpers (section 5).

A few places genuinely care about direction (the status endpoint reports specifically
*"have I blocked them"*; group/DM delivery is keyed off the symmetric check). The matrix in
section 9 spells out which method each caller uses and why.

---

## 2. The data model — `blocks` table (`Block.java`)

```java
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "blocks",
        uniqueConstraints = @UniqueConstraint(
                columnNames = {"blocker_id", "blocked_id"}))
public class Block {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "blocker_id", nullable = false)
    private User blocker;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "blocked_id", nullable = false)
    private User blocked;

    @CreationTimestamp
    @Column(updatable = false)
    private Instant createdAt;
}
```

Field by field:

| Column | Mapping | Meaning |
|---|---|---|
| `id` | `@Id @GeneratedValue(IDENTITY)` | DB-assigned surrogate PK |
| `blocker_id` | `@ManyToOne(LAZY)` + `@JoinColumn(nullable=false)` | the user doing the blocking |
| `blocked_id` | `@ManyToOne(LAZY)` + `@JoinColumn(nullable=false)` | the user being blocked |
| `created_at` | `@CreationTimestamp @Column(updatable=false)` | set once at insert, never updated |

Key points:

- Both FKs are **`FetchType.LAZY`** — `User` objects are only materialized when actually
  dereferenced (e.g. `block.getBlocked()` in `listBlocked`). The id-only repository queries
  never touch the `users` table at all.
- **`@CreationTimestamp` + `updatable = false`** — Hibernate stamps `createdAt` on insert
  and the column is excluded from all UPDATE statements, so the "blocked at" time is
  immutable.
- **Unique constraint `(blocker_id, blocked_id)`** — you cannot block the same person twice
  in the same direction. At most one row per `(blocker, blocked)` pair. (The service also
  guards this in code via `existsBy...` before saving; the constraint is the DB backstop.)

Because the row is one-directional, for a pair of users `(7, 3)` there can be up to **two**
independent rows:

- `blocker=7, blocked=3` (7 blocked 3), and
- `blocker=3, blocked=7` (3 blocked 7).

They are independent records. The unique constraint is per direction, so both can coexist.

---

## 3. The repository — `BlockRepository.java`

This is the most query-heavy repository in the app, because so many features need to ask
blocks different questions. Three Spring Data **derived** methods and three custom
**`@Query` (JPQL)** methods.

```java
public interface BlockRepository extends JpaRepository<Block, Long> {

    Optional<Block> findByBlocker_IdAndBlocked_Id(Long blockerId, Long blockedId);

    boolean existsByBlocker_IdAndBlocked_Id(Long blockerId, Long blockedId);

    List<Block> findByBlocker_Id(Long blockerId);

    @Query("SELECT b.blocked.id FROM Block b WHERE b.blocker.id = :blockerId")
    List<Long> findBlockedIdsByBlocker(@Param("blockerId") Long blockerId);

    @Query("SELECT b.blocker.id FROM Block b WHERE b.blocked.id = :blockedId")
    List<Long> findBlockerIdsByBlocked(@Param("blockedId") Long blockedId);

    @Query("""
        SELECT COUNT(b) > 0 FROM Block b
        WHERE (b.blocker.id = :firstUserId AND b.blocked.id = :secondUserId)
           OR (b.blocker.id = :secondUserId AND b.blocked.id = :firstUserId)
        """)
    boolean existsBlockBetween(@Param("firstUserId") Long firstUserId,
                               @Param("secondUserId") Long secondUserId);
}
```

### The derived methods (parsed from the method name by Spring Data)

| Method | Direction asked | Used for |
|---|---|---|
| `findByBlocker_IdAndBlocked_Id(a, b)` | the row where **a** blocked **b** | `unblock` needs the actual row to delete |
| `existsByBlocker_IdAndBlocked_Id(a, b)` | did **a** block **b**? (one way) | dup-check before `block`; backs `hasBlocked` |
| `findByBlocker_Id(a)` | full `Block` rows where **a** is the blocker | backs `listBlocked` (needs `createdAt` + the `blocked` user) |

The `Blocker_Id` underscore tells Spring Data to traverse the `blocker` association and then
its `id` field (`b.blocker.id`) rather than a literal `blockerId` column — required because
`blocker` is a `@ManyToOne`, not a scalar.

### The three custom JPQL queries (why they exist)

- **`findBlockedIdsByBlocker` / `findBlockerIdsByBlocked`** select **only the id column**
  (`SELECT b.blocked.id` / `SELECT b.blocker.id`), returning `List<Long>`. This is
  deliberate: callers like presence and status only need a *set of user ids* to filter
  other collections in memory — loading full `Block` entities (and lazily touching `users`)
  would be wasted work. JPQL projects exactly one field into a scalar list. There is no
  derived-method spelling for "give me just this one associated id," so it's an explicit
  `@Query`.
- **`existsBlockBetween`** is the workhorse. It uses `SELECT COUNT(b) > 0 ... WHERE (a→b)
  OR (b→a)` — an **OR across both directions**. A derived `findBy...` name cannot express
  an OR over two different field pairs, so it must be written out. This single query is what
  turns a one-directional table into two-directional enforcement, and it is what most
  features call (via `isBlockedBetween`). Returning a boolean from `COUNT(...) > 0` keeps it
  to one cheap aggregate round-trip.

---

## 4. The controller — `BlockController.java`

Base path `/api/v1/blocks`. The caller's id always comes from
`SecurityUtil.currentUserId()` (JWT), never from the request body — you can only manage
*your own* blocks. Every method returns the standard `ApiResponse<T>` envelope.

| Method + path | Service call | Returns |
|---|---|---|
| `POST /api/v1/blocks/{userId}` | `block(currentUserId, userId)` | `ApiResponse.ok(null)` — block (idempotent) |
| `DELETE /api/v1/blocks/{userId}` | `unblock(currentUserId, userId)` | `ApiResponse.ok(null)` — unblock (idempotent) |
| `GET /api/v1/blocks` | `listBlocked(currentUserId)` | `ApiResponse<List<BlockedUserResponse>>` |
| `GET /api/v1/blocks/{userId}/status` | `hasBlocked(currentUserId, userId)` | `ApiResponse<Map<String,Boolean>>` → `{"blocked": true/false}` |

Detail worth defending in review: the status endpoint calls **`hasBlocked`**, the
**one-directional** check — it answers specifically *"have I blocked this user?"*, not
*"is there any block between us."* That is correct for a per-user block toggle in the UI:
the toggle reflects the current user's own action, so it must not flip on just because the
*other* person blocked *you*.

```java
@GetMapping("/{userId}/status")
public ApiResponse<Map<String, Boolean>> status(@PathVariable Long userId) {
    boolean blocked = blockService.hasBlocked(SecurityUtil.currentUserId(), userId);
    return ApiResponse.ok(Map.of("blocked", blocked));
}
```

`Map.of("blocked", blocked)` ships a one-key JSON object without a dedicated DTO for a
single boolean.

---

## 5. The service — the query directions (the important part)

`BlockService` splits into **commands** (mutate) and **queries** (answer questions other
features ask). It injects four collaborators:

```java
private final BlockRepository blockRepository;
private final UserRepository userRepository;
private final ContactRepository contactRepository;   // NEW: for savedAlias in listBlocked
private final StorageService storageService;          // presigned avatar URLs
```

`ContactRepository` is injected so the blocked-list can show the **alias the blocker saved**
for that contact (section 8). This is the recent change that made the old doc stale.

### Commands

**`block(blockerId, blockedId)`** — `@Transactional`:

```java
boolean blockingYourself = blockerId.equals(blockedId);
if (blockingYourself) {
    throw new ApiException(HttpStatus.BAD_REQUEST, "You cannot block yourself.");
}

boolean alreadyBlocked = blockRepository.existsByBlocker_IdAndBlocked_Id(blockerId, blockedId);
if (alreadyBlocked) {
    return;                       // idempotent — blocking twice is a no-op, not an error
}

User blocker = findUserOrThrow(blockerId, "User not found.");
User blocked = findUserOrThrow(blockedId, "User to block not found.");

Block block = new Block();
block.setBlocker(blocker);
block.setBlocked(blocked);
blockRepository.save(block);
```

Order matters: self-block → **400**; already blocked → silent return (no second row, no
error); then both users must exist → **404**; then insert.

**`unblock(blockerId, blockedId)`** — `@Transactional`:

```java
Optional<Block> existingBlock =
        blockRepository.findByBlocker_IdAndBlocked_Id(blockerId, blockedId);
if (existingBlock.isPresent()) {
    blockRepository.delete(existingBlock.get());
}
```

If there's no such row, it does nothing — also idempotent. It removes only the caller's own
direction; any reverse block (the other person blocking the caller) is untouched.

> "Idempotent" = calling it again reaches the same end state without error. Important for UI
> buttons a user may double-tap.

### Queries (consumed by other features)

This is the key table — note the **direction** each one asks:

| Method | Repo call | Direction | Returns |
|---|---|---|---|
| `hasBlocked(A, B)` | `existsByBlocker_IdAndBlocked_Id(A, B)` | **one-way**: did A block B? | `boolean` |
| `isBlockedBetween(A, B)` | `existsBlockBetween(A, B)` | **either way** (A→B OR B→A) | `boolean` |
| `blockedIdsOf(A)` | `findBlockedIdsByBlocker(A)` | ids **A blocked** | `List<Long>` |
| `blockersOf(A)` | `findBlockerIdsByBlocked(A)` | ids **who blocked A** | `List<Long>` |
| `listBlocked(A)` | `findByBlocker_Id(A)` + map | rows A created (for the UI) | `List<BlockedUserResponse>` |

All five are `@Transactional(readOnly = true)`.

`isBlockedBetween` is the single most-used method: most features don't care *who* blocked
*whom* — if a block exists in either direction, hide the interaction. `hasBlocked` is used
only where direction is the point (the status endpoint). `blockedIdsOf` / `blockersOf`
return id lists so a caller can compute a hidden-id `Set` once and filter a batch in memory
(presence, status) instead of running a per-pair query in a loop.

---

## 6. FLOW: blocking a user

```
POST /api/v1/blocks/3
  -> blockerId = me (from JWT), blockedId = 3
  -> blocking myself?           -> 400 "You cannot block yourself."
  -> existsByBlocker_IdAndBlocked_Id(me, 3)? -> true: return (idempotent no-op)
  -> findUserOrThrow(me)        -> 404 if missing
  -> findUserOrThrow(3)         -> 404 if missing
  -> save Block(blocker=me, blocked=3)   (createdAt stamped by @CreationTimestamp)
  -> 200 ApiResponse.ok(null)
```

After this insert, every feature that calls `isBlockedBetween(me, 3)` (or, for the toggle,
`hasBlocked(me, 3)`) starts returning `true` and hides accordingly. Blocking does **not**
delete past messages or the contact row — it gates *future* interaction and *live* info.
See section 9 for exactly what each feature suppresses.

---

## 7. FLOW: unblocking

```
DELETE /api/v1/blocks/3
  -> findByBlocker_IdAndBlocked_Id(me, 3)
  -> present? delete the row : do nothing
  -> 200 ApiResponse.ok(null)
```

Only my `me→3` row is removed. If 3 had also blocked me (`3→me`), that row survives and
`isBlockedBetween(me, 3)` still returns `true` — hiding continues until 3 unblocks too.

---

## 8. FLOW: listing blocked users (`listBlocked`) — alias-or-number

`GET /api/v1/blocks` → `findByBlocker_Id(me)` → map each `Block` to a `BlockedUserResponse`.
The DTO:

```java
@Getter
@AllArgsConstructor
public class BlockedUserResponse {
    private final Long userId;
    private final String name;       // alias-or-null (see below) — NOT the registered name
    private final String phone;
    private final String avatarUrl;  // presigned
    private final Instant blockedAt;
}
```

The mapping (current behaviour — this is the part that changed):

```java
private BlockedUserResponse toBlockedUserResponse(Block block, Long blockerId) {
    User blockedUser = block.getBlocked();
    String avatarUrl = storageService.presignedUrl(blockedUser.getAvatarUrl());
    String displayName = savedAlias(blockerId, blockedUser.getId());   // <-- alias, not name

    return new BlockedUserResponse(
            blockedUser.getId(),
            displayName,
            blockedUser.getPhone(),
            avatarUrl,
            block.getCreatedAt());
}

private String savedAlias(Long ownerId, Long contactUserId) {
    return contactRepository.findByOwner_IdAndContact_Id(ownerId, contactUserId)
            .map(Contact::getAlias)
            .filter(alias -> alias != null && !alias.isBlank())
            .orElse(null);
}
```

What this means, and why it matters for review:

- The `name` field is **the alias the blocker saved for that contact**, looked up via
  `ContactRepository.findByOwner_IdAndContact_Id(blockerId, blockedUserId)`.
- If the blocker has no contact row for that user, or the saved alias is null/blank,
  `name` is **`null`**. The client is expected to fall back to displaying the phone number.
- Therefore the blocked list shows **alias-or-number, never the blocked user's registered
  display name**. Rationale: privacy/consistency with the rest of the app — you see people
  by the name *you* gave them (or their number), not the self-chosen profile name. This is
  the same alias-first convention used in contacts and profiles (`displayNameFor`).
- This is the reason `BlockService` now depends on `ContactRepository`; the older doc
  predates this and incorrectly described `name` as the registered name.

The blocked person's **avatar is still presigned and returned** on purpose: this is *your
own* management screen of people *you* blocked, so you need to recognize them. The hiding
rules apply to interactions, not to your own block-management list.

---

## 9. How other features use blocks — the enforcement matrix

These are **cross-links**, not re-documentation. Each feature owns its own doc; here we only
record which `BlockService` method it calls and why. All checks are reads; none of these
callers mutate blocks.

| Feature (file) | Method called | Direction | Effect |
|---|---|---|---|
| **Direct message send** — `message/ChatService.java` (`sendMessage`, line ~78) | `isBlockedBetween(sender, receiver)` | either-way | If blocked, the message is still **saved**, but no recipient status is created, and it is **not delivered/notified** to the receiver (only echoed back to the sender). |
| **Group message delivery** — `message/ChatService.java` (`deliverableRecipientIds`, line ~161) | `isBlockedBetween(sender, member)` | either-way | A group member is dropped from the recipient list (no status row, no socket push, no notification) if a block exists either way with the sender — **symmetric**: blocker and blocked both stop receiving each other's group messages. |
| **Conversation partners list** — `message/ConversationService.java` (`getPartners`, line ~106) | `isBlockedBetween(currentUser, partner)` | either-way | DM partners with a block either way are removed from the conversation/partner list. |
| **Chat history visibility** — `message/ConversationService.java` (`hiddenByBlock`, line ~286) | (uses delivery state, not a direct block query) | n/a | A message you never received (no recipient status was created — see DM/group rules above) is hidden from your history, **except** your own messages and messages already delivered to you. So the block hides messages indirectly via the missing recipient-status rows the send-time check skipped. |
| **Typing indicator (DM)** — `message/TypingService.java` (line ~53) | `isBlockedBetween(sender, recipient)` | either-way | Typing event is suppressed if blocked either way. |
| **Typing indicator (group)** — `message/TypingService.java` (line ~76) | `isBlockedBetween(sender, member)` | either-way | Per-member: a blocked member (either direction) does not receive the typing event. |
| **Presence — single lookup** — `user/PresenceService.java` (`getPresenceFor`, line ~110) | `isBlockedBetween(viewer, user)` | either-way | If blocked either way, return forced **offline, no last-seen**. |
| **Presence — batch lookup** — `user/PresenceService.java` (`getPresenceForViewer` → `collectHiddenUserIds`, line ~138) | `blockersOf(viewer)` + `blockedIdsOf(viewer)` | both id lists, unioned | Builds one `Set<Long>` of everyone with a block in either direction with the viewer; each is reported offline/no-last-seen. Uses the id-list helpers to avoid per-user queries in the loop. |
| **Presence — broadcast fan-out** — `user/PresenceService.java` (`broadcast`, line ~183) | `collectHiddenUserIds(update.userId)` (= `blockersOf` ∪ `blockedIdsOf`) | both id lists | When a user's presence changes, the update is **not** pushed to anyone with a block either way relative to that user. |
| **Contact card render** — `contact/ContactService.java` (`toResponse`, line ~174) | `isBlockedBetween(contactUser, owner)` | either-way | If blocked either way, the contact's `avatarUrl` and `lastSeen` are nulled out (the row still appears, but live/profile info is hidden). |
| **Contact list/search blocked flag** — `contact/ContactService.java` (`isBlocked`, line ~68) | `isBlockedBetween(owner, contact)` | either-way | Drives the `blocked` flag exposed in list/search results. |
| **Profile view** — `user/UserProfileService.java` (`getUserProfileFor`, line ~40) | `isBlockedBetween(viewer, owner)` | either-way | If blocked either way, `avatarUrl` and `lastSeen` are hidden (name still resolved via alias). |
| **Status creation** — `status/StatusService.java` (`hideFromBlockedViewers` → `blockedOrBlockingIds`, line ~109/276) | `blockedIdsOf(author)` + `blockersOf(author)` | both id lists, unioned | On posting a status, a `HiddenStatus` row is written for every user with a block either way relative to the author, so they never see it. |
| **Status feed** — `status/StatusService.java` (`getContactStatuses` → `blockedOrBlockingIds`, line ~138/276) | `blockedIdsOf(user)` + `blockersOf(user)` | both id lists, unioned | Authors with a block either way are excluded from the viewer's contact-status feed. |
| **Block status toggle** — `block/BlockController.java` (`status`) | `hasBlocked(me, target)` | **one-way** | The only consumer that uses the directional check — reflects whether *I* blocked *them*. |

Reading of the matrix: almost everything uses **`isBlockedBetween`** (or the
`blockersOf ∪ blockedIdsOf` id-list form of the same idea) so the effect is symmetric. The
single directional consumer is the **status endpoint** (`hasBlocked`). Group/DM delivery is
symmetric by design — neither party receives the other's live messages once a block exists
in either direction.

---

## 10. Libraries & mechanisms — WHAT / WHY / HOW

### JPA + Hibernate (entity mapping)
- **WHAT:** JPA is the spec for mapping Java objects to relational rows; Hibernate is the
  implementation. `Block` is an `@Entity` mapped to `blocks`.
- **WHY:** lets the rest of the app work with `Block`/`User` objects and associations
  instead of hand-written SQL and result-set plumbing.
- **HOW:** `@Entity` + `@Table` (with `@UniqueConstraint`) define the table; `@Id` +
  `@GeneratedValue(IDENTITY)` delegate PK generation to the DB; `@ManyToOne(LAZY)` +
  `@JoinColumn` map `blocker`/`blocked` to FK columns and defer loading the `User` until
  dereferenced; `@CreationTimestamp` + `@Column(updatable=false)` stamp `createdAt` on
  insert and freeze it.

### Spring Data JPA — derived query methods
- **WHAT:** repository interface methods whose **names** are parsed into queries.
- **WHY:** no boilerplate for the common reads/exists/deletes.
- **HOW:** `BlockRepository extends JpaRepository<Block, Long>`. Spring generates a proxy at
  startup; `findByBlocker_IdAndBlocked_Id`, `existsByBlocker_IdAndBlocked_Id`,
  `findByBlocker_Id` are parsed (the `_Id` traverses the `@ManyToOne` association to its
  `id`). `save`/`delete`/`findById` come from `JpaRepository`.

### `@Query` with JPQL — custom queries
- **WHAT:** explicit queries in **JPQL** (object query language: entity/field names like
  `b.blocked.id`, not table/column names).
- **WHY:** for things derived names can't express — (a) projecting a **single id column**
  into `List<Long>` to keep filtering cheap, and (b) an **OR across both directions** for the
  symmetric existence check.
- **HOW:** `findBlockedIdsByBlocker` / `findBlockerIdsByBlocked` do
  `SELECT b.blocked.id` / `SELECT b.blocker.id`; `existsBlockBetween` does
  `SELECT COUNT(b) > 0 ... WHERE (a→b) OR (b→a)`. `:firstUserId` etc. are bound via
  `@Param`. Hibernate translates JPQL to SQL.

### Spring `@Transactional`
- **WHAT:** declarative transaction boundaries on service methods.
- **WHY:** commands (`block`/`unblock`) must run atomically; queries run in a read
  transaction so lazy associations (`block.getBlocked()` in `listBlocked`) resolve inside an
  open persistence context, and the DB can optimize read-only work.
- **HOW:** `block`/`unblock` are `@Transactional`; the five query methods are
  `@Transactional(readOnly = true)`. Spring wraps each call in a proxy that opens/commits
  (or rolls back) the transaction.

### `ApiException` + `ApiResponse` (cross-cutting)
- **WHAT:** the app's uniform error and response envelope.
- **WHY/HOW:** `block` throws `ApiException(BAD_REQUEST/NOT_FOUND, msg)` for self-block and
  missing users; a global handler turns it into the standard error body. Controller methods
  wrap payloads in `ApiResponse.ok(...)`.

---

## 11. Quick reference

### Endpoints
| Method + path | Returns |
|---|---|
| `POST /api/v1/blocks/{userId}` | block (idempotent) |
| `DELETE /api/v1/blocks/{userId}` | unblock (idempotent) |
| `GET /api/v1/blocks` | list of blocked users (alias-or-number, never registered name) |
| `GET /api/v1/blocks/{userId}/status` | `{ "blocked": bool }` — one-way, `hasBlocked` |

### Service queries other features call
| Method | Direction | Backed by |
|---|---|---|
| `hasBlocked(A, B)` | A→B only | `existsByBlocker_IdAndBlocked_Id` |
| `isBlockedBetween(A, B)` | either direction | `existsBlockBetween` (JPQL OR) |
| `blockedIdsOf(A)` | ids A blocked | `findBlockedIdsByBlocker` (id-only) |
| `blockersOf(A)` | ids who blocked A | `findBlockerIdsByBlocked` (id-only) |
| `listBlocked(A)` | A's block rows for UI | `findByBlocker_Id` + `savedAlias` |

### The one-line mental model
> **A block is a one-way `blocker → blocked` row. Enforcement is mostly two-way:
> `isBlockedBetween` ("either direction") is the question almost every feature asks to hide
> messages, typing, presence, contacts, profiles and statuses; `blockersOf` ∪ `blockedIdsOf`
> is the id-list form of the same idea for batch filtering; `hasBlocked` (one-way) is used
> only by the block-status toggle. The blocked-users list shows the alias you saved or the
> phone number — never the registered name — which is why `BlockService` now injects
> `ContactRepository`.**
