# The Message / Chat Feature — Backend Flow (Current)

This is the authoritative, code-grounded reference for Pulse's Message/Chat feature. It
is the realtime hub of the app, so WebSocket/STOMP gets the deepest treatment. Every
claim here is verified against the current source in `com.mohan.pulse.message` (plus the
WebSocket config, the WS/REST auth plumbing, and the collaborating `block`,
`notification`, `user` (presence) and `group` packages).

Audience: a developer defending this design in a review. It does not oversimplify.

---

## 1. Overview

A chat app needs two fundamentally different transport shapes:

1. **Server push** — when someone sends you a message, edits it, deletes it, starts
   typing, or marks your message read, it must reach your screen *without you asking*.
   Plain HTTP cannot do this: the client must initiate every exchange.
2. **Request / response** — when you open a chat you ask for "the last N messages",
   "unread counts", "delivery info for this message". The client asks, the server
   answers, done.

Pulse therefore splits the one logical feature across **two channels**:

| Need | Transport | Spring style | Components |
|------|-----------|--------------|------------|
| Live push (both directions) | **WebSocket + STOMP** | `@Controller` + `@MessageMapping` | `ChatController` |
| Ask / answer | **REST (HTTP)** | `@RestController` + `@GetMapping`/`@PutMapping`/`@DeleteMapping` | `ConversationController`, `MessageActionController`, `MessageStatusController` |

This is why a single feature has four controllers. Keep the split in mind:

- **`ChatController`** (WebSocket): send DM, send group, delivered ack, read ack, typing.
- **`ConversationController`** (REST): history pages, unread counts, partners, summaries,
  hidden conversations, clear conversation.
- **`MessageActionController`** (REST): edit, delete-for-me, delete-for-everyone.
- **`MessageStatusController`** (REST): per-message delivery info ("message info" screen).

A subtle but important asymmetry: **sending** a message happens over WebSocket, but its
*side effects* (edit/delete) are triggered over REST and then **broadcast back over
WebSocket**. So `MessageActionService` is a REST service that pushes STOMP events. There
is no rule that "REST controllers never push" — they use `SimpMessagingTemplate` freely.

---

## 2. The two channels in detail

### 2.1 REST channel — how `currentUserId` is established

REST requests carry a JWT in the `Authorization: Bearer <token>` header. `JwtAuthFilter`
(an `OncePerRequestFilter`, runs once per HTTP request) validates it and puts the user id
into Spring Security's context as the *principal*:

```java
private void authenticate(HttpServletRequest request, Long userId) {
    UsernamePasswordAuthenticationToken authentication =
            new UsernamePasswordAuthenticationToken(userId, null, Collections.emptyList());
    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
    SecurityContextHolder.getContext().setAuthentication(authentication);
}
```

Note the principal is the raw `Long userId`, not a `UserDetails`. REST controllers then
read it through `SecurityUtil.currentUserId()`:

```java
public static Long currentUserId() {
    Authentication authentication =
            SecurityContextHolder.getContext().getAuthentication();
    if (authentication == null || !authentication.isAuthenticated()) {
        throw new ApiException(HttpStatus.UNAUTHORIZED, "You are not logged in.");
    }
    Object principal = authentication.getPrincipal();
    if (principal instanceof Long userId) {
        return userId;
    }
    throw new ApiException(HttpStatus.UNAUTHORIZED, "Could not identify the current user.");
}
```

So every REST handler starts with `Long currentUserId = SecurityUtil.currentUserId();`.

### 2.2 WebSocket channel — how the `Principal` is established

The WebSocket cannot use the `Authorization` header during the SockJS/STOMP handshake
the same way, so the token arrives as a **query parameter** `?token=...`. Two collaborating
classes set up the socket identity:

**`WebSocketAuthInterceptor`** (a `HandshakeInterceptor`) runs `beforeHandshake`. It pulls
the token from the query string, validates it, and stashes the user id in the handshake
**attributes** map:

```java
String query = request.getURI().getQuery();
boolean tokenMissing = (query == null || !query.contains(TOKEN_PARAM));
if (tokenMissing) {
    return false;          // reject handshake → no WebSocket
}
String token = extractToken(query);
boolean tokenIsValid = jwtUtil.isValid(token);
if (!tokenIsValid) {
    return false;
}
Long userId = jwtUtil.extractUserId(token);
attributes.put("userId", userId);
return true;
```

Returning `false` aborts the upgrade, so an unauthenticated client never gets a socket.

**`WebSocketHandshakeHandler`** (extends `DefaultHandshakeHandler`) then turns that
attribute into the STOMP session `Principal`:

```java
protected Principal determineUser(...) {
    Long userId = (Long) attributes.get("userId");
    if (userId == null) {
        return null;
    }
    String userIdAsName = userId.toString();
    return new Principal() {
        @Override public String getName() { return userIdAsName; }
    };
}
```

So **`principal.getName()` is the stringified user id** for the lifetime of that socket.
Every `@MessageMapping` handler recovers the sender with
`Long senderId = Long.valueOf(principal.getName());`. This Principal is also what
`SimpMessagingTemplate.convertAndSendToUser(userId.toString(), ...)` targets, and what
`PresenceService`'s `SessionConnectedEvent`/`SessionDisconnectEvent` listeners read
(`event.getUser()`).

---

## 3. STOMP / WebSocket deep-dive

### 3.1 What WebSocket and STOMP are

- A **WebSocket** is a single long-lived, bidirectional TCP connection upgraded from
  HTTP. Once open, either side can send frames at any time — this is what enables push.
- A raw WebSocket only carries bytes; it has no notion of addresses or subscriptions.
  **STOMP** (Simple Text Oriented Messaging Protocol) is a thin text protocol layered on
  top. It introduces:
  - **destinations** — string addresses such as `/app/chat.send`, `/topic/presence`,
    `/user/queue/messages`.
  - **SEND** frames (client → server) and **SUBSCRIBE** frames ("push me anything that
    arrives at this destination").
  - **MESSAGE** frames (server → client) delivered to matching subscriptions.

### 3.2 The broker configuration — `WebSocketConfig`

```java
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    private static final String WEBSOCKET_ENDPOINT = "/ws";

    @Value("${app.allowed-origins}")
    private String allowedOrigins;
    ...
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        // allowedOrigins is a comma-separated env-driven list, trimmed and split:
        ...
        registry
                .addEndpoint(WEBSOCKET_ENDPOINT)             // clients connect to /ws
                .addInterceptors(authInterceptor)            // token check at handshake
                .setHandshakeHandler(new WebSocketHandshakeHandler()) // sets Principal
                .setAllowedOrigins(allowedOriginsArray)
                .withSockJS();                               // SockJS fallback enabled
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(1);
        scheduler.setThreadNamePrefix("ws-heartbeat-");
        scheduler.initialize();

        registry.enableSimpleBroker("/topic", "/queue")     // in-memory broker
                .setHeartbeatValue(new long[] { 10000, 10000 })
                .setTaskScheduler(scheduler);

        registry.setApplicationDestinationPrefixes("/app");  // → @MessageMapping
        registry.setUserDestinationPrefix("/user");          // → per-user queues
    }
}
```

What each piece means:

- **`/ws`** — the single SockJS endpoint the browser connects to (with `?token=...`).
- **`enableSimpleBroker("/topic", "/queue")`** — Pulse uses the **in-memory simple
  broker** (not RabbitMQ/ActiveMQ). The broker owns destinations starting with `/topic`
  and `/queue`; it routes server-sent messages to subscribers. Implication: broadcast
  state lives in a single JVM — this design is single-instance / not horizontally scaled
  without an external broker.
- **Heartbeats `{10000, 10000}`** — server and client each expect a heartbeat every 10s,
  driven by the dedicated `ws-heartbeat-` scheduler, so dead sockets are detected and
  `PresenceService` can mark users offline.
- **`setApplicationDestinationPrefixes("/app")`** — inbound client SENDs to `/app/...`
  are routed to `@MessageMapping` handlers (not to the broker). So `/app/chat.send` →
  `ChatController.sendMessage`.
- **`setUserDestinationPrefix("/user")`** — enables **user destinations**. A client
  subscribes to `/user/queue/messages`; Spring rewrites that per-session into a unique
  internal destination. The server sends with
  `convertAndSendToUser("42", "/queue/messages", payload)` and Spring delivers it only to
  user 42's session(s) on their `/user/queue/messages` subscription. This is the backbone
  of all "send to one specific user" pushes in this feature.

### 3.3 The destination convention used by this feature

| Prefix | Owner | Direction | Meaning |
|--------|-------|-----------|---------|
| `/app/...` | App (`@MessageMapping`) | client → server | A command: send, ack, typing |
| `/user/queue/...` | User destination | server → one user | Private push (the message, status, typing, edit/delete, notification) |
| `/topic/...` | Broker | server → many | Broadcast (presence) |

Concretely, the server-side queues this feature pushes to (all via
`convertAndSendToUser`, so the client subscribes with a leading `/user`):

- `/queue/messages` — new message delivery (`ChatService`).
- `/queue/status` — delivery/read status updates back to the sender (`MessageStatusService`).
- `/queue/typing` — typing indicators (`TypingService`).
- `/queue/message-deleted` — delete-for-everyone events (`MessageActionService`).
- `/queue/message-edited` — edit events (`MessageActionService`).
- `/queue/notifications` — message/group/reaction notifications (`NotificationService`).
- `/topic/presence` — presence (online/offline + lastSeen) (`PresenceService`), still
  delivered per-user with `convertAndSendToUser` so blocked viewers can be filtered out.

### 3.4 `SimpMessagingTemplate.convertAndSendToUser`

Every push goes through this helper (Jackson serializes the DTO to JSON):

```java
private void sendTo(Long userId, ChatMessageResponse response) {
    messagingTemplate.convertAndSendToUser(userId.toString(), USER_QUEUE, response);
    // USER_QUEUE = "/queue/messages"
}
```

The first arg is the **user name** = the Principal name = the stringified id set at
handshake. If the user has no active session, the message is silently dropped (the simple
broker does not persist). That is exactly why durable delivery state lives in the
database (`MessageRecipientStatus`), not in the broker — see §6.

---

## 4. Data model

All entities live in `com.mohan.pulse.message` and use Lombok `@Getter/@Setter` plus
JPA/Hibernate annotations. IDs are DB identity columns.

### 4.1 `Message`

The core row. One per sent message (DM or group).

```java
@Entity
@Table(name = "messages",
        indexes = @Index(name = "idx_convo_time", columnList = "conversation_id, created_at"))
public class Message {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;

    @Column(name = "conversation_id", nullable = false) private String conversationId;

    @Enumerated(EnumType.STRING) @Column(nullable = false) private ConversationType conversationType;

    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "sender_id", nullable = false) private User sender;

    @Enumerated(EnumType.STRING) @Column(nullable = false) private MessageType type;

    @Column(columnDefinition = "text") private String content;
    private String mediaUrl;

    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "reply_to_id") private Message replyTo;

    private boolean edited;
    private boolean deleted;

    @Column(name = "reply_to_status_id") private Long replyToStatusId;

    @CreationTimestamp @Column(nullable = false, updatable = false) private Instant createdAt;
    @UpdateTimestamp private Instant updatedAt;
}
```

Annotation rationale:

- **`@Index(columnList = "conversation_id, created_at")`** — the history query always
  filters by conversation and orders by time; this composite index makes paging cheap.
- **`conversationId` is a `String`**, not a FK. It is a synthetic key built by
  `ConversationUtil` (§5): `dm:<smaller>:<larger>` or `group:<groupId>`. There is no
  "Conversation" table — conversations are implicit.
- **`conversationType` and `type` are `EnumType.STRING`** — stored as readable text
  (`DIRECT`/`GROUP`, `TEXT`/`IMAGE`/...), resilient to enum reordering.
- **`sender`, `replyTo` are `FetchType.LAZY`** — avoids loading the whole graph for every
  message; the services touch `getSender().getId()`/`getName()` deliberately.
- **`replyTo` self-reference** — a message can quote another *message*. `replyToStatusId`
  is a separate plain `Long` for the case where a DM is a reply to a *Status* (story),
  which lives in another module; it's an id, not a managed relation.
- **`content columnDefinition = "text"`** — long messages allowed. On
  delete-for-everyone, `content` and `mediaUrl` are nulled and `deleted=true` is set
  (tombstone, the row stays so reply previews can show "deleted").
- **`@CreationTimestamp` / `@UpdateTimestamp`** — Hibernate fills these; `createdAt` is
  `updatable=false` and is the basis for all time-window and block-visibility logic.

### 4.2 `MessageRecipientStatus`

The per-recipient delivery ledger. **This is the durable source of truth for ticks**, and
for whether a recipient is even allowed to see a received message (block handling).

```java
@Entity
@Table(name = "message_recipient_status",
        uniqueConstraints = @UniqueConstraint(columnNames = {"message_id", "user_id"}),
        indexes = {
                @Index(name = "idx_mrs_message", columnList = "message_id"),
                @Index(name = "idx_mrs_recipient_status", columnList = "user_id, status")
        })
public class MessageRecipientStatus {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "message_id", nullable = false) private Message message;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "user_id", nullable = false) private User recipient;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private MessageStatus status; // SENT/DELIVERED/READ
    private Instant deliveredAt;
    private Instant readAt;
    @UpdateTimestamp private Instant updatedAt;
}
```

- **One row per (message, recipient)**, enforced by the unique constraint. The sender
  never gets a row — the sender doesn't "receive" their own message.
- **`idx_mrs_recipient_status (user_id, status)`** — supports "all my SENT rows" queries
  used by the delivered-ack path and unread counts.
- The row's existence has a second meaning beyond ticks: **a recipient row exists only if
  the recipient was a deliverable target at send time** (not blocked). History rendering
  uses this (`findDeliveredMessageIds`) to decide whether a received message is visible.

### 4.3 `DeletedMessage` — delete-for-me

```java
@Entity
@Table(name = "deleted_messages",
        uniqueConstraints = @UniqueConstraint(columnNames = {"message_id", "user_id"}))
public class DeletedMessage {
    @Id ... private Long id;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "message_id", nullable = false) private Message message;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "user_id", nullable = false) private User user;
    @CreationTimestamp private Instant deletedAt;
}
```

A "hide this message from *this one user*" marker. The message row is untouched and other
participants still see it. Unique on `(message, user)` so re-deleting is idempotent.

### 4.4 `ClearedConversation` — clear-chat / hidden conversations

```java
@Entity
@Table(name = "cleared_conversations",
        uniqueConstraints = @UniqueConstraint(name = "uq_user_conversation",
                columnNames = {"user_id", "conversation_id"}))
public class ClearedConversation {
    @Id ... private Long id;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "user_id", nullable = false) private User user;
    @Column(name = "conversation_id", nullable = false) private String conversationId;
    @Column(name = "cleared_at", nullable = false) private Instant clearedAt;
}
```

A per-user "I cleared this conversation at time T" watermark. Messages with
`createdAt <= clearedAt` are hidden *from that user only*. One row per (user,
conversation); clearing again just updates `clearedAt`. A conversation counts as "hidden"
in the chat list only while no message exists newer than `clearedAt`.

### 4.5 Enums

```java
public enum MessageStatus { SENT, DELIVERED, READ }   // ordered: SENT < DELIVERED < READ
public enum MessageType   { TEXT, IMAGE, AUDIO, VIDEO, FILE }
public enum ConversationType { DIRECT, GROUP }
```

`MessageStatus` is the per-recipient lifecycle and the aggregate the sender sees.

### 4.6 Supporting entity: `GroupMember` (from the group module)

Relevant fields for chat: it has `user`, `group`, `role`, and crucially
`@CreationTimestamp private Instant joinedAt;`. **`joinedAt` is the linchpin of group
history visibility** — a viewer only sees group messages sent on/after they joined (§7.3).

---

## 5. `ConversationUtil` — conversation id algebra

There is no Conversation table; ids are computed deterministically:

```java
public static String dmConversationId(Long a, Long b) {
    long smaller = Math.min(a, b);
    long larger  = Math.max(a, b);
    return "dm:" + smaller + ":" + larger;       // order-independent → one id per pair
}
public static String groupConversationId(Long groupId) { return "group:" + groupId; }

public static boolean isGroup(String id)  { return id != null && id.startsWith("group:"); }
public static boolean isDirect(String id) { return id != null && id.startsWith("dm:"); }
public static Long groupIdFrom(String id) { return Long.valueOf(id.substring("group:".length())); }
public static long[] dmParticipants(String id) {
    String[] parts = id.split(":");
    return new long[] { Long.parseLong(parts[1]), Long.parseLong(parts[2]) };
}
```

Because the DM id sorts the two ids, both directions of a DM map to **one** conversation
id. The participants are recoverable from the id alone — used heavily by edit/delete
broadcast and typing relay to find the other side without a DB lookup.

---

## 6. Repositories (with the `@Query`s)

### `MessageRepository`

```java
List<Message> findByConversationIdOrderByCreatedAtDesc(String conversationId, Pageable pageable);
List<Message> findByConversationIdAndIdLessThanOrderByCreatedAtDesc(String conversationId, Long beforeId, Pageable pageable);

@Query("SELECT DISTINCT m.conversationId FROM Message m " +
       "WHERE m.sender.id = :userId AND m.conversationType = com.mohan.pulse.message.ConversationType.DIRECT")
List<String> findDirectConversationIdsBySender(@Param("userId") Long userId);

@Query("SELECT m.conversationId, MAX(m.createdAt) FROM Message m " +
       "WHERE m.conversationId IN :conversationIds GROUP BY m.conversationId")
List<Object[]> findLastMessageTimes(@Param("conversationIds") Collection<String> conversationIds);
```

- The two `findByConversationId...Desc` methods are the paging engine: newest-first,
  optionally `id < before` for scroll-up. `IdLessThan` (not `createdAt <`) gives a stable
  cursor.
- `findDirectConversationIdsBySender` finds DMs *I sent into*; combined with the recipient
  side (next repo) to enumerate my partners.
- `findLastMessageTimes` powers conversation summaries and the hidden-conversation check.

### `MessageRecipientStatusRepository`

```java
List<MessageRecipientStatus> findByMessage_Id(Long messageId);
List<MessageRecipientStatus> findByMessage_IdIn(List<Long> messageIds);
List<MessageRecipientStatus> findByRecipient_IdAndStatus(Long recipientId, MessageStatus status);
List<MessageRecipientStatus> findByRecipient_IdAndMessage_ConversationIdAndStatus(Long recipientId, String conversationId, MessageStatus status);
List<MessageRecipientStatus> findByRecipient_IdAndMessage_ConversationIdAndStatusNot(Long recipientId, String conversationId, MessageStatus status);

@Query("""
    SELECT mrs.message.conversationId, COUNT(mrs)
    FROM MessageRecipientStatus mrs
    WHERE mrs.recipient.id = :userId
      AND mrs.status <> com.mohan.pulse.message.MessageStatus.READ
    GROUP BY mrs.message.conversationId
    """)
List<Object[]> countUnreadPerConversation(@Param("userId") Long userId);

@Query("""
    SELECT DISTINCT mrs.message.conversationId
    FROM MessageRecipientStatus mrs
    WHERE mrs.recipient.id = :userId
      AND mrs.message.conversationType = com.mohan.pulse.message.ConversationType.DIRECT
    """)
List<String> findDirectConversationIdsForRecipient(@Param("userId") Long userId);

@Query("""
    SELECT mrs.message.id
    FROM MessageRecipientStatus mrs
    WHERE mrs.recipient.id = :recipientId
      AND mrs.message.id IN :messageIds
    """)
List<Long> findDeliveredMessageIds(@Param("recipientId") Long recipientId,
                                   @Param("messageIds") List<Long> messageIds);
```

- `findByRecipient_IdAndStatus(.., SENT)` / `...AndMessage_ConversationIdAndStatus(.., SENT)`
  → the "promote SENT→DELIVERED" path.
- `...AndStatusNot(.., READ)` → the "promote everything not-yet-read to READ" path.
- `countUnreadPerConversation` → unread badges (anything not READ counts).
- `findDirectConversationIdsForRecipient` → DMs *I received into* (the recipient side of
  partner enumeration).
- **`findDeliveredMessageIds`** — note the *name is misleading*: it returns message ids
  that simply **have a status row for me**, regardless of SENT/DELIVERED/READ. Its real
  job in history rendering is "does a recipient row exist for me on this message?" =
  "was I a deliverable, non-blocked recipient when it was sent?" This is the block-visibility
  gate (§7.3).

### Other repositories

```java
// DeletedMessageRepository
boolean existsByMessage_IdAndUser_Id(Long messageId, Long userId);
List<DeletedMessage> findByUser_IdAndMessage_IdIn(Long userId, List<Long> messageIds);

// ClearedConversationRepository
Optional<ClearedConversation> findByUser_IdAndConversationId(Long userId, String conversationId);
List<ClearedConversation> findByUser_Id(Long userId);

// GroupMemberRepository (group module)
List<GroupMember> findByGroupId(Long groupId);
List<GroupMember> findByUserId(Long userId);
Optional<GroupMember> findByGroupIdAndUserId(Long groupId, Long userId);   // → joinedAt
boolean existsByGroupIdAndUserId(Long groupId, Long userId);

// BlockRepository — symmetric block check used everywhere
@Query("""
    SELECT COUNT(b) > 0 FROM Block b
    WHERE (b.blocker.id = :firstUserId AND b.blocked.id = :secondUserId)
       OR (b.blocker.id = :secondUserId AND b.blocked.id = :firstUserId)
    """)
boolean existsBlockBetween(@Param("firstUserId") Long a, @Param("secondUserId") Long b);
```

`existsBlockBetween` is symmetric: it's true if *either* user blocked the other. This is
the foundation of "block hides messaging in both directions" used across `ChatService`,
`TypingService`, `ConversationService`, and `PresenceService`.

---

## 7. Flows, step by step

### 7.1 Send a direct message — `ChatService.sendDirectMessage`

Entry: client SENDs to `/app/chat.send` → `ChatController.sendMessage`:

```java
@MessageMapping("/chat.send")
public void sendMessage(SendMessageRequest request, Principal principal) {
    Long senderId = Long.valueOf(principal.getName());
    chatService.sendDirectMessage(senderId, request);
}
```

`sendDirectMessage` (entire method, `@Transactional`):

```java
if (request.getReceiverId() == null) throw BAD_REQUEST "Receiver id is required";
validateContent(request.getMessageType(), request.getContent(), request.getMediaUrl());

User sender   = findUser(senderId, "Sender not found");
User receiver = findUser(request.getReceiverId(), "Receiver not found");

if (sender.getId().equals(receiver.getId())) throw BAD_REQUEST "You cannot message yourself";

String conversationId = ConversationUtil.dmConversationId(sender.getId(), receiver.getId());

Message message = new Message();
message.setConversationId(conversationId);
message.setConversationType(ConversationType.DIRECT);
message.setSender(sender);
message.setType(parseMessageType(request.getMessageType()));
message.setContent(request.getContent());
message.setMediaUrl(request.getMediaUrl());
message.setReplyTo(resolveReplyTo(request.getReplyToId(), conversationId));
if (request.getReplyToStatusId() != null) message.setReplyToStatusId(request.getReplyToStatusId());

Message saved = messageRepository.save(message);

boolean blocked = blockService.isBlockedBetween(sender.getId(), receiver.getId());
if (!blocked) {
    messageStatusService.createRecipientStatuses(saved, List.of(receiver.getId()));
}

StatusPreviewDto statusPreview = buildStatusPreview(request.getReplyToStatusId());
MessageStatus status = messageStatusService.currentStatus(saved.getId());
ChatMessageResponse response =
        toResponse(saved, sender.getId(), conversationId, statusPreview, status.name());

if (!blocked) {
    sendTo(receiver.getId(), response);
    String notificationName = notificationNameFor(receiver.getId(), sender);
    notificationService.sendNotification(
            receiver.getId(), conversationId, notificationName, request.getContent());
}

sendTo(sender.getId(), response);
return response;
```

Key behaviors:

1. **Validation** — `validateContent`: TEXT (or null type) requires non-blank `content`;
   any other type requires non-blank `mediaUrl`. `parseMessageType` falls back to `TEXT`
   on unknown values rather than throwing.
2. **Reply integrity** — `resolveReplyTo` ensures the quoted message exists *and is in the
   same conversation*.
3. **Block handling (asymmetric persistence, no error)** — the message is **always saved**.
   But if `isBlockedBetween(sender, receiver)`:
   - **no** `MessageRecipientStatus` row is created (so the receiver gets no tick state and
     the row-existence gate later hides it),
   - **no** push to the receiver, **no** notification.
   The block is *silent* to the sender: they still get the message echoed to their own UI
   (`sendTo(sender...)` runs unconditionally). The receiver simply never learns of it. If
   they later unblock, the message stays hidden because no recipient row was ever created.
4. **Self-echo** — the sender always gets the same `ChatMessageResponse` on
   `/user/queue/messages`, so all their devices stay in sync and the message appears
   immediately.
5. **Initial status** — `currentStatus(saved.getId())` aggregates the rows just created. If
   the receiver was online when `createRecipientStatuses` ran, their row is already
   `DELIVERED`, so the sender's echo can show two ticks instantly (see §7.4).
6. **Notification title** — `notificationNameFor(receiver, sender)`: if the receiver has the
   sender saved as a contact, use the sender's *name*; otherwise the sender's *phone*.

### 7.2 Send a group message — `ChatService.sendGroupMessage`

Entry: `/app/group.send` → `ChatController.sendGroupMessage`. The service (`@Transactional`):

```java
if (request.getGroupId() == null) throw BAD_REQUEST "Group id is required";
validateContent(...);
User sender = findUser(senderId, "Sender not found");

if (!groupMemberRepository.existsByGroupIdAndUserId(request.getGroupId(), senderId))
    throw FORBIDDEN "You are not a member of this group.";

String conversationId = ConversationUtil.groupConversationId(request.getGroupId());
// build + save Message (ConversationType.GROUP) ...
Message saved = messageRepository.save(message);

List<GroupMember> members = groupMemberRepository.findByGroupId(request.getGroupId());
List<Long> recipientIds = deliverableRecipientIds(members, senderId);   // see below

messageStatusService.createRecipientStatuses(saved, recipientIds);

MessageStatus status = messageStatusService.currentStatus(saved.getId());
ChatMessageResponse response = toResponse(saved, sender.getId(), conversationId, null, status.name());

String groupName = members.get(0).getGroup().getName();
for (Long recipientId : recipientIds) {
    sendTo(recipientId, response);
    String senderLabel = notificationNameFor(recipientId, sender);
    notificationService.sendGroupNotification(
            recipientId, conversationId, groupName, senderLabel, request.getContent());
}

sendTo(sender.getId(), response);
return response;
```

The single most important helper is `deliverableRecipientIds`, and it is used for **all
three** of: status-row creation, realtime delivery, and notifications:

```java
private List<Long> deliverableRecipientIds(List<GroupMember> members, Long senderId) {
    List<Long> recipientIds = new ArrayList<>();
    for (GroupMember member : members) {
        Long memberId = member.getUser().getId();
        if (memberId.equals(senderId)) continue;                          // exclude sender
        if (blockService.isBlockedBetween(senderId, memberId)) continue;  // symmetric block
        recipientIds.add(memberId);
    }
    return recipientIds;
}
```

Consequences (defend these in review):

- The sender is **excluded from recipients** (they get only the self-echo), so they are
  never counted in `totalRecipients` and never get a status row.
- **Symmetric group block**: if A blocked B *or* B blocked A, then when A posts to the
  group, B is excluded from delivery, status rows, *and* notifications — and vice-versa.
  Because no status row is created for B, B will not see A's during-block messages in
  history even after an unblock (§7.3 group rule).
- **Group notifications** are per-recipient and carry a per-recipient sender label:
  `sendGroupNotification(recipientId, conversationId, groupName, senderLabel, content)`.
  The title is the *group name*; the preview is `"<senderLabel>: <preview>"`, where
  `senderLabel` is again contact-name-or-phone *from that recipient's perspective*
  (`notificationNameFor(recipientId, sender)`).

`toResponse` (shared by both DM and group) builds the `ChatMessageResponse`: presigns the
media URL via `StorageService`, flattens the reply via `ReplySummary.from(...)` (which
truncates previews to 80 chars and emits `null` content / `replyToDeleted=true` for
tombstoned originals), and carries `edited`/`deleted`/`statusPreview`.

### 7.3 Loading history — `ConversationService`

Two REST entry points, both end in the same `fetchPage` → `toResponses` pipeline:

```java
public PagedMessages getDirectConversation(Long me, Long other, Long beforeId, int limit) {
    String conversationId = ConversationUtil.dmConversationId(me, other);
    Instant clearedAt = clearedAtFor(me, conversationId);
    return fetchPage(conversationId, beforeId, limit, me, clearedAt);
}
public PagedMessages getGroupConversation(Long me, Long groupId, Long beforeId, int limit) {
    if (!groupMemberRepository.existsByGroupIdAndUserId(groupId, me))
        throw FORBIDDEN "You are not a member of this group.";
    String conversationId = ConversationUtil.groupConversationId(groupId);
    Instant clearedAt = clearedAtFor(me, conversationId);
    return fetchPage(conversationId, beforeId, limit, me, clearedAt);
}
```

**Paging** (`fetchPage`): page size = `limit` (default 30). First page (no `before`) uses
`findByConversationIdOrderByCreatedAtDesc`; scroll-up uses
`findByConversationIdAndIdLessThanOrderByCreatedAtDesc(.., beforeId, ..)`. `hasMore =
(newestFirst.size() == limit)`. The newest-first page is reversed to oldest-first before
DTO conversion (UI renders top→bottom).

**Filtering** is the interesting part. `toResponses` batches lookups then walks each
message applying three independent skip rules:

```java
Set<Long> hiddenMessageIds = hiddenMessageIdsFor(currentUserId, messageIds);   // delete-for-me
boolean directConversation = ConversationUtil.isDirect(conversationId);
Set<Long> deliveredToMe = new HashSet<>(
        recipientStatusRepository.findDeliveredMessageIds(currentUserId, messageIds)); // row exists?
Instant joinedGroupAt = joinTimeFor(conversationId, currentUserId);            // GroupMember.joinedAt
...
for (Message message : messages) {
    if (clearedForMe(message, clearedAt)) continue;
    if (hiddenMessageIds.contains(message.getId())) continue;
    if (hiddenByBlock(message, currentUserId, directConversation, deliveredToMe, joinedGroupAt)) continue;
    ... add response ...
}
```

Rule 1 — **cleared chat**: `clearedForMe` = `clearedAt != null && !createdAt.isAfter(clearedAt)`,
i.e. anything at or before my clear watermark is hidden from me only.

Rule 2 — **delete-for-me**: `hiddenMessageIdsFor` loads my `DeletedMessage` rows for this
page and skips those message ids.

Rule 3 — **block visibility** (`hiddenByBlock`), the rule that recently changed and is the
crux of the doc:

```java
private boolean hiddenByBlock(Message message, Long viewerId, boolean directConversation,
                              Set<Long> deliveredMessageIds, Instant viewerJoinedGroupAt) {
    boolean ownMessage       = message.getSender().getId().equals(viewerId);
    boolean deliveredToViewer = deliveredMessageIds.contains(message.getId());
    if (ownMessage || deliveredToViewer) return false;   // never hide my own, or any I have a row for
    if (directConversation) return true;                 // received DM with no row → hide
    return wasMemberWhenSent(message, viewerJoinedGroupAt);
}
private boolean wasMemberWhenSent(Message message, Instant viewerJoinedGroupAt) {
    return viewerJoinedGroupAt != null && !message.getCreatedAt().isBefore(viewerJoinedGroupAt);
}
```

Read this carefully:

- **My own messages** are always shown (I always sent them, even while blocked).
- **Any message I have a recipient-status row for** is always shown (the row was created
  at send time → I was a legitimate, non-blocked recipient). This is the meaning of
  `findDeliveredMessageIds`.
- **Direct conversation, received, no row** → **hide.** A received DM is only visible if a
  status row exists. During-block DMs (which created no row) are hidden, and stay hidden
  after unblock because the row is never back-filled.
- **Group, received, no row** → hide **only if** `wasMemberWhenSent`, i.e. the message was
  sent on/after `viewerJoinedGroupAt`. The reasoning:
  - If I had **no row** *and* the message was sent **while I was a member** → it was
    suppressed by a block at the time → hide it (and keep it hidden after unblock).
  - If I had no row but the message predates my join (`createdAt < joinedAt`) →
    `wasMemberWhenSent` is false → **show** it. This deliberately keeps **pre-join group
    history visible** even though no status row was ever created for me on those messages.

  Net effect: during-block group messages never reappear after unblock, while normal
  pre-join history is preserved. (`joinTimeFor` returns null for DMs and for non-members;
  for groups it reads `GroupMember.joinedAt` via `findByGroupIdAndUserId`.)

For surviving messages, `buildMessageResponse` attaches the aggregated status
(`statusForMessages`), reactions (`reactionService.reactionsForMessages`), reply summary,
status-reply preview, and `edited`/`deleted` flags. Aggregate counts (`deliveredCount`,
`readCount`, `totalRecipients`) come straight from the recipient-status rows.

### 7.4 Delivery & read status — `MessageStatusService`

This service owns ticks. There are no separate SENT/DELIVERED/READ rows per state — each
recipient has **one** row whose `status` advances `SENT → DELIVERED → READ`.

**Row creation at send time** (`createRecipientStatuses`): for each recipient, if
`presenceService.isOnline(recipientId)` the row starts as `DELIVERED` with `deliveredAt =
now`; otherwise `SENT`. So an online recipient is "delivered" the instant the message is
sent, before any client ack:

```java
boolean recipientOnline = presenceService.isOnline(recipientId);
if (recipientOnline) { row.setStatus(MessageStatus.DELIVERED); row.setDeliveredAt(now); }
else                 { row.setStatus(MessageStatus.SENT); }
```

**Aggregation** (`aggregate`) — how the sender's single tick state is derived from N rows:

```java
if (total == 0) return SENT;          // no recipients (e.g. blocked DM) → stays SENT
if (read == total) return READ;       // everyone read → double blue
if (delivered == total) return DELIVERED;  // everyone (at least) delivered → double grey
return SENT;                          // otherwise single tick
```

`delivered` counts rows whose status is DELIVERED *or* READ (`countAtLeastDelivered`);
`read` counts only READ. So a group goes READ only when *every* recipient read it.

**Delivered ack** — client SENDs `/app/chat.delivered` with `{conversationId}`:

```java
@MessageMapping("/chat.delivered")
public void markDelivered(ConversationAckRequest req, Principal p) {
    messageStatusService.markDelivered(Long.valueOf(p.getName()), req.getConversationId());
}
```

`markDelivered` promotes the caller's `SENT` rows to `DELIVERED` (scoped to the
conversation if provided, else all of mine), stamps `deliveredAt`, saves, then
`notifySenders`. (Online recipients are usually already DELIVERED from send time, so this
mainly catches recipients who were offline at send and have now connected.)

**Read ack** — client SENDs `/app/chat.read`:

```java
@MessageMapping("/chat.read")
public void markRead(ConversationAckRequest req, Principal p) {
    Long recipientId = Long.valueOf(p.getName());
    messageStatusService.markRead(recipientId, req.getConversationId());
    notificationService.clearUnread(recipientId, req.getConversationId());
}
```

`markRead` requires a `conversationId` (returns early if null). It loads the caller's rows
in that conversation whose status `<> READ`, sets `readAt = now` (and back-fills
`deliveredAt` if it was never set, so a message read while offline-then-online still shows
a delivered time), advances to `READ`, saves, then `notifySenders`. It also clears the
in-memory unread counter for that conversation.

**Pushing ticks back to senders** (`notifySenders`): for every message touched, it reloads
*all* rows of that message, re-aggregates, and pushes a `MessageStatusUpdate`
(messageId, conversationId, aggregated status, delivered/read/total counts) to the
**message's sender** on `/user/queue/status`. This is how the sender's grey/blue ticks
update live.

**Message info screen** (`getMessageInfo`, REST `GET /api/messages/{id}/status`): only the
*sender* may call it (else 403). Returns per-recipient `RecipientStatusEntry` rows
(recipient id/name/avatar, status, deliveredAt, readAt) plus totals — the "info" panel
showing exactly who has read in a group.

### 7.5 Typing — `TypingService` (symmetric block aware)

Entry `/app/chat.typing` → `handleTyping(senderId, conversationId, typing)`. No DB write,
pure relay. DM path:

```java
long recipientId = (senderId == firstUserId) ? secondUserId : firstUserId;
boolean blocked = blockService.isBlockedBetween(senderId, recipientId);
if (blocked) return;                 // never leak typing across a block (either direction)
send(recipientId, new TypingEvent(conversationId, senderId, typing));
```

Group path: verify the sender is a member, then loop members, pushing a `TypingEvent` to
each member who is **not** the sender and **not** blocked-with the sender
(`!isSender && !blocked`). Events go to `/user/queue/typing`. So typing is suppressed in
both directions of any block, mirroring §7.1/§7.2.

### 7.6 Edit / delete — `MessageActionService` (REST → WebSocket)

These are REST endpoints under `/api/messages` that mutate the DB then **broadcast** the
result over STOMP.

**Edit** (`PUT /api/messages/{id}`, `editMessage`, window = 30 min):
guards in order — sender must be caller (else 403); not already deleted; type must be
`TEXT` (`Only text messages can be edited`); new content non-blank; not older than
`EDIT_WINDOW` (`Duration.ofMinutes(30)`). Then `content = trim`, `edited = true`, save,
and `broadcastEdited` pushes a `MessageEditedEvent(id, conversationId, content)` to every
participant on `/user/queue/message-edited`.

**Delete for everyone** (`DELETE /api/messages/{id}/for-everyone`, window = 1 hour):
sender must be caller (else 403); idempotent if already deleted; not older than
`DELETE_FOR_EVERYONE_WINDOW` (`Duration.ofHours(1)`). Then tombstone the message:
`deleted = true`, `content = null`, `mediaUrl = null`, save, and `broadcastDeleted` pushes
`MessageDeletedEvent(id, conversationId)` to all participants on
`/user/queue/message-deleted`. The row survives so reply previews can render "deleted".

**Delete for me** (`DELETE /api/messages/{id}/for-me`): `ensureMember` (DM participant or
group member, else 403), then insert a `DeletedMessage(message, user)` (idempotent). No
broadcast — purely local hiding handled later by history filtering (§7.3 Rule 2).

`recipientsOf(conversationId)` builds the broadcast audience: for a DM, both
`dmParticipants`; for a group, every `GroupMember`. (Note: edit/delete broadcasts are *not*
block-filtered — they target participants generically, unlike send/typing.)

### 7.7 Conversation list helpers — `ConversationService`

- **`getUnreadCounts`** → `Map<conversationId, count>` from `countUnreadPerConversation`
  (rows where status `<> READ`). Drives unread badges.
- **`getPartners`** → enumerates my DM conversation ids from both the sender side
  (`findDirectConversationIdsBySender`) and recipient side
  (`findDirectConversationIdsForRecipient`), derives the other participant from each id,
  then **removes any partner I'm blocked with** (`removeIf(isBlockedBetween)`), and returns
  `ConversationPartner(id, name, phone, presigned avatar, lastSeen)`. Blocked partners
  disappear from the partner list.
- **`getConversationSummaries`** → `Map<conversationId, lastMessageInstant>` across my DMs
  *and* my groups (`findByUserId`), via `findLastMessageTimes`. Used to sort/preview the
  chat list.
- **`getHiddenConversations`** → conversation ids I cleared that have **no** message newer
  than my `clearedAt` (so they stay hidden until someone sends a new message).
- **`clearDirectConversation` / `clearGroupConversation`** → upsert a `ClearedConversation`
  row with `clearedAt = now` (DELETE `/api/conversations/{otherUserId}` or
  `/api/conversations/group/{groupId}`). This is a *per-user* clear, not a real delete.

---

## 8. Libraries & mechanisms (WHAT / WHY / HOW)

**Spring WebSocket + STOMP (`@EnableWebSocketMessageBroker`)**
- *What*: Spring's messaging stack — a SockJS WebSocket endpoint, a STOMP sub-protocol
  layer, and a message broker.
- *Why*: Pure REST can't push. STOMP gives named destinations and subscriptions so the
  server can deliver to "this user" or "everyone".
- *How here*: `WebSocketConfig` registers `/ws`, an **in-memory simple broker** for
  `/topic`+`/queue`, app prefix `/app` (→ `@MessageMapping`), and user prefix `/user`.
  Inbound `/app/...` frames hit `ChatController` methods; outbound pushes go to
  `/user/queue/...` and `/topic/...`. Single-JVM only (no external broker).

**`@MessageMapping`**
- *What*: the STOMP analogue of `@RequestMapping` — maps an inbound destination to a
  handler method, with the message payload auto-deserialized into the method arg.
- *Why/How*: `ChatController` uses it for the five inbound commands; the `Principal`
  parameter is injected from the socket session (set at handshake), giving the sender id
  with no header parsing.

**`SimpMessagingTemplate` + user destinations**
- *What*: programmatic API to send STOMP messages from any bean.
- *Why*: services need to push outside of a request/response cycle (a *new* message must
  reach a *different* user).
- *How*: `convertAndSendToUser("42", "/queue/messages", dto)` — Spring resolves user "42"
  (the Principal name) to their session-specific queue. Used for messages, status, typing,
  edited, deleted, notifications; `/topic/presence` for broadcast (still per-user so blocks
  can be filtered).

**`HandshakeInterceptor` + `DefaultHandshakeHandler` (the socket Principal)**
- *What/Why/How*: `WebSocketAuthInterceptor` validates the `?token=` at handshake and
  stores `userId` in handshake attributes (rejecting bad/missing tokens by returning
  `false`); `WebSocketHandshakeHandler.determineUser` reads that attribute and returns a
  `Principal` whose `getName()` is the user id. That Principal is the socket's identity for
  every `@MessageMapping` and every `convertAndSendToUser` target.

**`OncePerRequestFilter` for REST identity (`senderId`/`currentUserId`)**
- *What/Why/How*: `JwtAuthFilter` runs exactly once per HTTP request, validates the bearer
  token, and sets a `UsernamePasswordAuthenticationToken` whose principal is the `Long`
  user id. `SecurityUtil.currentUserId()` reads it back. This is the REST counterpart to
  the socket Principal — same identity model, different transport.

**Spring Data JPA / Hibernate**
- *What/Why*: repositories from interfaces (derived queries + `@Query` JPQL); entities map
  to tables; lazy `@ManyToOne` avoids over-fetching.
- *How here*: derived names (`findByConversationIdOrderByCreatedAtDesc`,
  `findByRecipient_IdAndMessage_ConversationIdAndStatusNot`) and explicit JPQL for
  aggregates (`countUnreadPerConversation`, `findLastMessageTimes`, `existsBlockBetween`).
  `EnumType.STRING` keeps enum columns readable; `@CreationTimestamp`/`@UpdateTimestamp`
  auto-stamp times; composite/unique indexes back paging and per-(message,user) uniqueness.

**`@Transactional`**
- *What/Why*: wraps a method in one DB transaction (atomic + a managed persistence
  context, so dirty entities flush without explicit `save`).
- *How here*: every write path is `@Transactional` (`sendDirectMessage`,
  `sendGroupMessage`, `createRecipientStatuses`, `markDelivered`, `markRead`,
  edit/delete, clear). Read aggregations use `@Transactional(readOnly = true)`
  (`currentStatus`, `statusForMessages`, `getMessageInfo`). Note edit/delete fire their
  STOMP broadcast *inside* the transaction — recipients can in principle be notified just
  before commit; acceptable for this in-memory broker.

**Jackson**
- *What/Why/How*: serializes DTOs to JSON for both REST bodies and STOMP payloads, and
  deserializes inbound `@MessageMapping`/`@RequestBody` args. The `@Getter`-only response
  DTOs (`ChatMessageResponse`, `MessageResponse`, ...) serialize their getters; the
  `@Setter`/`@NoArgsConstructor` request DTOs (`SendMessageRequest`, etc.) deserialize via
  setters. Defaults like `messageType = "TEXT"` apply when the field is absent.

---

## 9. Quick reference — REST endpoints

| Method | Path | Controller | Body / params | Returns | Auth/Notes |
|--------|------|-----------|---------------|---------|------------|
| GET | `/api/conversations/{otherUserId}` | ConversationController | `before?`, `limit=30` | `PagedMessages` | DM history, filtered (cleared / delete-for-me / block) |
| GET | `/api/conversations/group/{groupId}` | ConversationController | `before?`, `limit=30` | `PagedMessages` | 403 if not a member; pre-join history shown, during-block hidden |
| GET | `/api/conversations/unread-counts` | ConversationController | — | `Map<convId,int>` | rows not READ |
| GET | `/api/conversations/partners` | ConversationController | — | `List<ConversationPartner>` | excludes blocked partners |
| GET | `/api/conversations/summaries` | ConversationController | — | `Map<convId,Instant>` | last-message times (DMs + groups) |
| GET | `/api/conversations/hidden` | ConversationController | — | `List<String>` | cleared convs with no newer message |
| DELETE | `/api/conversations/{otherUserId}` | ConversationController | — | `Void` | clear DM (per-user watermark) |
| DELETE | `/api/conversations/group/{groupId}` | ConversationController | — | `Void` | clear group (per-user watermark) |
| GET | `/api/messages/{messageId}/status` | MessageStatusController | — | `MessageInfoResponse` | sender-only (403 otherwise) |
| PUT | `/api/messages/{messageId}` | MessageActionController | `EditMessageRequest{content}` | `Void` | sender-only, TEXT only, ≤30 min; broadcasts edit |
| DELETE | `/api/messages/{messageId}/for-everyone` | MessageActionController | — | `Void` | sender-only, ≤1 h; tombstone + broadcast |
| DELETE | `/api/messages/{messageId}/for-me` | MessageActionController | — | `Void` | participant-only; local hide, no broadcast |

(All require a valid `Authorization: Bearer` JWT; user id via `SecurityUtil.currentUserId()`.)

## 10. Quick reference — STOMP destinations

### Inbound — client SEND to `/app/...` (`@MessageMapping` in `ChatController`)

| Destination | Payload DTO | Handler | Effect |
|-------------|-------------|---------|--------|
| `/app/chat.send` | `SendMessageRequest` | `sendMessage` | `ChatService.sendDirectMessage` |
| `/app/group.send` | `SendGroupMessageRequest` | `sendGroupMessage` | `ChatService.sendGroupMessage` |
| `/app/chat.delivered` | `ConversationAckRequest` | `markDelivered` | promote my SENT→DELIVERED, notify senders |
| `/app/chat.read` | `ConversationAckRequest` | `markRead` | promote my rows→READ, notify senders, clear unread |
| `/app/chat.typing` | `TypingRequest` | `typing` | relay typing (block-aware) |

### Outbound — server push (client SUBSCRIBEs with leading `/user` for queues)

| Subscribe destination | Payload DTO | Source | When |
|-----------------------|-------------|--------|------|
| `/user/queue/messages` | `ChatMessageResponse` | `ChatService.sendTo` | new message (to recipients + sender echo) |
| `/user/queue/status` | `MessageStatusUpdate` | `MessageStatusService.notifySenders` | recipient delivered/read → tick update to sender |
| `/user/queue/typing` | `TypingEvent` | `TypingService` | someone is typing |
| `/user/queue/message-edited` | `MessageEditedEvent` | `MessageActionService` | message edited |
| `/user/queue/message-deleted` | `MessageDeletedEvent` | `MessageActionService` | message deleted-for-everyone |
| `/user/queue/notifications` | `NotificationDto` | `NotificationService` | message / group / reaction notification |
| `/topic/presence` | `PresenceUpdate` | `PresenceService` | online/offline + lastSeen (block-filtered) |

---

## 11. Things to be ready to defend

- **Blocked DMs are saved but invisible to the receiver, forever.** No status row → no
  delivery, no notification, hidden in history even after unblock. The sender gets no
  error and still sees their own copy.
- **Group block is symmetric and applied at send time** to delivery, status rows, and
  notifications via the one `deliverableRecipientIds` list. Combined with the
  `wasMemberWhenSent` rule, during-block group messages never reappear after unblock,
  while genuine pre-join history stays visible.
- **`findDeliveredMessageIds` is misnamed** — it tests row existence, which is the
  block-visibility gate, not literal delivery.
- **The simple broker is in-memory / single-JVM.** Pushes to offline users are dropped;
  durability is in `MessageRecipientStatus`. Horizontal scaling needs an external broker.
- **Online-at-send ⇒ DELIVERED immediately** (before any client ack), driven by
  `PresenceService.isOnline`, so ticks can show two grey instantly.
- **Edit/delete broadcasts are not block-filtered** (they target all participants), unlike
  send and typing which are.