# Pulse — Authentication & Security (Backend Flow)

This document explains, end to end, how Pulse authenticates and authorizes
requests. It is written for a developer who has to defend this code in review
and finds Spring Security and JJWT confusing. Every claim below is grounded in
the actual source; real snippets are quoted.

The model in one sentence: **Pulse is stateless. There are no server-side
sessions. A successful signup/login hands the client a signed JWT, and every
subsequent REST request (and the WebSocket handshake) re-proves identity by
presenting that token, which the server verifies cryptographically on each
call.**

---

## 0. The cast of files

| File | Role |
|------|------|
| `auth/AuthController.java` | REST endpoints `/api/auth/signup` and `/api/auth/login` |
| `auth/AuthService.java` | Business logic: duplicate check, hashing, password match, token issue |
| `auth/JwtUtil.java` | JJWT wrapper: builds tokens, verifies signatures, extracts the user id |
| `auth/JwtAuthFilter.java` | Per-request Spring Security filter that reads the `Authorization` header |
| `auth/JwtAuthenticationEntryPoint.java` | Produces the clean `401` JSON for unauthenticated requests |
| `auth/WebSocketAuthInterceptor.java` | Validates the JWT during the WebSocket handshake (token in query string) |
| `auth/WebSocketHandshakeHandler.java` | Attaches a `Principal` (name = userId) to the WebSocket session |
| `config/SecurityConfig.java` | The `SecurityFilterChain`, password encoder, stateless policy, entry point wiring |
| `config/WebSocketConfig.java` | Registers the STOMP endpoint with the interceptor + handshake handler |
| `config/CorsConfig.java` | The `CorsConfigurationSource` that Spring Security consumes |
| `common/SecurityUtil.java` | `currentUserId()` — how the rest of the app reads "who is calling" |
| `user/User.java`, `user/UserRepository.java` | The `passwordHash` column and phone lookups |
| `application.properties` | `app.jwt.secret`, `app.jwt.expiration-ms`, `app.allowed-origins` |

Library versions (from `pom.xml`): JJWT `io.jsonwebtoken:jjwt-api`,
`jjwt-impl`, `jjwt-jackson` all `0.12.6`; Spring Security and Spring WebSocket
come from `spring-boot-starter-security` and `spring-boot-starter-websocket`.

---

## 1. Signup flow

### Entry point

`AuthController` is a thin HTTP adapter. It does no logic; it delegates to
`AuthService` and wraps the result in the app's standard envelope:

```java
@PostMapping("/signup")
public ApiResponse<AuthResponse> signup(@Valid @RequestBody SignupRequest request) {
    AuthResponse result = authService.signup(request);
    return ApiResponse.ok("Account created successfully", result);
}
```

`@Valid` triggers Jakarta Bean Validation **before** the method body runs. The
constraints live on `SignupRequest`:

```java
@NotBlank(message = "Phone number is required")
private String phone;

@NotBlank(message = "Password is required")
@Size(min = 6, message = "Password must be at least 6 characters")
private String password;

@NotBlank(message = "Name is required")
private String name;
```

So a blank phone, a blank/short password, or a blank name is rejected at the
controller boundary (a `400`) and never reaches the service. This is input
*validation*, distinct from *authentication*.

### Business logic (`AuthService.signup`)

```java
public AuthResponse signup(SignupRequest request) {
    boolean phoneAlreadyRegistered = userRepository.existsByPhone(request.getPhone());
    if (phoneAlreadyRegistered) {
        throw new ApiException(HttpStatus.CONFLICT, "Phone number is already registered");
    }

    String hashedPassword = passwordEncoder.encode(request.getPassword());

    User user = new User();
    user.setPhone(request.getPhone());
    user.setPasswordHash(hashedPassword);
    user.setName(request.getName());

    User savedUser = userRepository.save(user);
    return buildAuthResponse(savedUser);
}
```

Step by step:

1. **Duplicate phone check.** `userRepository.existsByPhone(...)` is a derived
   Spring Data query (declared as `boolean existsByPhone(String phone)` in
   `UserRepository`). If the phone is taken, throw `ApiException(CONFLICT, ...)`
   → HTTP `409`. Note this is also defended at the database level: in
   `User.java` the column is `@Column(nullable = false, unique = true)`, so even
   under a race the unique constraint is the final guard.
2. **Hash the password.** `passwordEncoder.encode(...)` is called *immediately*.
   The raw password is never stored, never logged. `passwordEncoder` is the
   `BCryptPasswordEncoder` bean (see §3).
3. **Build and save the entity.** Only `phone`, `passwordHash`, and `name` are
   set. `id` is DB-generated (`@GeneratedValue(strategy = IDENTITY)`),
   `createdAt` is set by Hibernate (`@CreationTimestamp`).
4. **Build the auth response** — this is where the JWT is minted (§1.1).

### 1.1 Building the response (and issuing the token)

```java
private AuthResponse buildAuthResponse(User user) {
    String token = jwtUtil.generateToken(user.getId());
    String avatarUrl = storageService.presignedUrl(user.getAvatarUrl());

    return new AuthResponse(
            token,
            user.getId(),
            user.getPhone(),
            user.getName(),
            avatarUrl);
}
```

`AuthResponse` is an immutable DTO (`@Getter @AllArgsConstructor`, all fields
`final`) carrying `token, userId, phone, name, avatarUrl`. The `token` is the
credential the client must keep and resend; the rest is convenience data so the
UI doesn't need a second round-trip after login.

The key design point for review: **the token is generated from the persisted
user's id only** — `jwtUtil.generateToken(user.getId())`. No password, no PII
goes into the token. The token's job is solely "this caller is user N".

---

## 2. Login flow

```java
public AuthResponse login(LoginRequest request) {
    User user = findUserByPhoneOrThrow(request.getPhone());

    boolean passwordMatches =
            passwordEncoder.matches(request.getPassword(), user.getPasswordHash());
    if (!passwordMatches) {
        throw new ApiException(HttpStatus.UNAUTHORIZED, "Invalid phone or password");
    }

    user.setLastSeen(Instant.now());
    userRepository.save(user);

    return buildAuthResponse(user);
}
```

1. **Lookup.** `findUserByPhoneOrThrow` calls `userRepository.findByPhone(phone)`
   (returns `Optional<User>`). If empty it throws `UNAUTHORIZED` (`401`).
2. **Password check.** `passwordEncoder.matches(rawInput, storedHash)`. This is
   the *inverse-free* verification: BCrypt re-hashes the supplied password with
   the salt embedded in the stored hash and compares. It returns a boolean; it
   never decrypts (BCrypt is one-way — see §3).
3. **Anti-enumeration detail (worth calling out in review).** Both "phone not
   found" and "wrong password" throw the **same** message `"Invalid phone or
   password"` with the **same** status `401`. An attacker cannot tell whether a
   phone number is registered. (In contrast, signup intentionally *does* reveal
   "already registered" — that is a usability trade-off accepted for the signup
   path.)
4. **`lastSeen` update.** On successful login we stamp `user.setLastSeen(Instant.now())`
   and `save`. This is presence bookkeeping, not part of auth.
5. **Token issue.** Same `buildAuthResponse` path as signup — a fresh JWT.

`LoginRequest` is validated by `@Valid` in the controller too (`@NotBlank` phone
and password), so empty bodies are `400`s before the service runs.

---

## 3. Password security (one-way hashing / BCrypt)

### The contract

- Plaintext passwords are **never** persisted. The entity stores only a hash:

  ```java
  @Column(nullable = false)
  private String passwordHash;
  ```

- Writing the hash: `passwordEncoder.encode(...)` (signup).
- Verifying: `passwordEncoder.matches(raw, hash)` (login). There is no `decode`
  — that is the whole point of a one-way function.

### Where the bean comes from

`SecurityConfig` defines exactly one `PasswordEncoder` bean, and it is BCrypt:

```java
@Bean
public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
}
```

`AuthService` receives this via constructor injection (its field is typed as the
interface `PasswordEncoder`, decoupling it from the concrete algorithm).

### Why BCrypt specifically

- **Salted automatically.** Each `encode` generates a random salt and stores it
  *inside* the output string (the `$2a$10$...` format), so identical passwords
  produce different hashes and rainbow tables are useless. `matches` reads that
  salt back out — which is why verification needs no separate salt column.
- **Deliberately slow / adaptive.** BCrypt has a work factor (default cost 10
  for `new BCryptPasswordEncoder()`). It is tuned to be expensive, throttling
  brute-force. The cost is embedded in the hash, so it can be raised later
  without breaking existing hashes.
- **`PasswordEncoder` interface** is Spring Security's abstraction. Because
  `AuthService` depends on the interface, swapping to e.g. an Argon2 or
  delegating encoder is a one-line change in `SecurityConfig`.

---

## 4. JWT in depth (`JwtUtil` + JJWT)

### 4.1 What a JWT actually is

A JWT (JSON Web Token) is a compact, **self-contained, signed** string with
three Base64URL parts separated by dots:

```
header . payload . signature
```

- **Header** — JSON describing the token, e.g. `{"alg":"HS256"}`. JJWT writes
  this automatically based on the key/algorithm you sign with.
- **Payload (claims)** — JSON of statements. Here the meaningful claims are
  `sub` (subject = the user id), `iat` (issued-at), and `exp` (expiration).
- **Signature** — an HMAC-SHA over `base64(header) + "." + base64(payload)`
  using a server-only secret key. Anyone can *read* the payload (it is not
  encrypted, only encoded), but **no one can forge or tamper** with it without
  the secret, because changing the payload invalidates the signature.

"Self-contained" is why Pulse can be stateless: the server doesn't look anything
up to know who you are — the verified token *is* the identity assertion.

### 4.2 JJWT — what / why / how

- **What:** `io.jsonwebtoken` (JJWT) is a Java library for creating and parsing
  JWTs. Pulse uses three artifacts (v `0.12.6`): `jjwt-api` (the interfaces you
  compile against), `jjwt-impl` (runtime implementation), and `jjwt-jackson`
  (runtime JSON (de)serialization via Jackson). The impl/jackson jars are
  `runtime` scope on purpose — code only references the `-api` types.
- **Why:** it gives a fluent, type-safe builder/parser and handles the fiddly,
  security-critical bits (canonical JSON, Base64URL, constant-time signature
  comparison, `exp` checking) so we don't hand-roll crypto.
- **How:** two fluent entry points — `Jwts.builder()` to create,
  `Jwts.parser()` to verify — both used in `JwtUtil`.

### 4.3 The signing key and config injection

```java
public JwtUtil(
        @Value("${app.jwt.secret}") String secret,
        @Value("${app.jwt.expiration-ms}") long expirationMillis) {

    byte[] secretBytes = secret.getBytes(StandardCharsets.UTF_8);
    this.signingKey = Keys.hmacShaKeyFor(secretBytes);
    this.expirationMillis = expirationMillis;
}
```

- **`@Value` injection.** Spring resolves `${app.jwt.secret}` and
  `${app.jwt.expiration-ms}` from `application.properties` at construction time:

  ```properties
  app.jwt.secret=this-is-my-pulse-secret-key-1234567890
  app.jwt.expiration-ms=86400000
  ```

  `86400000` ms = 24 hours token lifetime. (`@Value` resolves the property
  placeholder; the second value is bound straight to a `long`.)
- **`Keys.hmacShaKeyFor(secretBytes)`** builds a `javax.crypto.SecretKey` from
  the raw secret bytes. JJWT inspects the key length and picks the HMAC-SHA
  variant (HS256/384/512). The secret here is `38` ASCII bytes = `304` bits,
  comfortably above the `256`-bit (`32`-byte) minimum HS256 requires, so JJWT
  accepts it. The same `signingKey` is used to **sign** (build) and **verify**
  (parse) — that's symmetric HMAC.

  > Review note: the secret is hard-coded in `application.properties`. It is a
  > shared symmetric key; anyone who has it can mint valid tokens. For
  > production this should be externalized to an env var / secret manager. (The
  > DB password and MinIO endpoint already use `${...}` env placeholders; the
  > JWT secret currently does not.)

### 4.4 Generating a token

```java
public String generateToken(Long userId) {
    Date issuedAt = new Date();

    long expiryTimeInMillis = issuedAt.getTime() + expirationMillis;
    Date expiresAt = new Date(expiryTimeInMillis);

    String subject = String.valueOf(userId);

    return Jwts.builder()
            .subject(subject)
            .issuedAt(issuedAt)
            .expiration(expiresAt)
            .signWith(signingKey)
            .compact();
}
```

- `.subject(subject)` sets the `sub` claim to the stringified user id — the
  identity carried by the token.
- `.issuedAt(...)` / `.expiration(...)` set `iat` / `exp`. `exp` is `now +
  24h`; JJWT will later reject the token automatically once that passes.
- `.signWith(signingKey)` computes the HMAC signature with our secret. JJWT
  also writes the matching `alg` into the header.
- `.compact()` serializes the whole thing to the `header.payload.signature`
  string that gets returned in `AuthResponse.token`.

### 4.5 Verifying and reading a token

All verification funnels through one private method:

```java
private Claims parseClaims(String token) {
    return Jwts.parser()
            .verifyWith(signingKey)
            .build()
            .parseSignedClaims(token)
            .getPayload();
}
```

- `.verifyWith(signingKey)` tells the parser the key to check the signature
  against — the **same** key used to sign.
- `.parseSignedClaims(token)` does the heavy lifting: it splits the token,
  recomputes the HMAC, constant-time-compares it to the supplied signature, and
  validates registered claims including `exp`. If the signature is wrong, the
  token is malformed, or it is expired, JJWT **throws** (e.g.
  `SignatureException`, `MalformedJwtException`, `ExpiredJwtException`).
- `.getPayload()` returns the verified `Claims`.

Two public helpers build on it:

```java
public Long extractUserId(String token) {
    Claims claims = parseClaims(token);
    String subject = claims.getSubject();
    return Long.valueOf(subject);
}

public boolean isValid(String token) {
    try {
        parseClaims(token);
        return true;
    } catch (Exception e) {
        return false;
    }
}
```

- `extractUserId` reads `sub` back and converts to `Long`. It assumes a valid
  token (callers always call `isValid` first).
- `isValid` turns JJWT's *throw-on-failure* model into a *boolean* by catching
  any exception. This is the single chokepoint where "is this token genuine and
  unexpired?" is answered, and it is reused by both the REST filter and the
  WebSocket interceptor.

---

## 5. The per-request filter (`JwtAuthFilter`)

This is where a bare HTTP request becomes an authenticated one.

```java
@Component
public class JwtAuthFilter extends OncePerRequestFilter {
```

### Why `OncePerRequestFilter`

It is the Spring base class guaranteeing `doFilterInternal` runs **exactly once
per request**, even across internal forwards/dispatches. Auth logic must not run
twice, so this is the correct base.

### The body

```java
protected void doFilterInternal(
        HttpServletRequest request,
        HttpServletResponse response,
        FilterChain filterChain) throws ServletException, IOException {

    String token = extractToken(request);

    boolean hasToken = (token != null);
    boolean tokenIsValid = hasToken && jwtUtil.isValid(token);
    boolean notYetAuthenticated =
            SecurityContextHolder.getContext().getAuthentication() == null;

    if (tokenIsValid && notYetAuthenticated) {
        Long userId = jwtUtil.extractUserId(token);
        authenticate(request, userId);
    }

    filterChain.doFilter(request, response);
}
```

### Extracting the Bearer token

```java
private String extractToken(HttpServletRequest request) {
    String header = request.getHeader(AUTH_HEADER);              // "Authorization"

    boolean hasBearerToken = (header != null && header.startsWith(BEARER_PREFIX)); // "Bearer "
    if (!hasBearerToken) {
        return null;
    }

    return header.substring(BEARER_PREFIX.length());
}
```

It reads the `Authorization: Bearer <token>` header and strips the `"Bearer "`
prefix. No header / wrong scheme → `null` → request continues unauthenticated.

### Establishing the authentication

```java
private void authenticate(HttpServletRequest request, Long userId) {
    UsernamePasswordAuthenticationToken authentication =
            new UsernamePasswordAuthenticationToken(userId, null, Collections.emptyList());

    authentication.setDetails(
            new WebAuthenticationDetailsSource().buildDetails(request));

    SecurityContextHolder.getContext().setAuthentication(authentication);
}
```

- `UsernamePasswordAuthenticationToken` is Spring Security's standard
  `Authentication` implementation. The three-arg constructor produces an
  **authenticated** token (it internally sets `authenticated = true`):
  - **principal** = the `userId` (a `Long`). This is deliberate — `SecurityUtil`
    later reads it back as a `Long` (see §9).
  - **credentials** = `null` (we don't keep the password around).
  - **authorities** = `Collections.emptyList()` — Pulse has no role hierarchy;
    every authenticated user has the same access.
- `setDetails(... WebAuthenticationDetailsSource ...)` attaches request
  metadata (remote IP, session id) — standard hygiene.
- `SecurityContextHolder.getContext().setAuthentication(...)` stores the
  identity in the per-thread `SecurityContext`. Everything downstream (the
  authorization rules, `SecurityUtil.currentUserId()`) reads from here.

### Why this filter never blocks (authentication vs authorization)

This is the most important conceptual point for review:

- **Authentication** = "who are you?" That is *all* this filter does. If there
  is a valid token it records the identity; if not, it does **nothing** and
  simply calls `filterChain.doFilter(request, response)` to pass the request
  down the chain. It never sends a `401`/`403` itself.
- **Authorization** = "are you allowed to hit this URL?" That decision happens
  later, in the rules declared in `SecurityConfig`
  (`.anyRequest().authenticated()`). If the request reached a protected URL with
  no authentication in the context, *that* layer rejects it — and the rejection
  is rendered by the `JwtAuthenticationEntryPoint` (§7).

Separating the two means one filter can serve both public and protected
endpoints: it always attempts to authenticate, and lets the URL rules decide
whether authentication was required. The `notYetAuthenticated` guard
(`getAuthentication() == null`) also makes it idempotent and avoids overwriting
an identity already established earlier in the chain.

---

## 6. `SecurityConfig` — the filter chain

```java
@Bean
public SecurityFilterChain securityFilterChain(HttpSecurity http,
                                               JwtAuthFilter jwtAuthFilter,
                                               JwtAuthenticationEntryPoint authenticationEntryPoint) throws Exception {
    http
            .cors(Customizer.withDefaults())
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(session ->
                    session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            .exceptionHandling(ex -> ex.authenticationEntryPoint(authenticationEntryPoint))

            .authorizeHttpRequests(auth -> auth
                    .requestMatchers(PUBLIC_ENDPOINTS).permitAll()
                    .anyRequest().authenticated());

    http.addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

    return http.build();
}
```

### The Spring Security filter-chain model (background)

Every request passes through an ordered chain of servlet filters that Spring
Security assembles. A `SecurityFilterChain` bean **is** that configured chain.
Each filter inspects/decorates the request; the URL authorization filter near
the end enforces the rules; if any access check fails, the configured
`AuthenticationEntryPoint`/`AccessDeniedHandler` writes the response. Our custom
`JwtAuthFilter` is inserted into this chain.

### Line by line

- **`.cors(Customizer.withDefaults())`** — turn CORS on and let Spring use the
  `CorsConfigurationSource` bean from `CorsConfig` (see §8). Without this line
  the CORS bean would be ignored by the security chain.
- **`.csrf(AbstractHttpConfigurer::disable)`** — CSRF protection is disabled.
  This is **correct and safe here** *because* auth is via a `Bearer` token in a
  header, not a cookie. CSRF attacks rely on the browser auto-attaching
  credentials (cookies); a token that the JS client must explicitly add to the
  `Authorization` header is not auto-sent cross-site, so the CSRF token
  machinery is unnecessary.
- **`.sessionManagement(... STATELESS)`** — the linchpin. Spring Security will
  **not create or use an `HttpSession`**. There is no `JSESSIONID`, no
  server-side session store. Identity must be re-established from the token on
  *every* request — which is exactly what `JwtAuthFilter` does. This is the
  JWT/stateless model vs. classic server sessions (see §6.1).
- **`.exceptionHandling(... authenticationEntryPoint(...))`** — registers our
  `JwtAuthenticationEntryPoint` so unauthenticated access to a protected URL
  yields our JSON `401` instead of Spring's default redirect/HTML (§7).
- **`.authorizeHttpRequests(...)`** — the URL rules:
  - `requestMatchers(PUBLIC_ENDPOINTS).permitAll()` — open without a token.
  - `anyRequest().authenticated()` — everything else needs an authenticated
    `SecurityContext`.

  The public list:

  ```java
  private static final String[] PUBLIC_ENDPOINTS = {
          "/api/auth/**",     // signup & login (you can't have a token yet)
          "/ws/**",           // WebSocket handshake (auth handled in the interceptor)
          "/avatars/**",
          "/media/**",
          "/status-media/**",
          "/actuator/health"
  };
  ```

  `/api/auth/**` is public so signup/login work pre-token. `/ws/**` is public to
  the servlet filter chain on purpose — the WebSocket handshake is authenticated
  separately by `WebSocketAuthInterceptor` (§8), not by `JwtAuthFilter`.
- **`http.addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)`**
  — inserts our filter **before** the built-in
  `UsernamePasswordAuthenticationFilter`. Ordering matters: our filter must
  populate the `SecurityContext` from the token *before* the framework's
  username/password form-login filter (which we don't use) and before the
  authorization checks run. Placing it here guarantees the context is set when
  the URL rules are evaluated.
- **Beans also defined here:** `passwordEncoder()` (BCrypt, §3) and
  `authenticationManager(...)` exposed from `AuthenticationConfiguration`
  (available for injection; the auth flow itself doesn't route through an
  `AuthenticationManager` since `AuthService` verifies the password directly).

### 6.1 Stateless JWT vs. server sessions

| | Server session (classic) | Pulse (JWT, stateless) |
|---|---|---|
| Where identity lives | Server memory/store, keyed by a cookie | Inside the signed token the client holds |
| Per-request cost | Session lookup | Signature verification (`isValid`) |
| Horizontal scaling | Needs sticky sessions or shared session store | Any node can verify any token — no shared state |
| Logout / revocation | Delete the session | Hard — token is valid until `exp` (24h here). No server-side revocation list exists in this code |
| CSRF exposure | Yes (cookie auto-sent) | No (header token), hence CSRF disabled |

The revocation gap is the honest weakness to acknowledge in review: because
nothing is stored server-side, a leaked token works until it expires.

---

## 7. `JwtAuthenticationEntryPoint` — the clean 401

When an unauthenticated request hits a protected URL, the authorization layer
needs *something* to render the rejection. That something is the
`AuthenticationEntryPoint`.

```java
@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {

    @Override
    public void commence(HttpServletRequest request,
                         HttpServletResponse response,
                         AuthenticationException authException) throws IOException {

        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());

        String json = "{\"success\":false,"
                + "\"message\":\"Authentication required. Please log in.\","
                + "\"timestamp\":\"" + Instant.now() + "\"}";

        response.getWriter().write(json);
    }
}
```

- Spring Security calls `commence(...)` whenever an `AuthenticationException`
  bubbles out of the chain (i.e. the request needed authentication and didn't
  have it). It is wired in via `.exceptionHandling(... authenticationEntryPoint(...))`
  in `SecurityConfig`.
- The default Spring behavior for a browser is an HTML login page / redirect —
  useless for a JSON API. This override forces a `401` with a JSON body shaped
  like the rest of the API (`success/message/timestamp`), so the frontend gets a
  consistent, machine-readable error and can route the user to login.

---

## 8. WebSocket authentication

Pulse uses STOMP over WebSocket with SockJS. The handshake is HTTP, but after
upgrade there is no `Authorization` header per frame — so the WebSocket path
authenticates **once, at the handshake**, differently from REST.

### 8.1 Wiring (`WebSocketConfig`)

```java
registry
        .addEndpoint(WEBSOCKET_ENDPOINT)          // "/ws"
        .addInterceptors(authInterceptor)         // WebSocketAuthInterceptor
        .setHandshakeHandler(new WebSocketHandshakeHandler())
        .setAllowedOrigins(allowedOriginsArray)   // from app.allowed-origins
        .withSockJS();
```

The `/ws` endpoint registers two auth-related collaborators: the
**interceptor** (validates the token, stashes the userId) and the **handshake
handler** (turns that userId into a `Principal`). Origins come from
`app.allowed-origins`.

### 8.2 The interceptor (`WebSocketAuthInterceptor`)

```java
@Override
public boolean beforeHandshake(ServerHttpRequest request,
                               ServerHttpResponse response,
                               WebSocketHandler wsHandler,
                               Map<String, Object> attributes) {

    String query = request.getURI().getQuery();

    boolean tokenMissing = (query == null || !query.contains(TOKEN_PARAM)); // "token="
    if (tokenMissing) {
        return false;
    }

    String token = extractToken(query);

    boolean tokenIsValid = jwtUtil.isValid(token);
    if (!tokenIsValid) {
        return false;
    }

    Long userId = jwtUtil.extractUserId(token);
    attributes.put("userId", userId);

    return true;
}
```

- It implements Spring's `HandshakeInterceptor`. `beforeHandshake` runs during
  the HTTP upgrade, **before** the socket is established.
- **The token comes from the URL query string** (`?token=...`), not a header —
  parsed by `extractToken` which splits on `&` and reads the `token=` part.
- Validation reuses the *same* `jwtUtil.isValid` / `jwtUtil.extractUserId` as
  REST — one source of truth for "is this token genuine".
- **Returning `false` aborts the handshake** (the connection is refused). This
  is the WebSocket equivalent of a `401`: no valid token → no socket.
- On success it stores the userId in the `attributes` map. That map is the
  bridge to the next stage — it survives into the WebSocket session.

### 8.3 The handshake handler (`WebSocketHandshakeHandler`)

```java
public class WebSocketHandshakeHandler extends DefaultHandshakeHandler {

    @Override
    protected Principal determineUser(ServerHttpRequest request,
                                      WebSocketHandler wsHandler,
                                      Map<String, Object> attributes) {

        Long userId = (Long) attributes.get("userId");

        if (userId == null) {
            return null;
        }

        String userIdAsName = userId.toString();

        return new Principal() {
            @Override
            public String getName() {
                return userIdAsName;
            }
        };
    }
}
```

- It extends `DefaultHandshakeHandler` and overrides `determineUser`, which
  Spring calls to decide the `Principal` for the WebSocket session.
- It reads the `userId` the interceptor placed in `attributes` and returns a
  `Principal` whose **`getName()` is the userId** as a string.
- Why this matters: STOMP user-destination routing (the `/user` prefix set in
  `WebSocketConfig`, e.g. messages sent to `/user/{id}/queue/...`) keys off
  `Principal.getName()`. So making the name the userId lets the broker deliver
  per-user messages. It also means inside message handlers, `principal.getName()`
  yields the same id that `SecurityUtil.currentUserId()` yields over REST,
  keeping identity consistent across both transports.

### 8.4 Why the token is in the URL (and how this differs from REST)

| | REST (`JwtAuthFilter`) | WebSocket (`WebSocketAuthInterceptor`) |
|---|---|---|
| Where the token rides | `Authorization: Bearer <token>` header | `?token=<token>` query parameter |
| When checked | Every request | Once, at handshake |
| Identity stored as | `Authentication` in `SecurityContextHolder` (principal = `Long`) | `Principal` on the WS session (name = userId string) |
| Failure behavior | Pass through unauthenticated → entry point sends JSON `401` | `beforeHandshake` returns `false` → handshake refused |

The token is in the URL because the **browser `WebSocket` API cannot set custom
request headers** on the upgrade request — there is no way to attach
`Authorization: Bearer ...` from client JS. The query parameter is the standard
workaround. The trade-off to acknowledge in review: URLs can be logged (server
access logs, proxies), so a token in the query string is more exposable than one
in a header; it is mitigated here by the short token lifetime and TLS in
transit, but it is a known cost of the browser limitation.

---

## 9. Reading "who is calling" everywhere else (`SecurityUtil`)

Once `JwtAuthFilter` has populated the `SecurityContext`, the rest of the
codebase identifies the caller through one helper:

```java
public static Long currentUserId() {

    Authentication authentication =
            SecurityContextHolder.getContext().getAuthentication();

    if (authentication == null || !authentication.isAuthenticated()) {
        throw new ApiException(HttpStatus.UNAUTHORIZED, "You are not logged in.");
    }

    Object principal = authentication.getPrincipal();

    if (principal instanceof Long userId) {
        return userId;
    }

    throw new ApiException(HttpStatus.UNAUTHORIZED, "Could not identify the current user.");
}
```

- It pulls the `Authentication` out of the thread-bound `SecurityContextHolder`
  — the same object `JwtAuthFilter.authenticate` set.
- The `principal instanceof Long` check is the contract counterpart to the
  filter constructing `new UsernamePasswordAuthenticationToken(userId, ...)`
  with a `Long` principal. If anyone changes the principal type in the filter,
  this is where it breaks — keep them in lockstep.
- It throws `401` rather than returning `null`, so controllers/services can call
  `currentUserId()` and trust they have a real id or an exception.

This is the clean boundary: **the auth layer's only job is to put a `Long` user
id into the `SecurityContext`; the rest of the app reads it via
`SecurityUtil.currentUserId()` and never touches tokens.**

---

## 10. CORS (supporting cast — `CorsConfig`)

Not authentication per se, but it gates browser access and is wired into the
security chain via `.cors(Customizer.withDefaults())`.

```java
CorsConfiguration config = new CorsConfiguration();
config.setAllowedOrigins(parseOrigins(allowedOrigins));   // from app.allowed-origins
config.setAllowedMethods(ALLOWED_METHODS);                // GET,POST,PUT,PATCH,DELETE,OPTIONS
config.setAllowedHeaders(List.of("*"));
config.setAllowCredentials(true);

UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
source.registerCorsConfiguration("/**", config);
```

- Allowed origins come from `app.allowed-origins`
  (`${ALLOWED_ORIGINS:http://localhost:5173,http://localhost:5174}` — env var
  with a dev default), parsed CSV → list.
- `allowedHeaders("*")` permits the `Authorization` header the client must send.
- `allowCredentials(true)` is compatible because explicit origins are listed
  (not `*`) — required when credentials are allowed.
- Spring Security consumes this `CorsConfigurationSource` bean automatically
  because of the `.cors(Customizer.withDefaults())` line in `SecurityConfig`.

---

## 11. End-to-end recap

**Signup/Login (REST):**
`POST /api/auth/*` → `@Valid` DTO check → `AuthService` (duplicate check / BCrypt
hash, or lookup + `matches`) → `JwtUtil.generateToken(userId)` → `AuthResponse`
with the JWT.

**Authenticated REST request:**
client sends `Authorization: Bearer <jwt>` → `JwtAuthFilter` extracts it →
`JwtUtil.isValid` verifies signature + `exp` → `extractUserId` →
`UsernamePasswordAuthenticationToken(userId,...)` into `SecurityContextHolder` →
authorization rule `anyRequest().authenticated()` passes → controller reads
`SecurityUtil.currentUserId()`. If no/invalid token on a protected URL →
`JwtAuthenticationEntryPoint` writes JSON `401`.

**WebSocket:**
client connects to `/ws?token=<jwt>` → `WebSocketAuthInterceptor.beforeHandshake`
validates via `JwtUtil`, stores `userId` in attributes (or returns `false` to
refuse) → `WebSocketHandshakeHandler.determineUser` returns a `Principal` named
with the userId → STOMP user-destination routing uses that name.

**Throughout:** stateless (no sessions), BCrypt one-way password hashing, HMAC-SHA
signed tokens with a 24h expiry, identity always reduced to a `Long` user id.