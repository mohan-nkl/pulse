# Group Feature — Backend Flow

This document covers the **Group** feature of Pulse end to end (backend only): the data model, repositories, REST endpoints, service flows, authorization helpers, the real-time "added to group" push, edge cases, and the framework mechanisms in play. Every claim below is grounded in the actual source under `src/main/java/com/mohan/pulse/group/`.

Audience: a developer who needs to defend this code in a review. References use the form `Class#method`.

---

## 1. Package layout

```
com.mohan.pulse.group
├── Group.java                  // @Entity "groups"
├── GroupMember.java            // @Entity "group_members"
├── GroupRole.java              // enum { ADMIN, MEMBER }
├── GroupRepository.java        // JpaRepository<Group, Long>
├── GroupMemberRepository.java  // JpaRepository<GroupMember, Long> + derived queries
├── GroupController.java        // @RestController /api/groups
├── GroupService.java           // all business logic, @Transactional
└── dtos
    ├── CreateGroupRequest.java
    ├── AddMembersRequest.java
    ├── UpdateGroupRequest.java
    ├── GroupResponse.java
    └── GroupMemberResponse.java
```

Collaborators outside the package:
- `com.mohan.pulse.common.SecurityUtil` — extracts the authenticated user id.
- `com.mohan.pulse.common.ApiException` / `ApiResponse` — error and envelope types.
- `com.mohan.pulse.storage.StorageService` — MinIO upload + presigned URL generation (see `docs/message-feature.md` / media docs for depth).
- `com.mohan.pulse.user.{User, UserRepository}` — the member/owner entity.
- `org.springframework.messaging.simp.SimpMessagingTemplate` — STOMP/WebSocket push (see `docs/message-feature.md` for the realtime layer).

---

## 2. Data model

### 2.1 `Group` entity

`Group.java`:

```java
@Entity
@Table(name = "groups")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Group {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    private String avatarUrl;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by", nullable = false)
    private User createdBy;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private Instant createdAt;
}
```

Field-by-field:

| Field | Column | Notes |
|---|---|---|
| `id` | `id` (PK) | `GenerationType.IDENTITY` — DB auto-increment; the id is assigned only after `INSERT`. |
| `name` | `name NOT NULL` | Required at the DB level; also validated at the API edge via `@NotBlank` on the request DTOs. |
| `avatarUrl` | `avatar_url` (nullable) | Stores the **MinIO object key** (e.g. `groups/<uuid>.png`), *not* a public URL. It is converted to a short-lived presigned URL only at response-mapping time (`toGroupResponse`). `null` means "no avatar". |
| `createdBy` | `created_by NOT NULL` (FK → `users`) | The user who created the group. `@ManyToOne(fetch = LAZY)`. |
| `createdAt` | `created_at NOT NULL, updatable = false` | Set once by Hibernate via `@CreationTimestamp`. |

Note: the entity stores **only** `createdBy`; membership and roles live entirely in the separate `GroupMember` table. There is no `@OneToMany` collection on `Group`, so the relationship is navigated through the `GroupMemberRepository`, never via a lazy collection on the entity.

### 2.2 `GroupMember` entity (the join/membership row)

`GroupMember.java`:

```java
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "group_members",
        uniqueConstraints = @UniqueConstraint(
                columnNames = {"group_id", "user_id"}
        ))
public class GroupMember {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "group_id", nullable = false)
    private Group group;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private GroupRole role;

    @CreationTimestamp
    @Column(updatable = false)
    private Instant joinedAt;
}
```

This is a **rich join entity** (it has its own surrogate `id`, plus a `role` and `joinedAt`), not a bare association table. Each row = "user X is in group Y with role R, since joinedAt".

| Field | Column | Notes |
|---|---|---|
| `id` | `id` (PK) | Surrogate key for the membership row. |
| `group` | `group_id NOT NULL` (FK → `groups`) | `@ManyToOne(fetch = LAZY)`. |
| `user` | `user_id NOT NULL` (FK → `users`) | `@ManyToOne(fetch = LAZY)`. |
| `role` | `role NOT NULL` | `@Enumerated(EnumType.STRING)` → stored as text `"ADMIN"`/`"MEMBER"`. |
| `joinedAt` | `joined_at` (`updatable = false`) | `@CreationTimestamp`; used to pick the "earliest" member for auto-promotion (§4.4). |

**The unique constraint** `@UniqueConstraint(columnNames = {"group_id", "user_id"})` is the integrity backbone: a user can appear in a given group **at most once**. The service code defensively checks `existsByGroupIdAndUserId(...)` before inserting (see `addMembers` and `addInitialMembers`), but even if that check were bypassed concurrently, the DB constraint guarantees no duplicate membership rows.

### 2.3 `GroupRole` enum

`GroupRole.java`:

```java
public enum GroupRole {
    ADMIN,
    MEMBER
}
```

Two roles only. Because `GroupMember.role` is mapped `@Enumerated(EnumType.STRING)`, the **name** is persisted (`"ADMIN"` / `"MEMBER"`), not the ordinal. This is the deliberate, safe choice: reordering or inserting enum constants later will not silently re-map existing rows (which `EnumType.ORDINAL` would).

---

## 3. Repositories

### 3.1 `GroupRepository`

```java
@Repository
public interface GroupRepository extends JpaRepository<Group, Long> {
}
```

No custom methods — only the inherited `JpaRepository` CRUD: `save`, `findById`, `deleteById`, etc. Used by the service for create/find/save/delete of the `Group` aggregate.

### 3.2 `GroupMemberRepository`

```java
@Repository
public interface GroupMemberRepository extends JpaRepository<GroupMember, Long> {

    List<GroupMember> findByGroupId(Long groupId);

    List<GroupMember> findByUserId(Long userId);

    Optional<GroupMember> findByGroupIdAndUserId(Long groupId, Long userId);

    boolean existsByGroupIdAndUserId(Long groupId, Long userId);
}
```

All four are **Spring Data JPA derived queries** — Spring parses the method name and generates the query; no `@Query` needed. `groupId` / `userId` traverse the `group.id` / `user.id` paths of the `@ManyToOne` associations.

| Method | Generated semantics | Used by |
|---|---|---|
| `findByGroupId(groupId)` | All membership rows of a group. | `getMembers`, `leaveGroup` (remaining members), `countMembers`. |
| `findByUserId(userId)` | All groups the user belongs to (as membership rows). | `listMyGroups`. |
| `findByGroupIdAndUserId(groupId, userId)` | The single membership of a user in a group (if any). | `requireMembership` (and therefore `requireAdmin`). |
| `existsByGroupIdAndUserId(groupId, userId)` | `boolean` "is this user already a member?" — cheap `SELECT ... EXISTS`, no entity load. | dedup in `addMembers` / `addInitialMembers`. |

`countMembers` is implemented as `findByGroupId(groupId).size()` (`GroupService#countMembers`) — it loads the rows and counts in memory rather than issuing a `COUNT(*)`. Acceptable for small groups; a `countByGroupId` derived method would be the optimization if group sizes grow.

---

## 4. Controller — endpoint reference

`GroupController` is a `@RestController` mapped at `/api/groups`, constructor-injected with `GroupService` (`@RequiredArgsConstructor`). **Every** handler resolves the caller via `SecurityUtil.currentUserId()` and passes it as the first service argument — the controller itself does no authorization; the service does (§6). Every response is wrapped in `ApiResponse<T>` via `ApiResponse.ok(...)`.

| # | Method | Path | Body / Params | Service call | Returns (`data`) |
|---|---|---|---|---|---|
| 1 | `POST` | `/api/groups` | `@Valid CreateGroupRequest` (JSON) | `createGroup(currentUserId, request)` | `GroupResponse` |
| 2 | `GET` | `/api/groups` | — | `listMyGroups(currentUserId)` | `List<GroupResponse>` |
| 3 | `GET` | `/api/groups/{groupId}/members` | path `groupId` | `getMembers(currentUserId, groupId)` | `List<GroupMemberResponse>` |
| 4 | `POST` | `/api/groups/{groupId}/members` | `@Valid AddMembersRequest` (JSON) | `addMembers(currentUserId, groupId, request)` | `List<GroupMemberResponse>` |
| 5 | `DELETE` | `/api/groups/{groupId}/members/{userId}` | path | `removeMember(currentUserId, groupId, userId)` | `List<GroupMemberResponse>` |
| 6 | `POST` | `/api/groups/{groupId}/admins/{userId}` | path | `makeAdmin(currentUserId, groupId, userId)` | `List<GroupMemberResponse>` |
| 7 | `DELETE` | `/api/groups/{groupId}/admins/{userId}` | path | `demoteAdmin(currentUserId, groupId, userId)` | `List<GroupMemberResponse>` |
| 8 | `POST` | `/api/groups/{groupId}/leave` | path | `leaveGroup(currentUserId, groupId)` | `null` (`Void`) |
| 9 | `PUT` | `/api/groups/{groupId}` | `@Valid UpdateGroupRequest` (JSON) | `updateGroup(currentUserId, groupId, request)` | `GroupResponse` |
| 10 | `POST` | `/api/groups/{groupId}/avatar` | `@RequestParam("file") MultipartFile` (multipart) | `updateGroupAvatar(currentUserId, groupId, file)` | `GroupResponse` |
| 11 | `DELETE` | `/api/groups/{groupId}/avatar` | path | `removeGroupAvatar(currentUserId, groupId)` | `GroupResponse` |

Messages returned in the envelope (the `message` field of `ApiResponse`): `"Group created"`, `"Members added"`, `"Member removed"`, `"Member promoted to admin"`, `"Admin dismissed"`, `"You left the group"`, `"Group updated"`, `"Group photo updated"`, `"Group photo removed"`. (`listMyGroups` and `getMembers` use the message-less `ApiResponse.ok(data)`.)

Note the REST convention: **role changes are modeled as a sub-collection** `/admins/{userId}` — `POST` = promote (add to admins), `DELETE` = demote (remove from admins). The handler method is named `dismissAdmin` but it delegates to `groupService.demoteAdmin(...)`.

### DTOs

Requests:

```java
// CreateGroupRequest
@NotBlank(message = "Group name is required")
private String name;
private List<Long> memberIds;          // optional; may be null

// AddMembersRequest
@NotEmpty(message = "At least one member id is required")
private List<Long> memberIds;

// UpdateGroupRequest
@NotBlank(message = "Group name is required")
private String name;
```

`@Valid` on the controller params triggers Bean Validation **before** the service runs; a violation produces a 400 via the global handler. Note the asymmetry: `CreateGroupRequest.memberIds` is *optional* (a group can be created with just its creator) and is therefore null-guarded inside `addInitialMembers`, whereas `AddMembersRequest.memberIds` is `@NotEmpty`.

Responses (both `@AllArgsConstructor @Getter`, immutable views):

```java
// GroupResponse
Long id; String name; String avatarUrl;
GroupRole myRole; int memberCount; Instant createdAt;

// GroupMemberResponse
Long userId; String name; String avatarUrl; GroupRole role;
```

`GroupResponse.myRole` is **caller-relative** — it is the role of the requesting user in that group, computed at mapping time, not a property of the group itself. `avatarUrl` in both DTOs is a freshly generated MinIO presigned URL (or `null`).

---

## 5. Service flows (step by step)

`GroupService` dependencies (`@RequiredArgsConstructor`):

```java
private final GroupRepository groupRepository;
private final GroupMemberRepository groupMemberRepository;
private final UserRepository userRepository;
private final StorageService storageService;
private final SimpMessagingTemplate messagingTemplate;

private static final String GROUP_ADDED_QUEUE = "/queue/group-added";
private static final List<String> ALLOWED_AVATAR_TYPES =
        List.of("image/jpeg", "image/png", "image/webp");
private static final long MAX_AVATAR_SIZE = 5L * 1024 * 1024;   // 5 MB
```

### 5.1 `createGroup` — creator becomes ADMIN, add initial members, notify

```java
@Transactional
public GroupResponse createGroup(Long creatorId, CreateGroupRequest request) {
    User creator = findUserOrThrow(creatorId);

    Group group = new Group();
    group.setName(request.getName());
    group.setCreatedBy(creator);
    Group savedGroup = groupRepository.save(group);

    addMembership(savedGroup, creator, GroupRole.ADMIN);
    addInitialMembers(savedGroup, creatorId, request.getMemberIds());

    int memberCount = countMembers(savedGroup.getId());
    return toGroupResponse(savedGroup, GroupRole.ADMIN, memberCount);
}
```

Steps:
1. Load the creator (`findUserOrThrow` → 404 if the id is unknown).
2. Build and `save` a new `Group` with `name` and `createdBy = creator`. `save` triggers the `INSERT`, populating `id` (IDENTITY) and `createdAt` (`@CreationTimestamp`).
3. **Creator is enrolled as `ADMIN`** via `addMembership(savedGroup, creator, GroupRole.ADMIN)`.
4. Add the optionally-supplied initial members via `addInitialMembers` (next).
5. Return a `GroupResponse` with `myRole = ADMIN` (the caller is always the new admin) and the current member count.

`addInitialMembers`:

```java
private void addInitialMembers(Group group, Long creatorId, List<Long> memberIds) {
    if (memberIds == null) {
        return;
    }
    for (Long memberId : memberIds) {
        boolean isCreator = memberId.equals(creatorId);
        boolean alreadyMember = groupMemberRepository.existsByGroupIdAndUserId(group.getId(), memberId);
        if (!isCreator && !alreadyMember) {
            User member = findUserOrThrow(memberId);
            addMembership(group, member, GroupRole.MEMBER);
            notifyAddedToGroup(group, member.getId());
        }
    }
}
```

- `null` member list is tolerated (create a group with only yourself).
- The creator id is skipped (they were already added as ADMIN in step 3) — prevents a unique-constraint collision.
- `existsByGroupIdAndUserId` dedups within the supplied list.
- Each genuinely-new member is added as `MEMBER` **and** receives a real-time `/queue/group-added` push (§7). Note the creator does *not* get a push (they made the call and get the synchronous response).
- An unknown `memberId` aborts the whole transaction with 404 ("User not found") — see §7 transactional note.

### 5.2 `listMyGroups`

```java
@Transactional(readOnly = true)
public List<GroupResponse> listMyGroups(Long userId) {
    List<GroupMember> memberships = groupMemberRepository.findByUserId(userId);
    List<GroupResponse> responses = new ArrayList<>();
    for (GroupMember membership : memberships) {
        Group group = membership.getGroup();
        int memberCount = countMembers(group.getId());
        responses.add(toGroupResponse(group, membership.getRole(), memberCount));
    }
    return responses;
}
```

For each of the caller's membership rows it builds a `GroupResponse` where `myRole = membership.getRole()` (the caller's actual role in that group). `membership.getGroup()` triggers a lazy load per group; `countMembers` issues one `findByGroupId` per group. So this is **N+1-ish** (one query for memberships + per-group group load + per-group member load). Fine at current scale; a candidate for a fetch-join / batch `count` if it grows. `readOnly = true` lets the persistence provider skip dirty-checking.

### 5.3 `getMembers`

```java
@Transactional(readOnly = true)
public List<GroupMemberResponse> getMembers(Long actorId, Long groupId) {
    requireMembership(groupId, actorId);
    List<GroupMember> members = groupMemberRepository.findByGroupId(groupId);
    ...
    return responses;  // each mapped via toMemberResponse
}
```

Authorization: **any member** may list members (`requireMembership`, not `requireAdmin`). `toMemberResponse` exposes `userId, name, presigned avatarUrl, role` per member. This method is also the **canonical "current member list" projection** — most mutating methods end by returning `getMembers(actorId, groupId)` so the client always gets the post-mutation snapshot.

### 5.4 `addMembers` — requireAdmin, skip existing, notify

```java
@Transactional
public List<GroupMemberResponse> addMembers(Long actorId, Long groupId, AddMembersRequest request) {
    requireAdmin(actorId, groupId);
    Group group = findGroupOrThrow(groupId);

    for (Long memberId : request.getMemberIds()) {
        boolean alreadyMember = groupMemberRepository.existsByGroupIdAndUserId(groupId, memberId);
        if (!alreadyMember) {
            User member = findUserOrThrow(memberId);
            addMembership(group, member, GroupRole.MEMBER);
            notifyAddedToGroup(group, member.getId());
        }
    }
    return getMembers(actorId, groupId);
}
```

1. **Admin only** (`requireAdmin`).
2. Load the group (404 if gone).
3. For each requested id: skip if already a member (idempotent — re-adding an existing member is a silent no-op, not an error); otherwise add as `MEMBER` and fire the `/queue/group-added` push (§7).
4. Return the refreshed member list.

Like `addInitialMembers`, an unknown `memberId` throws 404 and rolls back the whole batch.

### 5.5 `removeMember`

```java
@Transactional
public List<GroupMemberResponse> removeMember(Long actorId, Long groupId, Long targetUserId) {
    requireAdmin(actorId, groupId);

    boolean removingYourself = targetUserId.equals(actorId);
    if (removingYourself) {
        throw new ApiException(HttpStatus.BAD_REQUEST,
                "To leave the group, use leave — not remove.");
    }

    GroupMember target = requireMembership(groupId, targetUserId);
    groupMemberRepository.delete(target);
    return getMembers(actorId, groupId);
}
```

1. **Admin only.**
2. **You cannot remove yourself** — 400 directing you to use `leave` instead. (`leave` has the auto-promote / auto-delete bookkeeping that raw removal does not; routing self-removal through `leave` keeps that invariant in one place.)
3. `requireMembership(groupId, targetUserId)` — the target must actually be a member (else 403 "You are not a member of this group."). Note this also means trying to remove a non-member yields 403, not 404.
4. Delete the membership row and return the refreshed list.

There is no push to the removed user (no "you were removed" event).

### 5.6 `leaveGroup` — auto-delete empty group, auto-promote earliest member

```java
@Transactional
public void leaveGroup(Long actorId, Long groupId) {
    GroupMember membership = requireMembership(groupId, actorId);
    groupMemberRepository.delete(membership);

    List<GroupMember> remainingMembers = groupMemberRepository.findByGroupId(groupId);

    boolean groupIsNowEmpty = remainingMembers.isEmpty();
    if (groupIsNowEmpty) {
        groupRepository.deleteById(groupId);
        return;
    }

    boolean hasAdmin = anyAdmin(remainingMembers);
    if (!hasAdmin) {
        promoteEarliestMemberToAdmin(remainingMembers);
    }
}
```

Anyone (admin or plain member) may leave. Steps:
1. `requireMembership` — must be a member (403 otherwise).
2. Delete your own membership row.
3. Re-read the remaining members.
4. **If none remain → delete the group itself** (`groupRepository.deleteById`). This is the "last person out turns off the lights" rule.
5. **If members remain but none is ADMIN → auto-promote.** This happens when the only/last admin leaves. `anyAdmin` scans roles; `promoteEarliestMemberToAdmin` picks the member with the smallest `joinedAt`:

```java
private void promoteEarliestMemberToAdmin(List<GroupMember> members) {
    GroupMember earliestMember = members.get(0);
    for (GroupMember member : members) {
        boolean joinedEarlier = member.getJoinedAt().isBefore(earliestMember.getJoinedAt());
        if (joinedEarlier) {
            earliestMember = member;
        }
    }
    earliestMember.setRole(GroupRole.ADMIN);
    groupMemberRepository.save(earliestMember);
}
```

Invariant enforced: **a non-empty group always has at least one admin.** Tie-break is undefined if two rows share an exact `joinedAt` (whoever the linear scan settles on), but `joinedAt` is a timestamped instant so collisions are improbable.

Caveat for reviewers: `leaveGroup` does **not** check whether the leaving admin is the *last* admin before deleting — it deletes first, then repairs. The repair (auto-promote) runs only when members remain, which is correct. There's no orphaned-data cleanup of group messages here; that lives in the message feature (cross-reference `docs/message-feature.md`).

### 5.7 `makeAdmin` / `demoteAdmin`

```java
@Transactional
public List<GroupMemberResponse> makeAdmin(Long actorId, Long groupId, Long targetUserId) {
    requireAdmin(actorId, groupId);
    GroupMember target = requireMembership(groupId, targetUserId);
    target.setRole(GroupRole.ADMIN);
    groupMemberRepository.save(target);
    return getMembers(actorId, groupId);
}

@Transactional
public List<GroupMemberResponse> demoteAdmin(Long actorId, Long groupId, Long targetUserId) {
    requireAdmin(actorId, groupId);
    boolean demotingYourself = targetUserId.equals(actorId);
    if (demotingYourself) {
        throw new ApiException(HttpStatus.BAD_REQUEST, "You cannot dismiss yourself as admin.");
    }
    GroupMember target = requireMembership(groupId, targetUserId);
    target.setRole(GroupRole.MEMBER);
    groupMemberRepository.save(target);
    return getMembers(actorId, groupId);
}
```

- Both require the caller to be an admin.
- `makeAdmin` is idempotent in effect: promoting an existing admin just re-sets `ADMIN`.
- **`demoteAdmin` blocks self-demotion** (400) — this protects the "always one admin" invariant: a sole admin cannot strip their own rights and leave the group leaderless. To relinquish control you would promote someone else first, or leave (which auto-promotes). It does **not** prevent demoting *another* admin, so the last-admin invariant could in principle be broken by demoting peers — but since you cannot demote yourself, at least the actor remains an admin throughout, so the group is never left with zero admins by this path.
- The dirty-checked entity is `save`d (explicit, though within a transaction the change would flush anyway).

### 5.8 `updateGroup` (rename)

```java
@Transactional
public GroupResponse updateGroup(Long actorId, Long groupId, UpdateGroupRequest request) {
    requireAdmin(actorId, groupId);
    Group group = findGroupOrThrow(groupId);
    group.setName(request.getName().trim());
    Group savedGroup = groupRepository.save(group);
    int memberCount = countMembers(groupId);
    return toGroupResponse(savedGroup, GroupRole.ADMIN, memberCount);
}
```

Admin-only rename. The new name is `.trim()`-ed before saving (`@NotBlank` already rejected empty/whitespace-only input at the controller). `myRole` is hardcoded `ADMIN` in the response — safe, because `requireAdmin` guarantees the caller is an admin.

### 5.9 Avatar: upload / validate / remove

```java
@Transactional
public GroupResponse updateGroupAvatar(Long actorId, Long groupId, MultipartFile file) {
    requireAdmin(actorId, groupId);
    validateAvatar(file);
    Group group = findGroupOrThrow(groupId);
    String avatarKey = storageService.upload("groups", file);
    group.setAvatarUrl(avatarKey);
    Group savedGroup = groupRepository.save(group);
    int memberCount = countMembers(groupId);
    return toGroupResponse(savedGroup, GroupRole.ADMIN, memberCount);
}

@Transactional
public GroupResponse removeGroupAvatar(Long actorId, Long groupId) {
    requireAdmin(actorId, groupId);
    Group group = findGroupOrThrow(groupId);
    group.setAvatarUrl(null);
    Group savedGroup = groupRepository.save(group);
    ...
}
```

Validation (`validateAvatar`):

```java
private void validateAvatar(MultipartFile file) {
    boolean fileMissing = (file == null || file.isEmpty());
    if (fileMissing) throw new ApiException(BAD_REQUEST, "File must not be empty.");
    boolean tooLarge = file.getSize() > MAX_AVATAR_SIZE;            // 5 MB
    if (tooLarge) throw new ApiException(BAD_REQUEST, "Group photo must not exceed 5 MB.");
    boolean unsupportedType = !ALLOWED_AVATAR_TYPES.contains(file.getContentType());
    if (unsupportedType) throw new ApiException(BAD_REQUEST, "Group photo must be JPEG, PNG, or WebP.");
}
```

Upload flow:
1. **Admin only**, then validate (non-empty, ≤ 5 MB, content-type ∈ {jpeg, png, webp}). All failures are 400.
2. `storageService.upload("groups", file)` stores the bytes in MinIO under `groups/<uuid><ext>` and returns the **object key** (see `StorageService#upload` / §8.7).
3. The key is stored in `group.avatarUrl` and saved.
4. `toGroupResponse` converts the stored key to a presigned URL for the response.

Remove flow simply nulls `avatarUrl`. Reviewer note: removing/replacing an avatar **does not delete the old object from MinIO** — old objects are orphaned in the bucket. That's a known trade-off (no cleanup), not a correctness bug for the user-visible behavior.

---

## 6. Authorization helpers

All authorization is centralized in two private helpers; controllers never check roles.

```java
private GroupMember requireMembership(Long groupId, Long userId) {
    Optional<GroupMember> maybeMember = groupMemberRepository.findByGroupIdAndUserId(groupId, userId);
    if (maybeMember.isEmpty()) {
        throw new ApiException(HttpStatus.FORBIDDEN, "You are not a member of this group.");
    }
    return maybeMember.get();
}

private void requireAdmin(Long actorId, Long groupId) {
    GroupMember membership = requireMembership(groupId, actorId);
    boolean isAdmin = (membership.getRole() == GroupRole.ADMIN);
    if (!isAdmin) {
        throw new ApiException(HttpStatus.FORBIDDEN, "Only an admin can do that.");
    }
}
```

- `requireMembership` is both the **fetch** of the membership row and the **gate**: not a member → `ApiException(FORBIDDEN, "You are not a member of this group.")`. It returns the row so callers (`leaveGroup`, `removeMember`, `makeAdmin`, `demoteAdmin`) can mutate it directly.
- `requireAdmin` builds on it: first prove membership, then assert `role == ADMIN`, else `ApiException(FORBIDDEN, "Only an admin can do that.")`.
- `ApiException` carries an `HttpStatus`; the global exception handler turns it into the HTTP status + `ApiResponse.error(message)` envelope. Using **403 FORBIDDEN** (not 404) for "not a member" means the API does not distinguish "group doesn't exist" from "you can't see it" on member-scoped operations — a reasonable information-leak-minimizing default.

Read access (`getMembers`, `listMyGroups`) requires only membership; all mutations except `leave` require admin; `leave` requires only membership.

Other supporting helpers:
- `findGroupOrThrow` / `findUserOrThrow` → `ApiException(NOT_FOUND, ...)` when the id is unknown.
- `addMembership(group, user, role)` builds and saves a `GroupMember`.
- `countMembers(groupId)` = `findByGroupId(groupId).size()`.
- `toGroupResponse` / `toMemberResponse` map entities → DTOs and resolve presigned avatar URLs.

The caller id itself comes from `SecurityUtil.currentUserId()` (`common/SecurityUtil.java`), which reads `SecurityContextHolder`, throws `ApiException(UNAUTHORIZED, "You are not logged in.")` if there is no authenticated principal, and expects the principal to be a `Long` user id (set by the auth filter):

```java
Object principal = authentication.getPrincipal();
if (principal instanceof Long userId) {
    return userId;
}
throw new ApiException(HttpStatus.UNAUTHORIZED, "Could not identify the current user.");
```

So the authorization chain per request is: **authenticated (SecurityUtil) → member (requireMembership) → admin (requireAdmin)** as each endpoint demands.

---

## 7. Real-time "added to group" push

When a user is added to a group (either as an initial member at creation, or via `addMembers`), the backend pushes a notification over WebSocket so the client can show the new group without polling:

```java
private void notifyAddedToGroup(Group group, Long userId) {
    int memberCount = countMembers(group.getId());
    GroupResponse response = toGroupResponse(group, GroupRole.MEMBER, memberCount);
    messagingTemplate.convertAndSendToUser(userId.toString(), GROUP_ADDED_QUEUE, response);
}
```

- `GROUP_ADDED_QUEUE = "/queue/group-added"`.
- `SimpMessagingTemplate.convertAndSendToUser(user, destination, payload)` sends a **user-targeted** STOMP message: under the hood Spring rewrites the destination to a per-session user queue (`/user/{userId}/queue/group-added`). The `userId.toString()` must match the principal name used in the STOMP/WebSocket session for delivery to reach the right client.
- The payload is a full `GroupResponse` with `myRole = MEMBER` (newly added users are always plain members) and the current member count — enough for the client to render the group entry immediately.
- The push is fired **only for newly added members**, not the creator and not for already-existing members (both are filtered out before `notifyAddedToGroup` is reached).

Cross-reference: the STOMP broker configuration, the `/user/...` destination prefix, the principal wiring, and the broader realtime architecture (1:1 and group messages) are documented in **`docs/message-feature.md`**. `SimpMessagingTemplate` here is the same template that feature uses.

**Transactional interaction (important for reviewers):** `notifyAddedToGroup` is called *inside* the `@Transactional` `createGroup` / `addMembers` methods, **before** the transaction commits. If a later iteration throws (e.g. a bad `memberId` → 404) and the transaction rolls back, members already notified in earlier iterations will have received a `/queue/group-added` push for a group whose membership was rolled back. This is a real (if low-probability) inconsistency window: the WebSocket send is not transaction-bound. A hardened version would defer the push to an after-commit hook. Worth calling out in review.

---

## 8. Framework / library mechanisms — what, why, how

### 8.1 JPA/Hibernate entity mapping
**What:** `@Entity` + `@Table` map `Group` → `groups` and `GroupMember` → `group_members`. `@Id` + `@GeneratedValue(strategy = IDENTITY)` use DB auto-increment PKs. **Why:** declarative persistence — no hand-written SQL for CRUD. **How:** Hibernate generates `INSERT`/`UPDATE`/`DELETE`/`SELECT` from the annotations; `IDENTITY` means the PK is assigned by the DB on insert (so `id` is null until `save`). See both entity classes.

### 8.2 `@ManyToOne(fetch = FetchType.LAZY)` + `@JoinColumn`
**What:** the FK relationships — `Group.createdBy` → `users.id` via `created_by`; `GroupMember.group`/`user` via `group_id`/`user_id`. **Why LAZY:** avoid eagerly loading the related `User`/`Group` (and its graph) on every fetch; defer until actually dereferenced. **How:** `@JoinColumn(name=..., nullable=false)` names the FK column and makes it `NOT NULL`. Caveat: lazy associations dereferenced outside an open persistence context throw `LazyInitializationException`; here all dereferences happen inside `@Transactional` service methods, so they're safe (e.g. `membership.getGroup()` in `listMyGroups`).

### 8.3 `@Enumerated(EnumType.STRING)`
**What:** persist `GroupMember.role` as the enum **name** (`"ADMIN"`/`"MEMBER"`). **Why:** stable, human-readable, and resilient to enum reordering (unlike `ORDINAL`). **How:** Hibernate reads/writes the `name()` string to the `role` column. See `GroupMember.role`.

### 8.4 `@UniqueConstraint`
**What:** `uniqueConstraints = @UniqueConstraint(columnNames = {"group_id", "user_id"})` on `group_members`. **Why:** a user can be in a group only once — the DB is the source of truth even under concurrency. **How:** Hibernate adds a composite unique index at schema generation; a duplicate insert raises a constraint violation. The service's `existsByGroupIdAndUserId` checks are the friendly first line; the constraint is the guarantee.

### 8.5 `@CreationTimestamp`
**What:** auto-populate `Group.createdAt` and `GroupMember.joinedAt` on insert. **Why:** server-set, tamper-proof creation time without manual code. **How:** Hibernate sets the value at persist time; combined with `updatable = false` it's never overwritten on update. `joinedAt` is load-bearing for `promoteEarliestMemberToAdmin`.

### 8.6 Spring Data JPA derived queries
**What:** the four methods on `GroupMemberRepository`. **Why:** zero boilerplate — declare the method, get the query. **How:** Spring parses `findBy`/`existsBy` + property paths (`GroupId`, `UserId`) into a JPQL/SQL query and a proxy implementation at startup. `existsBy...` returns `boolean` via an efficient existence check.

### 8.7 `@Transactional`
**What:** every mutating service method is `@Transactional`; reads are `@Transactional(readOnly = true)`. **Why:** these methods do **multiple** DB operations that must be atomic — e.g. `createGroup` inserts a group **and** N membership rows; `leaveGroup` deletes a row, re-reads, then deletes the group or promotes someone. Without a single transaction a partial failure would leave the group in a half-built/inconsistent state. **How:** Spring's AOP proxy opens a transaction on entry, commits on normal return, and **rolls back on unchecked exceptions** (`ApiException` is a `RuntimeException`, so a thrown `ApiException` rolls everything back). `readOnly = true` on `listMyGroups`/`getMembers` lets the provider skip dirty-checking and hints the driver. It also keeps the persistence context open so lazy associations resolve (§8.2). One nuance (§7): the WebSocket push is *not* part of this rollback.

### 8.8 Spring multipart `MultipartFile`
**What:** avatar upload binds `@RequestParam("file") MultipartFile` in `GroupController#updateGroupAvatar`. **Why:** standard Spring MVC way to receive a `multipart/form-data` file part. **How:** Spring's multipart resolver parses the request; `validateAvatar` then inspects `isEmpty()`, `getSize()`, `getContentType()`; `StorageService#upload` streams `getInputStream()` to MinIO. (Note `getContentType()` is client-supplied and can be spoofed; this is a content-type *hint* check, not magic-byte sniffing.)

### 8.9 `SimpMessagingTemplate`
**What:** the WebSocket/STOMP send used by `notifyAddedToGroup`. Covered briefly here — full STOMP/broker wiring is in **`docs/message-feature.md`**.

### 8.10 MinIO via `StorageService`
**What:** object storage for avatars. `upload("groups", file)` returns an object key; `presignedUrl(key)` returns a time-limited GET URL (`null` for null/blank keys). The DB stores only the **key**; presigned URLs are generated per response and expire after `minio.presigned-expiry-minutes`. Covered briefly here — full media/storage details belong with the media docs. See `storage/StorageService.java`.

---

## 9. Edge cases & rules (summary)

| Rule | Where enforced | Result |
|---|---|---|
| Caller must be authenticated | `SecurityUtil.currentUserId()` | 401 |
| Read members / list groups → any member | `requireMembership` | 403 if not a member |
| Add / remove / role-change / rename / avatar → admin only | `requireAdmin` | 403 if not admin |
| Cannot remove yourself (use leave) | `removeMember` | 400 |
| Cannot demote yourself as admin | `demoteAdmin` | 400 |
| A user is in a group at most once | DB `@UniqueConstraint` + `existsByGroupIdAndUserId` | dedup / constraint violation |
| Re-adding an existing member is a no-op | `addMembers` / `addInitialMembers` | silently skipped |
| `createGroup` memberIds optional & null-safe | `addInitialMembers` null guard | group with only creator OK |
| Creator is always ADMIN | `createGroup` | — |
| Last member leaving deletes the group | `leaveGroup` | group row deleted |
| Last admin leaving auto-promotes earliest member | `leaveGroup` → `promoteEarliestMemberToAdmin` | group always keeps an admin |
| Unknown group / user id | `findGroupOrThrow` / `findUserOrThrow` | 404 |
| Avatar must be non-empty, ≤ 5 MB, jpeg/png/webp | `validateAvatar` | 400 |
| `memberCount` = `findByGroupId(groupId).size()` | `countMembers` | in-memory count (no `COUNT(*)`) |
| `GroupResponse.myRole` is caller-relative | `toGroupResponse` callers | reflects requester's role |

### Known trade-offs worth flagging in review
1. **WebSocket push is not transactional** (§7) — a rolled-back add can still notify earlier members.
2. **Orphaned MinIO objects** — replacing/removing an avatar never deletes the old object.
3. **N+1 queries** in `listMyGroups` and the `findByGroupId().size()` count pattern — fine at small scale.
4. **No magic-byte validation** — avatar type check trusts the client-supplied `Content-Type`.
5. **`demoteAdmin` can demote peer admins**, but self-demote is blocked, so the actor always remains admin — the last-admin invariant holds via that asymmetry plus the `leave` auto-promote.
